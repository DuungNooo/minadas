"""Nimbus oracle: slender living storm spirit with a single suspended heart.

The mature silhouette is long-necked and tear-shaped, with an asymmetric swept
forelock and a cloud mantle.  No armour borders, gauntlets or spherical doll
head.  Surface eyes and mouth are painted alpha planes, not stacked cubes.
"""
import math


def build(m, stage):
    final = stage == 3
    if final:
        config=dict(hip=16.6, shoulder=25.4, neck=27.0, head=30.0,
                    eye_y=32.0, eye_z=-2.42, hand_y=15.0, head_x=1.05)
    else:
        config=dict(hip=8.5, shoulder=14.2, neck=15.0, head=16.3,
                    eye_y=18.2, eye_z=-2.06, hand_y=8.2, head_x=1.12)
    c=config
    m.bone('body',(0,c['hip'],.2))
    m.bone('core',(0,23.0 if final else 12.4,-.45),'body')
    m.bone('head',(0,c['head'],-.3),'body',(2,0,0))
    m.bone('forelock',(.4,34.4 if final else 20.4,.4),'head')
    for sign,side in [(-1,'left'),(1,'right')]:
        arm_x=sign*(3.25 if final else 2.7)
        elbow_x=sign*(4.05 if final else 3.25)
        m.bone(side+'_arm',(arm_x,c['shoulder'],0),'body',(0,0,sign*9))
        m.bone(side+'_forearm',(elbow_x,20.4 if final else 11.2,-.2),side+'_arm')
        m.bone(side+'_leg',(sign*(1.5 if final else 1.2),14.0 if final else 7.2,.4),'body',(0,0,-sign*3))
        m.bone('eye_'+side,(sign*c['head_x'],c['eye_y'],c['eye_z']),'head')
        m.bone('mantle_'+side,(sign*(1.7 if final else 1.5),c['hip'],1.3),'body')
    m.bone('mantle_back',(0,c['hip'],1.8),'body')
    m.bone('conductor',(0,17 if final else 8.6,2.3),'body')

    def B(n,p,s,mat='stone',bone='body',r=(0,0,0),pivot=None):
        m.box(n,p,s,mat,bone,r,pivot)

    if final:
        # Continuous narrow abdomen, not a waist ring or segmented robot torso.
        B('tapered_abdomen',(-1.65,14.1,-.9),(3.3,6.0,2.5),'stone',r=(4,0,0))
        B('upper_abdomen',(-1.95,18.7,-.7),(3.9,2.1,2.4),'light')
        B('living_back',(-1.2,19.7,1.0),(2.4,6.0,1.3),'dark',r=(-5,0,0))
        B('swept_collar',(-2.7,25,-.7),(5.4,1.9,2.6),'light',r=(-5,0,0))
        B('slender_neck',(-.75,26.2,-1.2),(1.5,4.6,1.8),'light',r=(8,0,0))
        for sign,side in [(-1,'left'),(1,'right')]:
            B(side+'_heart_rib',(sign*2.2-.55,20.2,-.8),(1.1,5.3,2.0),'light',r=(0,0,-sign*13),pivot=(sign*2.2,25.5,.2))
        B('suspended_heart',(-1.1,21.9,-1.55),(2.2,2.2,2.2),'glow','core',r=(0,18,9),pivot=(0,23,-.45))

        # A small, forward-swept, pear-shaped head, total head height 6.5 units.
        B('face_mass',(-1.95,30.5,-2.3),(3.9,3.6,3.2),'light','head',r=(7,0,0))
        B('tapered_chin',(-1.2,29.6,-2.15),(2.4,1.5,2.4),'light','head',r=(12,0,0))
        B('crown_mass',(-1.65,33.6,-1.45),(3.3,1.7,2.8),'stone','head',r=(15,0,0))
        B('swept_occiput',(-1.55,31.1,.3),(3.1,3.2,3.2),'stone','head',r=(28,0,0))
        B('forelock_root',(-.75,34.4,-.3),(1.6,2.0,1.6),'accent','forelock',r=(16,0,-18))
        B('single_swept_crest',(-.15,35.0,.2),(2.5,3.7,0),'crest','forelock',r=(-10,0,-22),pivot=(.3,34.8,.2))
        for sign,side in [(-1,'left'),(1,'right')]:
            # One painted plane contains pupil, white and catchlight.
            B(side+'_painted_eye',(sign*1.05-.64,31.25,-2.425),(1.28,1.5,0),'eye','eye_'+side)
        B('painted_mouth',(-.34,30.45,-2.365),(.68,.42,0),'mouth','head')

        for sign,side in [(-1,'left'),(1,'right')]:
            x=sign*3.25; ex=sign*4.05; ax=sign*4.45
            B(side+'_shoulder_flow',(x-.85,23.5,-.7),(1.7,3.0,1.7),'stone',side+'_arm',r=(0,0,-sign*13))
            B(side+'_spindle_upper_arm',(x-.6,20.1,-.55),(1.2,4.2,1.35),'light',side+'_arm',r=(0,0,-sign*8))
            B(side+'_slender_forearm',(ex-.5,16.1,-.8),(1.0,4.7,1.15),'light',side+'_forearm',r=(0,0,-sign*7))
            B(side+'_small_hand',(ax-.56,14.8,-1.15),(1.12,1.55,1.3),'stone',side+'_forearm',r=(-10,0,sign*5))
            B(side+'_conductor_finger',(ax-.22,14.0,-1.25),(.44,1.2,.5),'accent',side+'_forearm',r=(-12,0,0))
            lx=sign*1.5
            B(side+'_long_thigh',(lx-.67,7.5,-.1),(1.34,6.8,1.7),'dark',side+'_leg',r=(2,0,0))
            B(side+'_long_shin',(lx-.53,1.8,-.5),(1.06,6.0,1.45),'light',side+'_leg',r=(-3,0,0))
            B(side+'_tapered_foot',(lx-.58,.65,-1.8),(1.16,1.6,2.6),'light',side+'_leg',r=(-8,0,0))
            # Large slanted cloud folds plus alpha silhouettes, no rectangular
            # belt edge. Front slit exposes the long legs and narrows the hips.
            mn='mantle_'+side
            B(side+'_mantle_shoulder',(sign*2.3-1.15,11.8,.55),(2.3,5.0,2.3),'stone',mn,r=(0,0,sign*12),pivot=(sign*1.7,16.6,1.3))
            B(side+'_cloud_mantle_fold',(sign*4.2-1.6,3.0,1.0),(3.2,12.9,2.0),'light',mn,r=(-14,0,sign*18),pivot=(sign*2,16,1.4))
            B(side+'_flowing_mantle_outline',(sign*4.4-3.4,1.3,.35),(6.8,14.4,0),'membrane',mn,r=(-10,0,sign*14),pivot=(sign*1.7,16.6,1.3))
            B(side+'_mantle_inner_shadow',(sign*2.95-.65,4.5,2.05),(1.3,10.6,1.4),'dark',mn,r=(-16,0,sign*13),pivot=(sign*1.7,16.6,1.3))
        B('trailing_cloud_back',(-2.55,2.8,3.0),(5.1,13.1,1.5),'stone','mantle_back',r=(-19,0,0),pivot=(0,16.6,2))
        B('tailing_mantle_membrane',(-4.1,1.6,3.85),(8.2,14.1,0),'membrane','mantle_back',r=(-20,0,0),pivot=(0,16.6,2))
        # The body-grown rod curves upward as one clear lightning tail/prong.
        _beam(B,'conductor_root',(0,17,2.45),(3.9,18.2,2.45),.85,'dark')
        _beam(B,'conductor_curve_low',(3.9,18.2,2.45),(5.4,23.6,2.45),.8,'metal')
        _beam(B,'conductor_curve_high',(5.4,23.6,2.45),(4.8,29.8,2.45),.72,'accent')
        _beam(B,'conductor_final_prong',(4.8,29.8,2.45),(6.1,36.4,2.45),.65,'accent')
        B('lightning_needle_tip',(5.4,35.8,2.45),(1.6,2.0,0),'crest','conductor',r=(0,0,-12))
    else:
        # The juvenile has a shorter tapered trunk, shallow bell, larger face
        # ratio and one developing rod; it is not a uniformly shrunk oracle.
        B('juvenile_abdomen',(-1.5,7.7,-.7),(3.0,3.1,2.2),'stone')
        B('juvenile_back',(-1.1,10.1,.9),(2.2,4.2,1.15),'dark')
        B('juvenile_collar',(-2.15,14.1,-.7),(4.3,1.35,2.1),'light')
        B('small_neck',(-.7,15.1,-.9),(1.4,2.0,1.5),'light',r=(6,0,0))
        for sign,side in [(-1,'left'),(1,'right')]:
            B(side+'_heart_curve',(sign*1.75-.45,10.5,-.7),(.9,3.9,1.7),'light',r=(0,0,-sign*11))
        B('suspended_heart',(-.9,11.5,-1.35),(1.8,1.8,1.8),'glow','core',r=(0,12,-8))
        B('juvenile_face',(-2.15,16.5,-1.9),(4.3,3.6,3.1),'light','head',r=(6,0,0))
        B('soft_chin',(-1.5,15.9,-1.8),(3.0,1.3,2.3),'light','head')
        B('head_cap',(-1.8,19.8,-1.2),(3.6,1.35,2.4),'stone','head',r=(10,0,0))
        B('back_of_head',(-1.6,17.8,.8),(3.2,2.0,1.8),'stone','head',r=(20,0,0))
        B('small_forelock',(-.45,20.4,.05),(1.9,2.75,0),'crest','forelock',r=(0,0,-21))
        for sign,side in [(-1,'left'),(1,'right')]:
            B(side+'_painted_eye',(sign*1.12-.65,17.5,-2.065),(1.3,1.4,0),'eye','eye_'+side)
        B('painted_mouth',(-.32,16.65,-2.15),(.64,.4,0),'mouth','head')
        for sign,side in [(-1,'left'),(1,'right')]:
            arm=side+'_arm';fore=side+'_forearm';leg=side+'_leg';mn='mantle_'+side
            x=sign*2.7;ex=sign*3.25;lx=sign*1.2
            B(side+'_upper_arm',(x-.65,11.0,-.5),(1.3,3.8,1.45),'stone',arm,r=(0,0,-sign*9))
            B(side+'_forearm',(ex-.45,8.7,-.65),(.9,2.9,1.1),'light',fore,r=(0,0,-sign*6))
            B(side+'_little_hand',(ex-.55,7.9,-.95),(1.1,1.1,1.25),'light',fore)
            B(side+'_leg',(lx-.6,3.0,-.05),(1.2,4.4,1.5),'dark',leg)
            B(side+'_little_foot',(lx-.65,.7,-1.1),(1.3,2.5,2.0),'light',leg,r=(-6,0,0))
            B(side+'_developing_mantle',(sign*2.5-1.05,3.2,.7),(2.1,5.8,1.4),'stone',mn,r=(-10,0,sign*15),pivot=(sign*1.5,8.5,1.3))
            B(side+'_cloud_outline',(sign*2.8-2.0,2.2,.65),(4.0,6.0,0),'membrane',mn,r=(-10,0,sign*12),pivot=(sign*1.5,8.5,1.3))
        B('short_rear_mantle',(-1.8,3.8,2.1),(3.6,4.5,1.2),'stone','mantle_back',r=(-15,0,0))
        _beam(B,'young_conductor_root',(0,8.8,2),(3.0,10.1,2),.7,'dark')
        _beam(B,'young_conductor_curve',(3.0,10.1,2),(4.0,16.1,2),.65,'metal')
        _beam(B,'young_single_prong',(4.0,16.1,2),(3.4,22.4,2),.55,'accent')
        B('young_needle_tip',(2.8,22,2),(1.3,1.7,0),'crest','conductor',r=(0,0,10))


def _beam(B,name,a,b,width,material):
    dx,dy=b[0]-a[0],b[1]-a[1]
    h=math.hypot(dx,dy)
    center=((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2)
    B(name,(center[0]-width/2,center[1]-h/2,center[2]-width/2),
      (width,h,width),material,'conductor',r=(0,0,-math.degrees(math.atan2(dx,dy))),pivot=center)


def animate(m):
    """Elegant storm motion: drift, stride, hand bolt, collect, recoil, wilt."""
    mature=m.stage==3
    def F(*pairs):return {str(t):v for t,v in pairs}
    def clip(loop,length,bones):return {'loop':loop,'animation_length':length,'bones':bones}
    def R(*pairs):return {'rotation':F(*pairs)}
    def P(*pairs):return {'position':F(*pairs)}
    def S(*pairs):return {'scale':F(*pairs)}
    d=5.2 if mature else 4.2
    idle={
      'body':{'position':F((0,[0,0,0]),(d*.25,[0,.18,0]),(d*.55,[0,-.05,0]),(d*.8,[0,.12,0]),(d,[0,0,0])),
              'rotation':F((0,[0,0,0]),(d*.4,[0,-2,-1]),(d*.75,[0,2,1]),(d,[0,0,0]))},
      'head':R((0,[0,0,0]),(d*.23,[-2,-7,-2]),(d*.4,[-2,-7,-2]),(d*.63,[1,4,1]),(d,[0,0,0])),
      'core':{'scale':F((0,[1,1,1]),(.35,[1.045,1.045,1.045]),(.55,[1,1,1]),(2.7,[1.035,1.035,1.035]),(2.95,[1,1,1]),(d,[1,1,1])),
              'position':F((0,[0,0,0]),(d*.5,[0,.12,0]),(d,[0,0,0]))},
      'forelock':R((0,[0,0,0]),(d*.3,[3,0,-4]),(d*.7,[-2,0,3]),(d,[0,0,0])),
      'conductor':R((0,[0,0,0]),(d*.32,[2,-2,2]),(d*.68,[-2,2,-2]),(d,[0,0,0])),
      'left_forearm':R((0,[0,0,0]),(d*.35,[-7,5,-4]),(d*.65,[-5,-2,-3]),(d,[0,0,0])),
      'right_forearm':R((0,[0,0,0]),(d*.25,[-3,-4,2]),(d*.7,[-5,3,3]),(d,[0,0,0])),
      'mantle_left':R((0,[0,0,0]),(d*.27,[2,0,-3]),(d*.62,[-2,0,2]),(d,[0,0,0])),
      'mantle_right':R((0,[0,0,0]),(d*.37,[-2,0,3]),(d*.74,[2,0,-2]),(d,[0,0,0])),
      'mantle_back':R((0,[0,0,0]),(d*.4,[4,0,0]),(d*.8,[-2,0,0]),(d,[0,0,0])),
    }
    for side in ['left','right']:
        idle['eye_'+side]=S((0,[1,1,1]),(1.6,[1,1,1]),(1.68,[1,.08,1]),(1.77,[1,.08,1]),(1.87,[1,1,1]),(d,[1,1,1]))
    w=1.65 if mature else 1.15
    walk={
      'body':{'position':F((0,[0,0,0]),(w*.25,[0,.18,0]),(w*.5,[0,0,0]),(w*.75,[0,.18,0]),(w,[0,0,0])),
              'rotation':F((0,[1,-3,-1]),(w*.5,[1,3,1]),(w,[1,-3,-1]))},
      'left_leg':R((0,[-16,0,-2]),(w*.5,[16,0,2]),(w,[-16,0,-2])),
      'right_leg':R((0,[16,0,2]),(w*.5,[-16,0,-2]),(w,[16,0,2])),
      'left_arm':R((0,[6,0,-1]),(w*.5,[-6,0,1]),(w,[6,0,-1])),
      'right_arm':R((0,[-6,0,1]),(w*.5,[6,0,-1]),(w,[-6,0,1])),
      'head':R((0,[-1,2,0]),(w*.5,[-1,-2,0]),(w,[-1,2,0])),
      'conductor':R((0,[0,0,2]),(w*.33,[-4,0,0]),(w*.66,[0,0,-2]),(w,[0,0,2])),
      'mantle_left':R((0,[0,0,-2]),(w*.3,[6,0,1]),(w*.7,[-3,0,3]),(w,[0,0,-2])),
      'mantle_right':R((0,[2,0,2]),(w*.3,[-3,0,-3]),(w*.7,[6,0,-1]),(w,[2,0,2])),
      'mantle_back':R((0,[0,0,0]),(w*.25,[5,0,0]),(w*.75,[-2,0,0]),(w,[0,0,0])),
    }
    a=1.25
    attack={
      'body':R((0,[0,0,0]),(.28,[0,12,4]),(.54,[-3,-9,-3]),(.82,[1,-3,-1]),(a,[0,0,0])),
      'head':R((0,[0,0,0]),(.3,[1,-8,-2]),(.55,[-4,8,0]),(a,[0,0,0])),
      'right_arm':R((0,[0,0,0]),(.27,[-30,-8,16]),(.48,[-72,5,4]),(.65,[-76,8,2]),(a,[0,0,0])),
      'right_forearm':R((0,[0,0,0]),(.28,[-35,0,0]),(.52,[-6,0,0]),(.7,[-6,0,0]),(a,[0,0,0])),
      'left_arm':R((0,[0,0,0]),(.35,[-12,0,-20]),(.7,[-8,0,-14]),(a,[0,0,0])),
      'conductor':R((0,[0,0,0]),(.35,[-4,-4,5]),(.5,[5,0,-5]),(.7,[-2,0,2]),(a,[0,0,0])),
      'core':S((0,[1,1,1]),(.38,[1.16,1.16,1.16]),(.56,[.86,.86,.86]),(.8,[1.05,1.05,1.05]),(a,[1,1,1])),
      'forelock':R((0,[0,0,0]),(.4,[0,0,9]),(.58,[-5,0,-8]),(a,[0,0,0])),
    }
    s=2.5
    special={
      'root':P((0,[0,0,0]),(.7,[0,.9,0]),(1.4,[0,1.2,0]),(1.7,[0,.4,0]),(s,[0,0,0])),
      'body':R((0,[0,0,0]),(.7,[-5,0,0]),(1.4,[-8,0,0]),(1.65,[6,0,0]),(2.0,[-2,0,0]),(s,[0,0,0])),
      'head':R((0,[0,0,0]),(.65,[-12,0,0]),(1.4,[-18,0,0]),(1.7,[5,0,0]),(s,[0,0,0])),
      'left_arm':R((0,[0,0,0]),(.8,[-45,0,-48]),(1.4,[-55,0,-55]),(1.68,[-65,0,-25]),(s,[0,0,0])),
      'right_arm':R((0,[0,0,0]),(.8,[-45,0,48]),(1.4,[-55,0,55]),(1.68,[-65,0,25]),(s,[0,0,0])),
      'left_forearm':R((0,[0,0,0]),(.8,[-20,0,0]),(1.4,[-26,0,0]),(1.68,[-5,0,0]),(s,[0,0,0])),
      'right_forearm':R((0,[0,0,0]),(.8,[-20,0,0]),(1.4,[-26,0,0]),(1.68,[-5,0,0]),(s,[0,0,0])),
      'conductor':R((0,[0,0,0]),(.8,[-8,0,9]),(1.4,[-12,0,13]),(1.64,[9,0,-8]),(1.9,[-4,0,4]),(s,[0,0,0])),
      'forelock':R((0,[0,0,0]),(.7,[-5,0,8]),(1.4,[-7,0,12]),(1.65,[6,0,-8]),(s,[0,0,0])),
      'core':S((0,[1,1,1]),(.6,[1.15,1.15,1.15]),(1.4,[1.38,1.38,1.38]),(1.64,[.6,.6,.6]),(1.9,[1.1,1.1,1.1]),(s,[1,1,1])),
    }
    for side,sign in [('left',-1),('right',1)]:
        special['mantle_'+side]=R((0,[0,0,0]),(.8,[8,0,sign*10]),(1.4,[12,0,sign*15]),(1.7,[-5,0,-sign*5]),(s,[0,0,0]))
    special['mantle_back']=R((0,[0,0,0]),(.8,[13,0,0]),(1.4,[20,0,0]),(1.7,[-6,0,0]),(s,[0,0,0]))
    hurt={
      'body':{'position':F((0,[0,0,0]),(.1,[0,.1,.6]),(.28,[0,0,.3]),(.7,[0,0,0])),
              'rotation':F((0,[0,0,0]),(.1,[-10,6,-5]),(.32,[3,-2,2]),(.7,[0,0,0]))},
      'head':R((0,[0,0,0]),(.1,[-14,8,4]),(.3,[4,-3,-2]),(.7,[0,0,0])),
      'conductor':R((0,[0,0,0]),(.18,[9,0,-10]),(.35,[-5,0,5]),(.7,[0,0,0])),
      'forelock':R((0,[0,0,0]),(.18,[7,0,-12]),(.35,[-4,0,5]),(.7,[0,0,0])),
    }
    for side in ['left','right']:hurt['eye_'+side]=S((0,[1,1,1]),(.08,[1,.12,1]),(.26,[1,.12,1]),(.4,[1,1,1]),(.7,[1,1,1]))
    faint={
      'root':P((0,[0,0,0]),(.65,[0,-.7,0]),(1.7,[0,-2.0,0]),(2.2,[0,-2.0,0])),
      'body':R((0,[0,0,0]),(.6,[7,0,-5]),(1.5,[16,0,-12]),(2.2,[16,0,-12])),
      'head':R((0,[0,0,0]),(.6,[12,0,3]),(1.4,[27,0,7]),(2.2,[27,0,7])),
      'left_arm':R((0,[0,0,0]),(.8,[5,0,8]),(2.2,[5,0,8])),
      'right_arm':R((0,[0,0,0]),(.8,[9,0,-8]),(2.2,[9,0,-8])),
      'conductor':R((0,[0,0,0]),(.9,[5,0,12]),(1.6,[8,0,20]),(2.2,[8,0,20])),
      'forelock':R((0,[0,0,0]),(.9,[12,0,-10]),(2.2,[12,0,-10])),
      'core':S((0,[1,1,1]),(.7,[.94,.94,.94]),(2.2,[.76,.76,.76])),
      'mantle_left':R((0,[0,0,0]),(1,[1,0,5]),(2.2,[1,0,5])),
      'mantle_right':R((0,[0,0,0]),(1,[1,0,-5]),(2.2,[1,0,-5])),
      'mantle_back':R((0,[0,0,0]),(1,[5,0,0]),(2.2,[5,0,0])),
    }
    for side in ['left','right']:faint['eye_'+side]=S((0,[1,1,1]),(.75,[1,.08,1]),(2.2,[1,.08,1]))
    m.animations={'idle':clip(True,d,idle),'walk':clip(True,w,walk),
                  'attack':clip(False,a,attack),'special':clip(False,s,special),
                  'hurt':clip(False,.7,hurt),'faint':clip(False,2.2,faint)}
