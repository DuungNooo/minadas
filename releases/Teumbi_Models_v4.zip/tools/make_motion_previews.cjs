/* Capture exact viewer poses for short GIFs or motion strips. */
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
(async()=>{
 const root=__dirname,out='/tmp/teumbi-v4-motion-frames';fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1020,height:720},deviceScaleFactor:1});
 const html=fs.readFileSync(path.join(root,'pack/VIEW_MODELS.html'),'utf8');
 await page.setContent(html);
 await page.addStyleTag({content:'html,body{background:transparent!important}main{grid-template-columns:300px 720px;min-height:720px}section{min-height:720px;height:720px;width:720px;background:transparent!important}#top,#badge,.help{display:none}aside{max-height:720px;overflow:hidden}'});
 await page.waitForFunction(()=>viewer.getState().ready);
 const args=process.argv.slice(2),kinds=args.length?args:['fire','electric','grass','water'];
 for(const kind of kinds){
  const name=kind==='normal'?'teumbi':`teumbi_${kind}_3`;
  await page.selectOption('#model',name);await page.waitForFunction(()=>viewer.getState().ready);
  const key=await page.locator('#animation option').evaluateAll(v=>v.find(x=>x.value.endsWith('.special')).value);
  await page.selectOption('#animation',key);
  const len=await page.evaluate(()=>selectedAnimation().animation_length);
  const dir=path.join(out,kind);fs.rmSync(dir,{recursive:true,force:true});fs.mkdirSync(dir,{recursive:true});
  const frames=Math.max(32,Math.min(64,Math.ceil(len*15)+1));
  for(let i=0;i<frames;i++){
   await page.evaluate(({t})=>{viewer.setView(.48,.12,1);viewer.setTime(t)},{t:len*i/(frames-1)});
   await page.locator('#canvas').screenshot({path:path.join(dir,String(i).padStart(3,'0')+'.png'),omitBackground:true});
  }
  const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
  const record={kind,name,animation:key,duration:len,frames,source_sha256:sha(fs.readFileSync(path.join(root,'pack/source',name+'.json'))),texture_sha256:sha(fs.readFileSync(path.join(root,'pack/textures',name+'.png'))),html_sha256:sha(html),alpha_cutout:true,background:'transparent'};
  fs.writeFileSync(path.join(dir,'timing.json'),JSON.stringify(record));
  fs.writeFileSync(path.join(root,'pack/previews','motion-'+kind+'.render.json'),JSON.stringify(record,null,2));
  console.log('Captured',kind,frames,'frames across',len,'seconds');
 }
 assembleGifs(root,out);
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});

function assembleGifs(root,out){
 const {spawnSync}=require('child_process');
 const code=String.raw`
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json,sys
r=Path(sys.argv[1]); out=Path(sys.argv[2]); models=[]
for kind in ['fire','electric','grass','water']:
 d=out/kind
 if not (d/'timing.json').exists():continue
 info=json.loads((d/'timing.json').read_text());frames=[Image.open(f).convert('RGBA').resize((512,512),Image.Resampling.LANCZOS) for f in sorted(d.glob('*.png'))]
 sample=Image.new('RGB',(768,512))
 for i in range(24):
  f=frames[round(i*(len(frames)-1)/23)].resize((128,128));sample.paste(f,((i%6)*128,(i//6)*128),f)
 palette=sample.quantize(colors=255,method=Image.Quantize.MEDIANCUT)
 palette.putpalette(palette.getpalette()[:765]+[255,0,255])
 encoded=[]
 for f in frames:
  background=Image.new('RGB',f.size,'#e8eddf');background.paste(f,mask=f.getchannel('A'))
  indexed=background.quantize(palette=palette,dither=Image.Dither.NONE)
  indexed.paste(255,mask=f.getchannel('A').point(lambda alpha:255 if alpha<128 else 0));encoded.append(indexed)
 ms=max(30,round(info['duration']*1000/(len(frames)-1)));dur=[ms]*len(frames);dur[-1]=450
 encoded[0].save(r/'pack/previews'/('motion-'+kind+'.gif'),save_all=True,append_images=encoded[1:],duration=dur,loop=0,disposal=2,optimize=False,transparency=255,background=255)
 models.append((kind,info,frames))
if len(models)==4:
 maxlen=max(v['duration'] for k,v,f in models); allframes=[]
 labels={'fire':'불꽃 · 도끼 강타','electric':'전기 · 축전 방출','grass':'풀 · 방패 결합','water':'물 · 물결 연주'}
 fontpath=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc');font=ImageFont.truetype(str(fontpath),19) if fontpath.exists() else ImageFont.load_default()
 for j in range(48):
  t=j/47*maxlen;im=Image.new('RGB',(1280,365),'#edf2e6');dr=ImageDraw.Draw(im)
  for i,(kind,info,frames) in enumerate(models):
   index=min(len(frames)-1,round(t/info['duration']*(len(frames)-1)))
   frame=frames[index].resize((320,320),Image.Resampling.LANCZOS);im.paste(frame,(i*320,45),frame);dr.text((i*320+16,10),labels[kind],fill='#294238',font=font)
  allframes.append(im)
 sample=Image.new('RGB',(1280,365*4))
 for j,index in enumerate([0,12,24,36]):sample.paste(allframes[index],(0,j*365))
 palette=sample.quantize(colors=192);encoded=[f.quantize(palette=palette,dither=Image.Dither.NONE) for f in allframes];dur=[round(maxlen*1000/47)]*48;dur[-1]=500
 encoded[0].save(r/'pack/previews/role-motions.gif',save_all=True,append_images=encoded[1:],duration=dur,loop=0,disposal=2,optimize=False)
 print('Created 4 individual motion GIFs and simultaneous role-motions.gif')
`;
 const r=spawnSync('python',['-c',code,root,out],{stdio:'inherit'});if(r.status!==0)throw new Error('GIF assembly failed');
}
