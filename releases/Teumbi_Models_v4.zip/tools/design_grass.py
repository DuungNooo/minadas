"""V4: a young seed spirit and its tall, living root-warden evolution.

The adult is deliberately long-legged and creature-shaped.  Its antlers and
leaf hands are cutout planes, not a helmet, crown or a stack of shield bricks.
All facial marks are single zero-depth planes.
"""
import math


def dimensions(stage):
    if stage == 2:
        return dict(hip=6.1, shoulder=14.4, sx=3.6, ey=10.6, ex=4.7,
                    wy=7.3, wx=5.5, knee=3.7, face=17.4, neck=15.4,
                    palm_w=5.4, palm_h=7.1, palm_y=5.6, core=12.4,
                    guard_x=2.7, guard_y=10.2)
    return dict(hip=14.1, shoulder=25.8, sx=5.8, ey=20.5, ex=7.6,
                wy=15.2, wx=8.6, knee=8.6, face=31.1, neck=27.7,
                palm_w=8.8, palm_h=11.5, palm_y=10.1, core=23.6,
                guard_x=4.4, guard_y=19.2)


def build(m, stage):
    q=dimensions(stage);young=stage==2
    m.bone('body', (0,q['hip'],.5))
    m.bone('core', (0,q['core'],0), 'body')
    m.bone('head', (0,q['neck'],.3), 'body')
    m.bone('canopy', (0,19.8 if young else 32.8,1), 'head')
    m.bone('tail', (0,6.4 if young else 15,2), 'body')
    for side,s in [('left',-1),('right',1)]:
        m.bone(side+'_arm', (s*q['sx'],q['shoulder'],0), 'body')
        m.bone(side+'_forearm', (s*q['ex'],q['ey'],-.35), side+'_arm')
        m.bone(side+'_palm', (s*q['wx'],q['wy'],-1), side+'_forearm')
        lx=s*(1.7 if young else 2.7)
        m.bone(side+'_leg', (lx,q['hip'],.8), 'root')
        m.bone(side+'_shin', (lx+s*.35,q['knee'],-.7), side+'_leg')
        m.bone(side+'_foot', (lx+s*.5,1.5 if young else 2.5,1.1), side+'_shin')
        m.bone(side+'_eye', (s*(1.55 if young else 1.48),q['face'],-2.61 if young else -2.95), 'head')

    def b(n,p,size,mat='wood',bone='body',rot=(0,0,0),pivot=None):
        m.box(n,p,size,material=mat,bone=bone,rotation=rot,pivot=pivot)

    if young:
        # A seed body and friendly leaf-eared face; the leg chain is already
        # present, but the head is much larger relative to the chest.
        b('seed_body',(-2.7,5.6,-1.8),(5.4,5.1,4.2),'wood')
        b('seed_lower_taper',(-2.1,4.7,-1.35),(4.2,2.0,3.4),'wood',rot=(8,0,0))
        b('seed_back',(-2.2,9.4,.8),(4.4,5.0,2.1),'stone',rot=(-9,0,0))
        b('chest_bridge',(-2.55,13.7,-.9),(5.1,1.8,3),'stone',rot=(-7,0,0))
        for s in [-1,1]:
            b('seed_chest_flank',(s*2.3-.7,10.2,-1),(1.4,4.2,2.8),'stone',rot=(0,0,-s*12))
        b('single_seed_heart',(-.95,11.45,-1),(1.9,1.9,1.9),'glow','core',(0,0,24))
        b('living_neck',(-1.45,14.4,-.5),(2.9,2.3,2.7),'wood',rot=(-12,0,0))
        b('seed_head',(-3.0,15.8,-1.9),(6,4.7,4.1),'stone','head',(0,0,0))
        b('soft_face_slope',(-2.7,15.7,-2.5),(5.4,3.6,1.6),'light','head',(-7,0,0))
        b('seed_muzzle',(-1.3,15.6,-3.3),(2.6,1.4,1.5),'light','head',(-10,0,0))
        b('seed_mouth',(-.7,16.05,-3.35),(1.4,.5,0),'mouth','head',(-10,0,0))
        for side,s in [('left',-1),('right',1)]:
            b(side+'_face_eye',(s*1.55-.75,16.75,-2.61),(1.5,1.75,0),'eye',side+'_eye',(-7,0,0))
            # Two pointed seed leaves replace ears; no box stack at the crown.
            b(side+'_leaf_ear',(s*2.7-1.3,18.8,.1),(2.6,4.3,0),'crest','canopy',(-15,0,-s*24),(s*2.4,19,.4))
        b('seed_tail_stem',(-.5,6.1,1.9),(1,2.7,1),'wood','tail',(-58,0,0),(0,6.5,2.1))
        b('seed_tail_leaf',(-1.35,6.4,4.1),(2.7,3.6,0),'crest','tail',(60,0,0))
    else:
        # Low-poly living anatomy: narrow pelvis, rising trunk, sloping
        # shoulder arch.  Only the heart opening interrupts this mass.
        b('root_pelvis',(-2.9,12.2,-1.15),(5.8,4.7,4.2),'wood',rot=(-8,0,0))
        b('rising_living_trunk',(-3.5,15,-1.55),(7,6.7,4.8),'wood',rot=(-6,0,0))
        b('back_trunk_slope',(-3.2,20,.8),(6.4,7.0,2.9),'stone',rot=(-12,0,0))
        b('shoulder_arch',(-4.45,25.6,-1.2),(8.9,2.5,4.1),'stone',rot=(-8,0,0))
        for s in [-1,1]:
            b('living_chest_flank',(s*3.7-.95,20.7,-1.2),(1.9,5.4,3.6),'stone',rot=(0,0,-s*13))
        b('single_warden_heart',(-1.4,22.2,-1.5),(2.8,2.8,2.8),'glow','core',(0,0,29))
        b('rising_throat',(-1.6,26.3,-.1),(3.2,3.8,3.2),'wood',rot=(-16,0,0))

        # A long creature mask and snout, not a square human face/helmet.
        b('elongated_cranium',(-2.3,28.8,-1.3),(4.6,4.8,4.2),'stone','head',(-13,0,0))
        b('sloping_mask',(-1.95,28.3,-2.6),(3.9,4.0,3.3),'light','head',(-17,0,0))
        b('long_botanical_snout',(-1.15,28.0,-4.1),(2.3,2.1,2.8),'light','head',(-11,0,0))
        b('jaw_taper',(-1.25,27.8,-2.7),(2.5,1.2,3),'wood','head',(-12,0,0))
        b('quiet_mouth',(-.73,28.1,-4.14),(1.46,.55,0),'mouth','head',(-11,0,0))
        for side,s in [('left',-1),('right',1)]:
            b(side+'_watchful_eye',(s*1.48-.78,30.55,-2.95),(1.56,1.15,0),'eye',side+'_eye',(-17,0,-s*7))
            b(side+'_swept_branch',(s*2.0-.37,31.0,1.0),(.74,3.9,.82),'wood','canopy',(-26,0,-s*30),(s*2.0,31,1.1))
            b(side+'_antler_leaf',(s*3.2-1.5,32.2,1.2),(3,5.2,0),'crest','canopy',(-24,0,-s*31),(s*2.9,32.5,1.25))
        # A trailing root-leaf tail gives the stance an animal counterweight.
        b('tapered_tail_base',(-.9,13.4,2.5),(1.8,4.3,1.8),'wood','tail',(-62,0,0),(0,15,2.8))
        b('tail_root_tip',(-.6,13.5,5.5),(1.2,3.7,1.2),'wood','tail',(-68,0,0),(0,15.3,6.1))
        b('tail_leaf',(-2.3,13.3,8.2),(4.6,5.7,0),'crest','tail',(66,0,0))

    for side,s in [('left',-1),('right',1)]:
        arm=side+'_arm';forearm=side+'_forearm';palm=side+'_palm'
        # Shoulder-to-fingertip curves are formed by two angled root masses,
        # not a shoulder box, elbow button and detached gauntlet.
        midx=s*(q['sx']+q['ex'])/2
        armlen=q['shoulder']-q['ey']
        thickness=1.75 if young else 3.1
        b(side+'_sloping_upper_root',(midx-thickness/2,q['ey']-.3,-1.25),
          (thickness,armlen+1.1,2.7 if young else 3.9),'stone',arm,(0,0,s*18))
        midx=s*(q['ex']+q['wx'])/2
        forelen=q['ey']-q['wy']
        b(side+'_tapered_fore_root',(midx-(.8 if young else 1.1),q['wy']-.2,-1.5),
          (1.6 if young else 2.2,forelen+.8,2.1 if young else 2.7),'wood',forearm,(0,0,s*11))
        # The physical hand is shallow. The leaf silhouette and veins live on
        # a genuine cutout plane, preventing brick-shaped shield edges.
        pw=q['palm_w'];ph=q['palm_h'];px=s*q['wx']
        b(side+'_leaf_palm_base',(px-(1.15 if young else 1.5),q['wy']-.7,-2.0),
          (2.3 if young else 3.0,2.3 if young else 3.1,.7),'wood',palm,(0,0,-s*8))
        b(side+'_great_leaf_hand',(px-pw/2,q['palm_y'],-2.5),(pw,ph,0),'membrane',palm)

        leg=side+'_leg';shin=side+'_shin';foot=side+'_foot'
        lx=s*(1.7 if young else 2.7)
        if young:
            b(side+'_young_haunch',(lx-1.05,3.4,-.7),(2.1,3.5,2.6),'wood',leg,(14,0,0))
            b(side+'_young_hock',(lx+s*.2-.65,1.3,.15),(1.3,2.7,1.6),'stone',shin,(-21,0,0))
            for digit in [-1,1]:
                b(side+'_root_toe',(lx+s*.45+digit*.5-.42,.35,-1.2),(.84,1.2,2.8),'wood',foot,(7,digit*13,0))
        else:
            # A powerful haunch tapers to a reversed hock, and then into two
            # slender forward roots. This is a digitigrade silhouette, not boots.
            b(side+'_powerful_haunch',(lx-1.65,9.1,-.7),(3.3,6.3,4.2),'wood',leg,(16,0,-s*6))
            b(side+'_haunch_taper',(lx-1.2,8.0,-1.1),(2.4,4.0,3.1),'stone',leg,(17,0,-s*4))
            b(side+'_reversed_hock',(lx+s*.35-.95,3.4,.1),(1.9,5.6,2.2),'wood',shin,(-25,0,0))
            b(side+'_root_ankle',(lx+s*.5-.8,1.4,.35),(1.6,2.4,2.0),'stone',foot,(13,0,0))
            for digit in [-1,1]:
                b(side+'_long_root_toe',(lx+s*.5+digit*.7-.55,.4,-2.0),(1.1,1.45,4.5),'wood',foot,(9,digit*15,0))


def _guard_angles(q):
    """Two-link XY IK keeps arm roots attached as the two leaf hands join."""
    shoulder=(q['sx'],q['shoulder']);elbow=(q['ex'],q['ey']);wrist=(q['wx'],q['wy'])
    goal=(q['guard_x'],q['guard_y'])
    length1=math.dist(shoulder,elbow);length2=math.dist(elbow,wrist)
    dx,dy=goal[0]-shoulder[0],goal[1]-shoulder[1];distance=math.hypot(dx,dy)
    a=(length1**2-length2**2+distance**2)/(2*distance)
    h=math.sqrt(max(0,length1**2-a*a));ux,uy=dx/distance,dy/distance
    joint=(shoulder[0]+a*ux-h*uy,shoulder[1]+a*uy+h*ux)
    angle=lambda a,b:math.degrees(math.atan2(b[1]-a[1],b[0]-a[0]))
    upper=angle(shoulder,joint)-angle(shoulder,elbow)
    fore=angle(joint,goal)-angle(elbow,wrist)-upper
    return upper,fore,-upper-fore


def animate(m):
    """Six original motions; mature stages stride rather than toy-waddle."""
    young=m.stage==2;q=dimensions(m.stage);pace=.84 if young else 1.0
    def frames(points):return {str(round(t*pace,4)):list(v) for t,v in points}
    def ch(**channels):return {key:frames(value) for key,value in channels.items()}
    def clip(length,bones,loop=False):return {'loop':loop,'animation_length':round(length*pace,4),'bones':bones}
    blink=ch(scale=[(0,(1,1,1)),(1.44,(1,1,1)),(1.51,(1,.09,1)),(1.64,(1,1,1)),(3.6,(1,1,1))])
    idle={
      'body':ch(scale=[(0,(1,1,1)),(1.5,(1.012,1.018,1.01)),(3.6,(1,1,1))]),
      'head':ch(rotation=[(0,(0,-3,0)),(1.4,(-2,3,-1)),(2.7,(1,4,1)),(3.6,(0,-3,0))]),
      'core':ch(position=[(0,(0,0,0)),(1.4,(0,.16,-.04)),(2.6,(0,-.08,.02)),(3.6,(0,0,0))],rotation=[(0,(0,-4,0)),(1.8,(0,4,0)),(3.6,(0,-4,0))]),
      'canopy':ch(rotation=[(0,(0,0,-2)),(1.1,(2,0,3)),(2.5,(-1,0,-1)),(3.6,(0,0,-2))]),
      'tail':ch(rotation=[(0,(0,-5,0)),(1.8,(0,6,0)),(3.6,(0,-5,0))]),
      'left_eye':blink,'right_eye':blink,
    }
    walk={
      'body':ch(position=[(0,(0,0,0)),(.25,(0,.18,0)),(.5,(0,0,0)),(.75,(0,.18,0)),(1,(0,0,0))],rotation=[(0,(1,-3,-1)),(.5,(1,3,1)),(1,(1,-3,-1))]),
      'head':ch(rotation=[(0,(-1,2,0)),(.5,(-1,-2,0)),(1,(-1,2,0))]),
      'tail':ch(rotation=[(0,(0,7,0)),(.5,(0,-7,0)),(1,(0,7,0))]),
      'canopy':ch(rotation=[(0,(0,0,2)),(.5,(0,0,-2)),(1,(0,0,2))]),
    }
    for side,s in [('left',-1),('right',1)]:
        # Hip, knee and toe each participate. The small hip sway is a plant
        # animal's weight transfer, not the old broad seed-shaped waddle.
        walk[side+'_leg']=ch(rotation=[(0,(s*22,0,0)),(.5,(-s*22,0,0)),(1,(s*22,0,0))])
        walk[side+'_shin']=ch(rotation=[(0,(-s*10,0,0)),(.25,(12 if s<0 else -6,0,0)),(.5,(s*10,0,0)),(.75,(-6 if s<0 else 12,0,0)),(1,(-s*10,0,0))])
        walk[side+'_foot']=ch(rotation=[(0,(-s*12,0,0)),(.5,(s*12,0,0)),(1,(-s*12,0,0))])
        walk[side+'_arm']=ch(rotation=[(0,(-s*6,0,0)),(.5,(s*6,0,0)),(1,(-s*6,0,0))])
        walk[side+'_palm']=ch(rotation=[(0,(s*2,0,0)),(.5,(-s*2,0,0)),(1,(s*2,0,0))])

    attack={
      'body':ch(position=[(0,(0,0,0)),(.22,(0,-.5,.7)),(.42,(0,-.2,-1.6)),(.68,(0,0,-.3)),(1.05,(0,0,0))],rotation=[(0,(0,0,0)),(.22,(-4,-9,0)),(.42,(8,13,0)),(.68,(2,4,0)),(1.05,(0,0,0))]),
      'head':ch(rotation=[(0,(0,0,0)),(.22,(-6,-8,0)),(.42,(5,8,0)),(1.05,(0,0,0))]),
      'left_arm':ch(rotation=[(0,(0,0,0)),(.22,(-10,0,-14)),(.42,(-32,-8,24)),(.68,(-13,0,8)),(1.05,(0,0,0))]),
      'left_forearm':ch(rotation=[(0,(0,0,0)),(.22,(0,0,20)),(.42,(-12,0,-24)),(.68,(0,0,-8)),(1.05,(0,0,0))]),
      'left_palm':ch(rotation=[(0,(0,0,0)),(.22,(10,0,-6)),(.42,(0,0,0)),(1.05,(0,0,0))]),
      'tail':ch(rotation=[(0,(0,0,0)),(.25,(0,14,0)),(.46,(0,-17,0)),(.75,(0,7,0)),(1.05,(0,0,0))]),
    }
    # The leaves meet edge-to-edge into ONE broad shield only during special.
    # An actual two-link solve preserves elbow/wrist continuity throughout.
    upper,fore,palm=_guard_angles(q)
    special={
      'body':ch(position=[(0,(0,0,0)),(.25,(0,-.2,.2)),(.65,(0,-.5,0)),(1.7,(0,-.5,0)),(2.1,(0,.12,0)),(2.5,(0,0,0))],rotation=[(0,(0,0,0)),(.65,(3,0,0)),(1.7,(3,0,0)),(2.5,(0,0,0))]),
      'head':ch(rotation=[(0,(0,0,0)),(.5,(4,0,0)),(1.7,(4,0,0)),(2.5,(0,0,0))]),
      'core':ch(scale=[(0,(1,1,1)),(.6,(1.08,1.08,1.08)),(1.1,(1,1,1)),(1.5,(1.06,1.06,1.06)),(2.5,(1,1,1))]),
      'tail':ch(rotation=[(0,(0,0,0)),(.6,(-8,0,0)),(1.7,(-8,0,0)),(2.5,(0,0,0))]),
    }
    for side,s in [('left',-1),('right',1)]:
        special[side+'_arm']=ch(rotation=[(0,(0,0,0)),(.25,(0,0,-s*4)),(.65,(0,0,s*upper)),(1.7,(0,0,s*upper)),(2.1,(0,0,s*upper*.2)),(2.5,(0,0,0))],position=[(0,(0,0,0)),(.65,(0,0,-2)),(1.7,(0,0,-2)),(2.5,(0,0,0))])
        special[side+'_forearm']=ch(rotation=[(0,(0,0,0)),(.25,(0,0,s*4)),(.65,(0,0,s*fore)),(1.7,(0,0,s*fore)),(2.1,(0,0,s*fore*.2)),(2.5,(0,0,0))])
        special[side+'_palm']=ch(rotation=[(0,(0,0,0)),(.65,(0,0,s*palm)),(1.7,(0,0,s*palm)),(2.1,(0,0,s*palm*.2)),(2.5,(0,0,0))])
        special[side+'_shin']=ch(rotation=[(0,(0,0,0)),(.65,(4,0,0)),(1.7,(4,0,0)),(2.5,(0,0,0))])

    squeeze=ch(scale=[(0,(1,1,1)),(.08,(1,.1,1)),(.25,(1,.1,1)),(.46,(1,1,1)),(.65,(1,1,1))])
    hurt={
      'body':ch(position=[(0,(0,0,0)),(.1,(0,0,.6)),(.28,(0,-.15,.2)),(.65,(0,0,0))],rotation=[(0,(0,0,0)),(.1,(-6,0,-3)),(.28,(-3,0,-1)),(.65,(0,0,0))]),
      'head':ch(rotation=[(0,(0,0,0)),(.1,(-11,7,-4)),(.3,(-3,2,-1)),(.65,(0,0,0))]),
      'canopy':ch(rotation=[(0,(0,0,0)),(.13,(7,0,7)),(.35,(-3,0,-3)),(.65,(0,0,0))]),
      'left_eye':squeeze,'right_eye':squeeze,
    }
    faint={
      'root':ch(rotation=[(0,(0,0,0)),(.4,(-3,0,2)),(.85,(-20,0,5)),(1.25,(-68,0,9)),(1.55,(-64,0,9)),(1.9,(-66,0,9))],position=[(0,(0,0,0)),(.8,(0,0,0)),(1.25,(0,3,-.4)),(1.9,(0,2.6,-.4))]),
      'head':ch(rotation=[(0,(0,0,0)),(.5,(11,0,0)),(1.2,(21,0,-4)),(1.9,(21,0,-4))]),
      'core':ch(scale=[(0,(1,1,1)),(.8,(.9,.9,.9)),(1.9,(.76,.76,.76))]),
      'tail':ch(rotation=[(0,(0,0,0)),(.8,(-9,0,8)),(1.9,(-16,0,10))]),
    }
    for side,s in [('left',-1),('right',1)]:
        faint[side+'_eye']=ch(scale=[(0,(1,1,1)),(.45,(1,.08,1)),(1.9,(1,.08,1))])
        faint[side+'_shin']=ch(rotation=[(0,(0,0,0)),(.65,(18,0,0)),(1.2,(33,0,0)),(1.9,(30,0,0))])
        faint[side+'_arm']=ch(rotation=[(0,(0,0,0)),(.9,(0,0,s*9)),(1.9,(0,0,s*12))])
    m.animations={'idle':clip(3.6,idle,True),'walk':clip(1,walk,True),
                  'attack':clip(1.05,attack),'special':clip(2.5,special),
                  'hurt':clip(.65,hurt),'faint':clip(1.9,faint)}
