const {chromium}=require('playwright');
const fs=require('fs'),path=require('path');
const ROOT=__dirname;
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1440,height:1050}});const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 const alphaFixture='/tmp/teumbi-v4-pipeline-test/pack/VIEW_MODELS.html';
 if(!fs.existsSync(alphaFixture))throw Error('Missing three-axis alpha fixture: '+alphaFixture);
 await page.setContent(fs.readFileSync(alphaFixture,'utf8'));
 await page.waitForFunction(()=>window.viewer&&viewer.getState().ready);
 const alpha=await page.evaluate(()=>{
  viewer.pause();viewer.setTime(0);viewer.setView(0,0,1);viewer.render();
  const w=canvas.width,h=canvas.height,aspect=w/h,half=extent*.54*Math.max(1,h/w*.8);
  function sample(p){const q=p.map((v,i)=>v-center[i]);const x=Math.floor((q[0]/half/aspect+1)*w*.5),y=Math.floor((q[1]/half+1)*h*.5);const pixel=new Uint8Array(4);gl.readPixels(x,y,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);return [...pixel]}
  return {count:viewer.getVertices(0).length/9,corner:sample([-2.5,1.5,-2.05]),center:sample([0,4,-2.05]),gl:gl.getError()};
 });
 if(alpha.count!==54||alpha.gl||alpha.center[0]<alpha.center[2]*1.4||alpha.corner[2]<alpha.corner[0]*1.5)throw Error('Zero-plane/alpha rendering fixture failed '+JSON.stringify(alpha));
 console.log('PASS all three zero-plane axes; one double-sided quad each; framebuffer alpha exposes blue cube through transparent sprite corners',JSON.stringify(alpha));
 await page.goto('about:blank');
 await page.setContent(fs.readFileSync(path.join(ROOT,'pack/VIEW_MODELS.html'),'utf8'));
 await page.waitForFunction(()=>window.viewer&&viewer.getState().ready);
 const fixture=await page.evaluate(()=>{
  const b={rotation:[0,0,0],pivot:[0,0,0],bone:'a'};
  const states={a:{b:{pivot:[1,2,3],parent:null},scale:[2,.5,1],rotation:[0,0,90],position:[4,0,0]}};
  const p=point([2,2,3],b,states),n=point([1,1,0],b,states,true);
  return {p,n,finite:[...p,...n].every(Number.isFinite)};
 });
 if(!fixture.finite||fixture.p.some((x,i)=>Math.abs(x-[5,4,3][i])>1e-6)||Math.abs(Math.hypot(...fixture.n)-1)>1e-6)throw Error('Scale/pivot/normal fixture failed '+JSON.stringify(fixture));
 console.log('PASS scale-before-rotation/pivot and inverse-scale normalized normals');
 const models=await page.locator('#model option').evaluateAll(v=>v.map(x=>x.value));let selections=0,animated=0;const finalMotionSignatures={};
 if(models.length!==9)throw Error('Expected 9 models, got '+models.length);
 for(const name of models){
  await page.selectOption('#model',name);await page.waitForFunction(()=>viewer.getState().ready);
  const defaultIdle=await page.evaluate(()=>$('animation').value.endsWith('.idle'));if(!defaultIdle)throw Error('Default idle missing '+name);
  const opts=await page.locator('#animation option').evaluateAll(v=>v.map(x=>x.value));
  if(opts.length!==7)throw Error(name+' expected rest + exactly 6 character motions');
  for(const animation of opts){
   await page.selectOption('#animation',animation);
   const state=await page.evaluate(()=>{
    const a=selectedAnimation(),len=a?a.animation_length:1;
    const poses=[0,.23,.51,.81,1].map(f=>[...vertices(len*f)]);
    const finite=poses.every(p=>p.length>0&&p.every(Number.isFinite));
    let change=0;for(let i=0;i<poses[0].length;i+=9)for(let j=0;j<3;j++)change=Math.max(change,Math.abs(poses[0][i+j]-poses[2][i+j]),Math.abs(poses[0][i+j]-poses[3][i+j]));
    const aspect=canvas.clientWidth/canvas.clientHeight,half=extent*.54*Math.max(1,1/aspect*.8),right=[Math.cos(yaw),0,Math.sin(yaw)],up=[-Math.sin(yaw)*Math.sin(pitch),Math.cos(pitch),Math.cos(yaw)*Math.sin(pitch)];let projection=0;for(const pose of poses)for(let i=0;i<pose.length;i+=9){const v=[pose[i]-center[0],pose[i+1]-center[1],pose[i+2]-center[2]],dot=n=>v.reduce((s,x,j)=>s+x*n[j],0);projection=Math.max(projection,Math.abs(dot(up))/half,Math.abs(dot(right))/(half*aspect))}
    const expectedVertices=model.boxes.reduce((sum,b)=>sum+(b.size.some(v=>v===0)?6:36),0);
    return {gl:gl.getError(),finite,change,len,projection,expectedVertices,actualVertices:poses[0].length/9,signature:JSON.stringify(a)};
   });
   if(state.gl!==0||!state.finite||state.projection>1.001||state.expectedVertices!==state.actualVertices)throw Error(name+': '+animation+': '+JSON.stringify(state));
   if(animation&&state.change<.001)throw Error('Motion is static '+name+' '+animation);
   if(name.endsWith('_3')&&animation){const clip=animation.split('.').pop();(finalMotionSignatures[clip]??=[]).push(state.signature)}
   if(animation)animated++;selections++;
  }
  const special=opts.find(v=>v.endsWith('.special'));await page.selectOption('#animation',special);
  await page.locator('#timeline').evaluate(el=>{el.value='500';el.dispatchEvent(new Event('input',{bubbles:true}))});
  const scrub=await page.evaluate(()=>({s:viewer.getState(),len:selectedAnimation().animation_length}));
  if(scrub.s.playing||Math.abs(scrub.s.time-scrub.len*.5)>.001)throw Error('Scrubber failed '+name);
  await page.click('#replay');const restart=await page.evaluate(()=>viewer.getState());if(!restart.playing||restart.time>.2)throw Error('Replay failed '+name);
  await page.evaluate(()=>{playhead=selectedAnimation().animation_length-.005;playing=true});
  await page.waitForFunction(()=>!viewer.getState().playing,{},{timeout:10000});const end=await page.evaluate(()=>({s:viewer.getState(),len:selectedAnimation().animation_length}));
  if(end.s.playing||Math.abs(end.s.time-end.len)>.001)throw Error('Nonloop action did not hold final pose '+name);
  console.log('PASS viewer',name,opts.length,'poses; movement, scrub, replay, end hold');
 }
 for(const clip of ['walk','attack','special'])if(new Set(finalMotionSignatures[clip]).size!==4)throw Error('Final branches share cloned '+clip+' animation');
 console.log('PASS all four final branches have distinct walk, attack, and special track definitions');
 await page.selectOption('#model','teumbi_water_3');await page.waitForFunction(()=>viewer.getState().ready);await page.selectOption('#animation','');
 const viewerState=await page.evaluate(()=>{viewer.pause();viewer.setView(.48,.15,1);return viewer.getState()});
 await page.screenshot({path:path.join(ROOT,'pack/previews/interactive-viewer.png')});
 if(errors.length)throw Error(errors.join('\n'));
 if(animated!==54||selections!==63)throw Error('Expected54motionsand63rest/motionselections, got '+animated+'/'+selections);
 console.log('PASS all',models.length,'models,',selections,'pose selections,',animated,'nonstatic motions, no JavaScript/WebGL errors');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
