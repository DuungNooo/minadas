"""A mature tide cantor: small painted face, long fins and a grown water harp."""
def build(m,stage):
    adult=stage==3;s=1 if adult else .59
    def bone(n,p,parent='body',r=(0,0,0)):m.bone(n,[v*s for v in p],parent,r)
    def box(n,p,z,mat='stone',b='body',r=(0,0,0)):m.box(n,[round(v*s,5) for v in p],[round(v*s,5) for v in z],mat,b,r)
    bone('body',(0,21,0),'root');bone('core',(0,27,-.25));bone('head',(0,34,0))
    bone('left_arm',(-3.6,30,0));bone('left_forearm',(-4.7,23,-.5),'left_arm')
    bone('right_arm',(3.6,30,0));bone('right_forearm',(4.7,23,-.5),'right_arm')
    bone('left_leg',(-1.8,18,0));bone('right_leg',(1.8,18,0))
    bone('ear_left',(-2.2,37,0),'head');bone('ear_right',(2.2,37,0),'head')
    for side,x in [('left',-1.22),('right',1.22)]:bone('eye_'+side,(x,37,-1.94),'head')
    bone('harp',(6,23,-2.5),'right_forearm')
    bone('ribbon_base',(-3,29,1));bone('ribbon_mid',(-8,22,1),'ribbon_base');bone('ribbon_tip',(-10,14,1),'ribbon_mid')
    bone('mantle_left',(-2.5,21,1));bone('mantle_right',(2.5,21,1))
    # Slender continuous anatomy; the upper chest is open around ONE core.
    box('spinal_tide',(-1.35,23,.5),(2.7,9.8,1.8),'dark',r=(-5,0,0))
    box('flowing_waist',(-1.5,19,-1.1),(3,5.6,2.5),'light',r=(6,0,0))
    box('pelvis',(-2.4,17,-1.2),(4.8,3.8,3),'stone',r=(-7,0,0))
    box('throat',(-.8,32,-.65),(1.6,3,1.6),'light',r=(10,0,0))
    for sg in [-1,1]:
        box('upper_swept_rib',(sg*2.2-.6,28.7,-1),(1.2,3.6,2.2),'light',r=(0,0,sg*32))
        box('living_chest_side',(sg*2.3-.55,24.2,-1.1),(1.1,5.2,2.6),'stone',r=(0,0,-sg*12))
    box('one_tide_heart',(-1.35,25.6,-1.8),(2.7,2.9,2.8),'glow','core',r=(0,12,10))
    # Small head and tapered jaw; all facial features are painted planes.
    hw=4.7 if adult else 5.6
    box('pearlescent_skull',(-hw/2,35,-1.9),(hw,5.1,3.9),'light','head')
    box('tapered_jaw',(-1.6,33.8,-1.7),(3.2,2.2,3.1),'light','head',r=(-10,0,0))
    box('swept_crown',(-1.8,38.8,-.5),(3.6,1.9,3.2),'stone','head',r=(-18,0,-12))
    for side,sg in [('left',-1),('right',1)]:
        box(side+'_eye',(sg*1.22-.6,36.1,-1.94),(1.2,1.9,0),'eye','eye_'+side)
        box(side+'_ear_fin',(sg*2.2-1.1,36.5,-.5),(2.2,5.5,0),'crest','ear_'+side,r=(0,sg*25,-sg*32))
    box('soft_mouth',(-.6,35.3,-1.94),(1.2,.5,0),'mouth','head')
    box('swept_wave_crest',(-2.5,39,.7),(5,6.5,0),'crest','head',r=(-20,0,-25))
    # One long upper limb and forearm per side, without stacked cuffs.
    for side,sg in [('left',-1),('right',1)]:
        arm=side+'_arm';fore=side+'_forearm';leg=side+'_leg'
        box(side+'_upper_arm',(sg*3.8-.6,22.6,-.7),(1.2,8,1.5),'stone',arm,r=(0,0,-sg*8))
        box(side+'_forearm',(sg*5-.5,16.2,-.9),(1,7.2,1.4),'light',fore,r=(6,0,-sg*4))
        box(side+'_long_hand',(sg*5.5-.55,14.3,-1),(1.1,2.8,1.5),'light',fore,r=(12,0,sg*6))
        box(side+'_wrist_fin',(sg*5-.9,16,-1.05),(1.8,5,0),'membrane',fore,r=(0,0,-sg*22))
        box(side+'_thigh',(sg*1.8-.65,10.8,-.8),(1.3,7.8,2),'stone',leg,r=(-6,0,-sg*5))
        box(side+'_calf',(sg*2-.5,3.8,-.8),(1,7.8,1.6),'light',leg,r=(6,0,sg*2))
        box(side+'_pointed_foot',(sg*2-.65,2,-2),(1.3,2.6,3),'stone',leg,r=(8,0,0))
        # Mantle planes carry tapered, irregular cutout hems, with real depth at roots.
        box(side+'_mantle_root',(sg*3.1-.7,17.5,.6),(1.4,5.2,2),'water','mantle_'+side,r=(-12,0,-sg*12))
        box(side+'_long_fin',(sg*5.2-3.3,3,1),(6.6,19,0),'membrane','mantle_'+side,r=(-14,sg*18,-sg*15))
        if adult:box(side+'_outer_train',(sg*7.4-3.2,5,2),(6.4,18,0),'membrane','mantle_'+side,r=(-25,sg*30,-sg*28))
    # The water-harp grows from the supporting right hand. Narrow physical rim,
    # alpha fins and separately animated zero-thickness strings shape the arc.
    box('harp_root',(4.8,17.1,-2.5),(2.2,1.2,1),'fracture','harp',r=(0,0,-10))
    box('harp_outer',(8,18,-2.3),(.8,10.5,.9),'water','harp',r=(0,0,-8))
    box('harp_top',(5,28,-2.3),(4.1,.8,.9),'fracture','harp',r=(0,0,-15))
    box('harp_swept_fin',(6.8,17.7,-2.35),(4.2,12,0),'membrane','harp',r=(0,0,-10))
    for j in range(6 if adult else 4):
        x=5.2+j*.47;h=9.8-j*.18
        bone('string_'+str(j),(x,18.3,-2.6),'harp')
        box('string_'+str(j),(x,18.3,-2.6),(.12,h,0),'string','string_'+str(j))
    # Thin flow membranes replace the former ring of solid blue toy blocks.
    for n,p,z,r in [('ribbon_base',(-7,24,1),(4.5,9,0),(0,25,-28)),('ribbon_mid',(-11,16,1),(4.5,10,0),(0,-15,16)),('ribbon_tip',(-12,9,1),(4.5,9,0),(0,15,-20))]:
        box(n+'_flow',p,z,'membrane',n,r)


def animate(m):
    mature=m.stage==3
    def k(*items):return {str(t):v for t,v in items}
    def R(*v):return {'rotation':k(*v)}
    def P(*v):return {'position':k(*v)}
    def S(*v):return {'scale':k(*v)}
    def clip(length,loop,bones):return {'animation_length':length,'loop':loop,'bones':{n:v for n,v in bones.items() if n in {b['name'] for b in m.bones}}}
    idle={'body':P((0,[0,0,0]),(1.4,[0,.3,0]),(3.2,[0,0,0])), 'head':R((0,[0,-5,-2]),(1.1,[2,3,2]),(2.3,[-2,5,0]),(3.2,[0,-5,-2])), 'left_arm':R((0,[0,0,-8]),(1.5,[0,0,-14]),(3.2,[0,0,-8])), 'right_forearm':R((0,[0,0,5]),(.8,[0,0,-3]),(1.1,[0,0,5]),(3.2,[0,0,5]))}
    for n,phase in [('ribbon_base',1),('ribbon_mid',-1),('ribbon_tip',1)]:idle[n]=R((0,[0,0,phase*5]),(1.6,[phase*4,0,-phase*7]),(3.2,[0,0,phase*5]))
    for n in ['eye_left','eye_right']:idle[n]=S((0,[1,1,1]),(2.4,[1,1,1]),(2.48,[1,.08,1]),(2.59,[1,1,1]),(3.2,[1,1,1]))
    walk={'root':P((0,[0,0,0]),(.4,[0,.7,-.3]),(.8,[0,0,0]),(1.2,[0,.7,-.3]),(1.6,[0,0,0])), 'body':R((0,[0,0,-4]),(.8,[0,0,4]),(1.6,[0,0,-4])), 'left_leg':R((0,[16,0,-4]),(.8,[-12,0,2]),(1.6,[16,0,-4])), 'right_leg':R((0,[-12,0,4]),(.8,[16,0,-2]),(1.6,[-12,0,4])), 'head':R((0,[0,4,3]),(.8,[0,-4,-3]),(1.6,[0,4,3]))}
    for n,phase in [('ribbon_base',1),('ribbon_mid',-1),('ribbon_tip',1)]:walk[n]=R((0,[phase*8,0,9]),(.5,[-phase*8,0,-9]),(1,[phase*8,0,6]),(1.6,[phase*8,0,9]))
    attack={'body':R((0,[0,0,0]),(.22,[0,18,6]),(.4,[0,-14,-6]),(.85,[0,0,0])),'right_arm':R((0,[0,0,0]),(.22,[-10,0,-24]),(.35,[-8,0,14]),(.5,[0,0,8]),(.85,[0,0,0])),'right_forearm':R((0,[0,0,0]),(.25,[0,0,-20]),(.36,[0,0,35]),(.5,[0,0,15]),(.85,[0,0,0])),'ribbon_tip':R((0,[0,0,0]),(.22,[0,0,-20]),(.46,[0,0,25]),(.85,[0,0,0]))}
    special={'body':R((0,[0,0,0]),(.35,[0,8,2]),(.9,[0,-8,-3]),(1.6,[0,6,2]),(2.4,[0,0,0])),'head':R((0,[0,0,0]),(.4,[8,0,-4]),(1,[2,0,5]),(1.8,[-4,0,-2]),(2.4,[0,0,0])),'left_arm':R((0,[0,0,0]),(.35,[-22,0,-18]),(.8,[-35,0,-35]),(1.6,[-20,0,-22]),(2.4,[0,0,0])),'right_arm':R((0,[0,0,0]),(.3,[-8,0,18]),(.55,[0,0,5]),(.85,[-5,0,18]),(1.1,[0,0,5]),(1.45,[-8,0,18]),(1.8,[0,0,5]),(2.4,[0,0,0])),'right_forearm':R((0,[0,0,0]),(.4,[0,0,-16]),(.58,[0,0,20]),(.82,[0,0,-10]),(1.06,[0,0,25]),(1.4,[0,0,-16]),(1.65,[0,0,18]),(2.4,[0,0,0]))}
    for i in range(6 if mature else 4):
        n='string_'+str(i);t=.44+i*.13
        special[n]=P((0,[0,0,0]),(t,[0,0,0]),(t+.07,[0,0,.3]),(t+.15,[0,0,-.16]),(t+.26,[0,0,.08]),(t+.38,[0,0,0]),(2.4,[0,0,0]))
    # The right hand supports the harp; the left hand reaches across to pluck.
    special['left_arm']=R((0,[0,0,0]),(.35,[10,0,5]),(.65,[14.5,0,9]),(1.15,[14.5,0,10]),(1.65,[14,0,8]),(1.95,[-20,0,-22]),(2.4,[0,0,0]))
    special['left_forearm']=R((0,[0,0,0]),(.35,[6,0,55]),(.55,[6,0,89]),(.76,[8,0,82]),(.98,[6,0,94]),(1.2,[8,0,82]),(1.45,[6,0,94]),(1.72,[8,0,84]),(2.4,[0,0,0]))
    special['right_arm']=R((0,[0,0,0]),(.3,[-6,0,3]),(1.75,[-6,0,3]),(2.4,[0,0,0]))
    special['right_forearm']=R((0,[0,0,0]),(.4,[0,0,-3]),(1.75,[0,0,-3]),(2.4,[0,0,0]))
    special['harp']=P((0,[0,0,0]),(.35,[-2,0,-1]),(1.75,[-2,0,-1]),(2.4,[0,0,0]))
    for i,n in enumerate(['ribbon_base','ribbon_mid','ribbon_tip']):
        offset=i*.16
        special[n]=R((0,[0,0,0]),(.4+offset,[0,12,18]),(.85+offset,[6,-18,-22]),(1.3+offset,[-8,15,24]),(1.8+offset,[0,-8,-12]),(2.4,[0,0,0]))
    hurt={'body':R((0,[0,0,0]),(.12,[-10,-12,8]),(.32,[3,4,-3]),(.65,[0,0,0])),'head':R((0,[0,0,0]),(.12,[-12,0,-10]),(.65,[0,0,0])),'harp':R((0,[0,0,0]),(.16,[0,0,18]),(.32,[0,0,-5]),(.65,[0,0,0]))}
    faint={'root':P((0,[0,0,0]),(.3,[0,-.7,0]),(.8,[0,-2,0]),(1.6,[0,-2,0])),'body':R((0,[0,0,0]),(.5,[0,0,-12]),(1,[0,0,-23]),(1.6,[0,0,-23])),'head':R((0,[0,0,0]),(.7,[25,0,5]),(1.6,[25,0,5])),'core':S((0,[1,1,1]),(.8,[.55,.55,.55]),(1.6,[.55,.55,.55]))}
    for n in ['eye_left','eye_right']:faint[n]=S((0,[1,1,1]),(.4,[1,.08,1]),(1.6,[1,.08,1]))
    m.animations={'idle':clip(3.2,True,idle),'walk':clip(1.6,True,walk),'attack':clip(.85,False,attack),'special':clip(2.4,False,special),'hurt':clip(.65,False,hurt),'faint':clip(1.6,False,faint)}
    idle['core']=P((0,[0,0,0]),(1.6,[0,.12,0]),(3.2,[0,0,0]))
    for side,sg in [('left',-1),('right',1)]:
        idle['mantle_'+side]=R((0,[0,sg*-2,sg*2]),(1.6,[sg*2,sg*3,-sg*2]),(3.2,[0,sg*-2,sg*2]))
        walk['mantle_'+side]=R((0,[-3,sg*4,sg*3]),(.8,[4,-sg*4,-sg*3]),(1.6,[-3,sg*4,sg*3]))
        special['mantle_'+side]=R((0,[0,0,0]),(.65,[0,sg*12,sg*5]),(1.25,[-5,-sg*9,-sg*7]),(1.85,[3,sg*5,sg*3]),(2.4,[0,0,0]))
    if not mature:
        for a in m.animations.values():
            a['animation_length']=round(a['animation_length']*.82,4)
            for tracks in a['bones'].values():
                for channel,frames in list(tracks.items()):
                    tracks[channel]={str(round(float(t)*.82,4)):[round(v*(.59 if channel=='position' else 1),5) for v in vec] for t,vec in frames.items()}
