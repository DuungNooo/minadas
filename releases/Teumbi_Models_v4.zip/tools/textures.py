"""Native-pixel creature surfaces using a compact, explicitly chosen palette.

No face bevels, generated gradients or all-over noise.  The alpha-only sprite
materials are for flat facial planes and silhouette-cut fins/leaves/crests.
"""
from __future__ import annotations

import hashlib
from PIL import Image, ImageDraw


def _palette(stone, dark, light, trim, accent, glow, hot, wood, leaf,
             water, metal, string, eye, pupil, mouth, blush, fracture,
             shadow, highlight, iris):
    return dict(stone=stone,dark=dark,light=light,trim=trim,accent=accent,
                glow=glow,hot=hot,wood=wood,leaf=leaf,water=water,metal=metal,
                string=string,eye=eye,pupil=pupil,mouth=mouth,blush=blush,
                fracture=fracture,shadow=shadow,highlight=highlight,iris=iris,
                membrane=leaf,crest=accent)


PALETTES = {
    'normal': _palette(
        '#576575','#2B3545','#8995A0','#C0A16D','#D5B77F',
        '#F6C66C','#FFE4A2','#6D6670','#8995A0','#8995A0',
        '#8995A0','#FFE4A2','#FFF3D6','#263140','#263140','#C0A16D',
        '#D5B77F','#435164','#A6AEB2','#624E40'),
    'fire': _palette(
        '#554652','#292E3A','#E2C4A0','#A65D48','#CB673D',
        '#FFB45E','#FFE2A1','#74443E','#CB673D','#CB673D',
        '#88717A','#FFE2A1','#FFF3D8','#252A36','#432D39','#A65D48',
        '#E2C4A0','#3C3543','#B2785C','#9A4135'),
    'electric': _palette(
        '#EAE2C8','#30384E','#FFF3D8','#BC8F43','#E4BB4F',
        '#FFE17B','#FFF3B0','#BC8F43','#D7BD6C','#B7CFD0',
        '#BC8F43','#FFF3B0','#FFF8E6','#272E42','#484052','#C58F7F',
        '#FFF3D8','#C6BDA8','#FFF3D8','#765D9A'),
    'grass': _palette(
        '#56846C','#294A42','#E2DDAC','#A59057','#A8C977',
        '#D0E995','#F1F5C1','#765C43','#3F7058','#83B9A1',
        '#A59057','#E2DDAC','#FFF3D8','#243E38','#3E5741','#AFAC71',
        '#E2DDAC','#3F6657','#83A481','#827244'),
    'water': _palette(
        '#DEDCC4','#294B60','#F1EDD8','#B2A172','#60A8AD',
        '#A8E3DE','#D8F4E8','#719A99','#60A8AD','#4F9DAA',
        '#78B9BC','#D8F4E8','#FFF7E2','#243F54','#3B5968','#C69B8B',
        '#F1EDD8','#B6C3B8','#D8F4E8','#427F92'),
}


def _rgba(color):
    return tuple(int(color[i:i+2],16) for i in (1,3,5))+(255,)


def tile(kind,material,width,height,seed,face='north'):
    """Return an exactly sized RGBA tile. Sprites use binary cutout alpha.

    The very smallest pieces deliberately reduce to one or two pixels. There
    is no attempt to manufacture detail smaller than the asset's texel grid.
    """
    w,h=max(1,int(width)),max(1,int(height))
    kind=kind if kind in PALETTES else 'normal'
    p=PALETTES[kind]
    material=material if material in p else 'stone'
    c=lambda role:_rgba(p[role])
    name=str(seed).lower()
    number=int.from_bytes(hashlib.sha256(f'{kind}/{material}/{seed}'.encode()).digest()[:4],'little')

    if material in ('eye','mouth','membrane','crest'):
        im=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(im)
        def poly(points,role):
            coords=[(round(x*(w-1)),round(y*(h-1))) for x,y in points]
            d.polygon(coords,fill=c(role))
        if material=='eye':
            # A small painted almond, not a white cuboid attached to the head.
            if kind=='normal':
                d.rectangle((0,0,w-1,h-1),fill=c('pupil'))
                if w>=3 and h>=3:d.point((w-2,0),fill=c('eye'))
            elif w==1 or h==1:
                d.rectangle((0,0,w-1,h-1),fill=c('pupil'))
                if w>=3:d.point((0,0),fill=c('eye'))
                elif h>=3:d.point((0,0),fill=c('eye'))
            else:
                poly([(0,.22),(.2,0),(.8,0),(1,.25),(1,.78),(.8,1),(.2,1),(0,.8)],'eye')
                # Keep a thin pale outer corner and a broad colored iris.
                x0=max(0,w//3);x1=w-1
                d.rectangle((x0,0,x1,h-1),fill=c('iris'))
                px=min(w-1,max(x0,w*2//3))
                d.line((px,0,px,h-1),fill=c('pupil'),width=max(1,w//3))
                # Exactly one shine, never a second set of stacked catchlights.
                if w>=3 and h>=3:d.point((x0,0),fill=c('eye'))
                # Cut the two outer corners back to an almond silhouette.
                if w>=4 and h>=3:
                    im.putpixel((0,0),(0,0,0,0));im.putpixel((0,h-1),(0,0,0,0))
                if 'right' in name or 'r_eye' in name:im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        elif material=='mouth':
            y=max(0,(h-1)//2)
            if w<=2:d.line((0,y,w-1,y),fill=c('mouth'))
            else:
                d.line((1,y,max(1,w-2),y),fill=c('mouth'))
                if h>=3 and w>=5:
                    d.point((0,max(0,y-1)),fill=c('mouth'))
                    d.point((w-1,max(0,y-1)),fill=c('mouth'))
        elif material=='membrane':
            if kind=='grass':
                poly([(.5,0),(.76,.16),(1,.48),(.82,.73),(.5,1),(.18,.73),(0,.48),(.24,.16)],'leaf')
                if w>=4 and h>=5:
                    d.line((w//2,1,w//2,h-2),fill=c('accent'))
                    d.line((w//2,h//2,max(0,w//5),max(1,h//3)),fill=c('accent'))
                    d.line((w//2,h*2//3,min(w-1,w*4//5),h//2),fill=c('accent'))
            elif kind=='water':
                # A swept broad fin with a long taper, never a blue rectangle.
                poly([(.22,0),(.63,.13),(1,.41),(.83,.64),(.60,.77),(.34,1),(.34,.72),(.12,.52),(0,.26)],'water')
                if w>=4 and h>=6:
                    d.line((max(0,w//4),1,w*3//4,h//2,w//3,h-2),fill=c('accent'))
                    d.line((max(0,w//4),1,w//2,h//2),fill=c('highlight'))
            elif kind=='electric':
                poly([(.5,0),(.78,.22),(1,.58),(.73,.78),(.5,1),(.28,.78),(0,.58),(.22,.22)],'light')
                if w>=5 and h>=6:
                    d.line((w//2,1,w//2,h-2),fill=c('trim'))
                    d.line((w//2,h//3,max(0,w//4),h//2),fill=c('accent'))
            elif kind=='fire':
                poly([(.5,0),(.67,.33),(.82,.22),(1,.71),(.68,1),(.24,.92),(0,.65),(.28,.31),(.34,.55)],'accent')
                if w>=4 and h>=5:poly([(.5,.3),(.7,.68),(.5,1),(.28,.74)],'glow')
            else:
                poly([(.5,0),(1,.48),(.71,1),(.2,.87),(0,.35)],'stone')
        else:  # crest
            if kind=='fire':
                poly([(.44,0),(.63,.37),(.8,.23),(1,.68),(.78,1),(.21,1),(0,.71),(.16,.46),(.27,.64)],'accent')
                if w>=4 and h>=5:poly([(.48,.35),(.72,.75),(.56,1),(.28,.83)],'glow')
            elif kind=='electric':
                poly([(.65,0),(.17,.54),(.48,.54),(.28,1),(.9,.36),(.57,.36)],'accent')
                if w>=5 and h>=7:
                    d.line((w*3//5,1,w//3,h//2),fill=c('hot'))
            elif kind=='grass':
                # Long swept antler leaf, broad root then trailing pointed tip.
                poly([(.90,0),(.95,.29),(.78,.59),(.47,.79),(.22,1),(0,.90),(.18,.62),(.47,.29)],'leaf')
                if w>=4 and h>=6:d.line((1,h-2,w//2,h//2,w-2,1),fill=c('accent'))
            elif kind=='water':
                poly([(.81,0),(1,.38),(.81,.78),(.46,1),(.06,.88),(.36,.60),(.43,.27)],'water')
                if w>=4 and h>=6:d.line((w*3//4,1,w//2,h//2,1,h-2),fill=c('highlight'))
            else:
                poly([(.65,0),(1,.50),(.62,1),(0,.79),(.22,.19)],'stone')
        # Tiny one-pixel sprites must not disappear due to a degenerate polygon.
        if im.getbbox() is None:im.putpixel((w//2,h//2),c('pupil' if material in ('eye','mouth') else 'accent'))
        return im

    im=Image.new('RGBA',(w,h),c(material));d=ImageDraw.Draw(im)
    # All subsequent colors are explicit palette entries: no derived gradients.
    if material in ('glow','hot'):
        if w>=3 and h>=3:
            d.rectangle((max(0,w//3),max(0,h//4),max(0,w*2//3),max(0,h*2//3)),fill=c('hot' if material=='glow' else 'light'))
        return im
    if material in ('pupil','blush','string','fracture'):return im
    if material=='water':
        if w>=5 and h>=5 and number%3==0:
            y=h//3;d.line((w//5,y,w*3//5,y),fill=c('highlight'))
        return im
    if material in ('wood','leaf'):
        if min(w,h)>=5 and number%3==0:
            x=w//2
            d.line((x,h//4,x,h*3//4),fill=c('dark' if material=='wood' else 'accent'))
        return im
    # Only large creature volumes get a single meaningful flat pixel marking.
    # No ubiquitous bottom shadow bands; adjacent boxes should form one body.
    if min(w,h)>=7 and w*h>=80 and number%4==0:
        x=w//3;y=h//2
        d.rectangle((x,y,min(w-1,x+max(1,w//5)),min(h-1,y+1)),fill=c('shadow'))
    if kind=='normal' and material=='stone' and min(w,h)>=6 and ('fracture' in name or 'inner' in name):
        d.line((0,h-1,w//2,h//2,w-1,h//2),fill=c('fracture'))
    return im
