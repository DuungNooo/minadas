"""A lean living volcanic predator, with axes growing from its forelimbs.

The head uses painted alpha planes.  The body is an uninterrupted series of
overlapping charcoal masses: no helmet, cuffs, mechanical joints or boots.
"""


def build(m, stage):
    adult=stage==3
    hip=17.2 if adult else 9.3
    chest=24.5 if adult else 14.5
    head=32.5 if adult else 19.6
    shoulder=26.1 if adult else 15.5
    elbow=19.7 if adult else 11.7
    armx=6.05 if adult else 4.7
    m.bone('body',(0,hip,1))
    m.bone('core',(0,chest,-.8),'body')
    m.bone('head',(0,head-3,.1),'body')
    m.bone('jaw',(0,head-1.1,-2.9),'head')
    m.bone('crest',(0,head+1,1),'head')
    for s,side in [(-1,'left'),(1,'right')]:
        m.bone(side+'_arm',(s*armx,shoulder,.6),'body',(0,0,s*9))
        m.bone(side+'_forearm',(s*(armx+.8),elbow,.3),side+'_arm')
        m.bone(side+'_leg',(s*(2.7 if adult else 2.1),hip,1.8),'body')
        m.bone(side+'_shin',(s*(3.1 if adult else 2.2),10.5 if adult else 5.8,3),side+'_leg')
        m.bone(side+'_foot',(s*(3.2 if adult else 2.2),3.7 if adult else 2.2,-.1),side+'_shin')
    m.bone('tail',(0,hip-1,2.6),'body')
    m.bone('tail_mid',(0,11.5 if adult else 7.0,8.2 if adult else 6),'tail')
    m.bone('tail_tip',(0,12 if adult else 7.0,14.8 if adult else 9.8),'tail_mid')

    def b(name,p,size,mat='stone',bone='body',r=(0,0,0),pivot=None):
        m.box(name,p,size,mat,bone,r,pivot)

    # Pelvis, slim waist and full back taper into the neck.  The core sits in
    # an actual opening between two organic chest lobes, rather than a cage.
    pw=3.8 if adult else 3.2
    b('pelvic_mass',(-pw,hip-2.6,.1),(pw*2,5.1 if adult else 3.9,5.0),'stone',r=(-9,0,0))
    b('lean_waist',(-2.6 if adult else -2.4,hip+1,-.2),(5.2 if adult else 4.8,5.7 if adult else 3.6,4.1),'stone',r=(5,0,0))
    b('back_thorax',(-4.1 if adult else -3.4,chest-1.8,1.2),(8.2 if adult else 6.8,5.6 if adult else 4.1,3.8),'stone',r=(-7,0,0))
    for s in [-1,1]:
        x=s*(3.6 if adult else 2.8)
        b('chest_lobe_'+str(s),(x-.95,chest-1.7,-2.25),(1.9,5 if adult else 3.9,4.3),'stone',r=(0,0,s*17))
        b('chest_to_neck_'+str(s),(x-1.15,chest+2,-1.55),(2.3,2.1,3.2),'stone',r=(0,0,-s*23))
    b('living_neck',(-1.7,head-4.8,-.8),(3.4,4.4 if adult else 2.7,3.4),'stone',r=(-12,0,0))
    k=2.7 if adult else 2.25
    b('one_suspended_heart',(-k/2,chest-k/2,-k/2-1.0),(k,k,k),'glow','core',(0,18,0))

    # An elongated animal cranium: rear vault -> narrow snout -> lower jaw.
    hw=3.5 if adult else 3.4
    b('cranial_vault',(-hw,head-1.9,-2.2),(hw*2,4.8 if adult else 4.5,5.0),'stone','head',r=(-5,0,0))
    b('crown_slope',(-hw+.6,head+1.5,-1.65),(hw*2-1.2,1.45,3.8),'stone','head',r=(8,0,0))
    b('forward_muzzle',(-2.15,head-1.35,-4.3),(4.3,2.05,2.6),'stone','head',r=(-7,0,0))
    b('lower_jaw',(-1.8,head-2.0,-4.1),(3.6,.95,2.6),'stone','jaw',r=(3,0,0))
    # Flat painted eyes and mouth lie a fraction above the face. No eye cubes.
    for s,side in [(-1,'left'),(1,'right')]:
        ex=s*(2.1 if adult else 1.9)
        b(side+'_painted_eye',(ex-.75,head-.25,-2.48),(1.5,2.35 if adult else 2.4,0),'eye','head',r=(0,0,-s*(9 if adult else 3)))
    b('painted_mouth',(-1.45,head-1.72,-4.36),(2.9,.8,0),'mouth','jaw')
    # A swept, asymmetric volcanic crest, not two mechanical antennae.
    b('cinder_brow_crest',(-2.8,head+2.1,-.2),(5.6,1.15,3.0),'stone','crest',r=(-22,0,0))
    for s,side in [(-1,'left'),(1,'right')]:
        length=(3.25 if s>0 else 2.5) if adult else (1.8 if s>0 else 1.35)
        x=s*(2.25 if adult else 2.1)
        b(side+'_swept_horn',(x-.65,head+2.2,.7),(1.3,length,1.8),'dark','crest',r=(-24,0,-s*23))
    if adult:
        b('cervical_spine',(-.65,head-2,2.2),(1.3,5,1.9),'accent','crest',r=(-26,0,0))
        b('dorsal_ridge',(-.75,chest+1,4.15),(1.5,4.5,1.5),'accent',r=(-32,0,0))
    else:
        b('young_back_flame',(-.8,chest+1.8,3),(1.6,3.1,1.5),'accent',r=(-20,0,0))

    for s,side in [(-1,'left'),(1,'right')]:
        arm=side+'_arm';fore=side+'_forearm';leg=side+'_leg';shin=side+'_shin';foot=side+'_foot'
        x=s*armx
        b(side+'_upper_arm_muscle',(x-1.35,elbow-.3,-1.15),(2.7,shoulder-elbow+.5,3.5),'stone',arm,r=(0,0,-s*12))
        b(side+'_long_forearm',(x+s*.7-1.1,12.4 if adult else 7.6,-1.0),(2.2,7.2 if adult else 4.0,3.0),'stone',fore,r=(0,0,s*7))
        # Three broad rotated masses give a crescent blade, with no row fan,
        # rectangular shield or separate handle. It IS the end of the limb.
        by=9.0 if adult else 5.5
        inner=1.3 if adult else 1.0
        width=4.2 if adult else 3.0
        left=x+inner if s>0 else x-inner-width
        b(side+'_axe_inner',(left,by+1.8,-1.2),(width,5.0 if adult else 3.5,2.6),'fracture',fore,r=(0,0,-s*8))
        edge=x+s*(inner+width)-.65
        b(side+'_axe_swept_edge',(edge,by+3.0,-1.4),(1.3,4.5 if adult else 3.1,2.9),'accent',fore,r=(0,0,-s*23))
        beard=x+s*(inner+width*.55)-.8
        b(side+'_hooked_beard',(beard,by-.6,-1.1),(1.6,3.5 if adult else 2.2,2.5),'stone',fore,r=(0,0,-s*27))
        lx=s*(2.8 if adult else 2.1)
        # Long digitigrade anatomy: broad haunch -> rear knee -> raised hock.
        b(side+'_haunch',(lx-1.85,hip-(5.5 if adult else 4.2),1.0),(3.7,6.5 if adult else 4.6,4.6),'stone',leg,r=(-19,0,-s*7))
        b(side+'_long_shin',(lx-1.0,4.7 if adult else 2.8,1.1),(2.0,7.6 if adult else 4.2,2.6),'stone',shin,r=(21,0,0))
        b(side+'_raised_hock',(lx-1.0,1.3,-.8),(2.0,4.1 if adult else 2.4,2.5),'stone',foot,r=(-12,0,0))
        b(side+'_grounded_toes',(lx-1.45,.15,-3.25),(2.9,1.45 if adult else 1.3,4.1),'stone',foot)

    # Long, counterbalancing, animal tail: descending base and rising tip.
    b('tail_base',(-1.6,hip-3.3,2.6),(3.2,3.3,7.2 if adult else 4.7),'stone','tail',r=(16,0,0))
    b('tail_middle',(-1.1,10.5 if adult else 6.7,8.1 if adult else 5.8),(2.2,2.4,7.2 if adult else 4.2),'stone','tail_mid',r=(-8,0,0))
    b('tail_whip',(-.65,11.3 if adult else 6.7,14.4 if adult else 9.4),(1.3,1.5,5 if adult else 2.4),'stone','tail_tip',r=(-22,0,0))
    b('tail_ember',(-1.25,12.7 if adult else 7.1,18.4 if adult else 11),(2.5,3.3 if adult else 2.3,2.6),'hot','tail_tip',r=(-15,0,20))


def animate(m):
    """Weight, stalking digitigrade gait and axe momentum come from the rig."""
    adult=m.stage==3
    def frames(*items):return {str(t):list(v) for t,v in items}
    def R(*items):return {'rotation':frames(*items)}
    def P(*items):return {'position':frames(*items)}
    def S(*items):return {'scale':frames(*items)}
    def C(t,b,loop=False):return {'loop':loop,'animation_length':t,'bones':b}
    O=(0,0,0);I=(1,1,1)
    T=3.9 if adult else 3.1
    idle={
      'body':S((0,I),(T*.44,(1.025,1.01,1.04)),(T,I)),
      'head':R((0,O),(.8,(-3,-5,-1)),(1.35,(-1,-11,-2)),(1.53,(3,-10,-1)),(1.8,(0,-6,0)),(T,O)),
      'jaw':R((0,O),(1.3,O),(1.46,(8 if adult else 13,0,0)),(1.63,O),(T,O)),
      'right_forearm':R((0,O),(T*.61,O),(T*.73,(3,0,-7)),(T*.85,O),(T,O)),
      'tail':R((0,(0,-5,0)),(T*.43,(0,7,1)),(T,(0,-5,0))),
      'tail_mid':R((0,(0,-3,0)),(T*.6,(0,8,0)),(T,(0,-3,0))),
      'tail_tip':R((0,(0,6,-3)),(T*.33,(0,-9,4)),(T*.7,(0,7,-2)),(T,(0,6,-3))),
      'core':S((0,I),(T*.2,(1.07,1.07,1.07)),(T*.32,I),(T*.4,(1.035,1.035,1.035)),(T*.52,I),(T,I))}
    W=1.35 if adult else .92
    walk={
      'root':P((0,O),(W*.18,(0,.45,0)),(W*.35,O),(W*.66,(0,.55,0)),(W*.84,O),(W,O)),
      'body':R((0,(3,-4,3)),(W*.34,(3,4,-3)),(W*.72,(3,-4,3)),(W,(3,-4,3))),
      'head':R((0,(-2,3,-2)),(W*.5,(-2,-3,2)),(W,(-2,3,-2))),
      'left_leg':R((0,(21,0,0)),(W*.23,(-14,0,0)),(W*.52,(-17,0,0)),(W*.77,(19,0,0)),(W,(21,0,0))),
      'right_leg':R((0,(-16,0,0)),(W*.31,(20,0,0)),(W*.56,(17,0,0)),(W*.83,(-16,0,0)),(W,(-16,0,0))),
      'left_shin':R((0,(-8,0,0)),(W*.29,(26,0,0)),(W*.51,(5,0,0)),(W*.76,(-7,0,0)),(W,(-8,0,0))),
      'right_shin':R((0,(20,0,0)),(W*.27,(-6,0,0)),(W*.55,(-7,0,0)),(W*.81,(25,0,0)),(W,(20,0,0))),
      'left_foot':R((0,(3,0,0)),(W*.3,(-14,0,0)),(W*.55,(9,0,0)),(W, (3,0,0))),
      'right_foot':R((0,(-11,0,0)),(W*.3,(8,0,0)),(W*.79,(-12,0,0)),(W,(-11,0,0))),
      'left_arm':R((0,(-6,0,-1)),(W*.5,(7,0,-2)),(W,(-6,0,-1))),
      'right_arm':R((0,(8,0,1)),(W*.55,(-5,0,2)),(W,(8,0,1))),
      'tail':R((0,(0,-10,0)),(W*.5,(0,10,0)),(W,(0,-10,0))),
      'tail_mid':R((0,(0,6,0)),(W*.5,(0,-6,0)),(W,(0,6,0)))}
    A=1.12 if adult else .83
    attack={
      'body':R((0,O),(A*.27,(0,-26,-6)),(A*.46,(5,29,7)),(A*.65,(3,35,4)),(A,O)),
      'head':R((0,O),(A*.27,(-5,18,3)),(A*.46,(7,-15,-3)),(A,O)),
      'right_arm':R((0,O),(A*.26,(-40,-36,34)),(A*.45,(74,33,-45)),(A*.63,(59,18,-34)),(A,O)),
      'right_forearm':R((0,O),(A*.28,(-25,0,12)),(A*.48,(14,0,-16)),(A*.68,(4,0,-8)),(A,O)),
      'left_arm':R((0,O),(A*.28,(-8,0,-12)),(A*.5,(15,0,-17)),(A,O)),
      'root':P((0,O),(A*.27,(0,0,.35)),(A*.46,(0,0,-1.7 if adult else -1)),(A*.69,(0,0,-.9)),(A,O)),
      'tail':R((0,O),(A*.26,(0,24,0)),(A*.48,(0,-28,0)),(A*.7,(0,-13,0)),(A,O)),
      'tail_tip':R((0,O),(A*.35,(0,22,6)),(A*.6,(0,-24,-6)),(A,O)),
      'jaw':R((0,O),(A*.36,(13,0,0)),(A*.61,(7,0,0)),(A,O))}
    J=1.85 if adult else 1.42
    special={
      'root':P((0,O),(J*.19,O),(J*.36,(0,3.7 if adult else 2.7,0)),(J*.47,(0,4.1 if adult else 3.1,-.3)),(J*.6,O),(J*.68,(0,.35,0)),(J*.8,O),(J,O)),
      'body':R((0,O),(J*.18,(12,0,0)),(J*.4,(-14,0,0)),(J*.6,(21,0,0)),(J*.76,(-3,0,0)),(J,O)),
      'head':R((0,O),(J*.22,(-7,0,0)),(J*.45,(-10,0,0)),(J*.6,(12,0,0)),(J,O)),
      'left_arm':R((0,O),(J*.36,(-137,0,-17)),(J*.47,(-149,0,-15)),(J*.6,(77,0,-8)),(J*.75,(44,0,-8)),(J,O)),
      'right_arm':R((0,O),(J*.36,(-137,0,17)),(J*.47,(-149,0,15)),(J*.6,(77,0,8)),(J*.75,(44,0,8)),(J,O)),
      'left_forearm':R((0,O),(J*.4,(-30,0,0)),(J*.6,(16,0,0)),(J,O)),
      'right_forearm':R((0,O),(J*.4,(-30,0,0)),(J*.6,(16,0,0)),(J,O)),
      'left_shin':R((0,O),(J*.22,(24,0,0)),(J*.4,(32,0,0)),(J*.6,(21,0,0)),(J,O)),
      'right_shin':R((0,O),(J*.22,(24,0,0)),(J*.4,(32,0,0)),(J*.6,(21,0,0)),(J,O)),
      'tail':R((0,O),(J*.36,(-23,0,0)),(J*.6,(28,0,0)),(J,O)),
      'tail_mid':R((0,O),(J*.45,(-17,0,0)),(J*.7,(17,0,0)),(J,O)),
      'core':S((0,I),(J*.45,(1.2,1.2,1.2)),(J*.62,(.94,.94,.94)),(J*.82,I),(J,I))}
    H=.65 if adult else .5
    hurt={
      'root':P((0,O),(H*.26,(0,0,1.15)),(H*.6,(0,0,.7)),(H,O)),
      'body':R((0,O),(H*.26,(16,-7,-6)),(H*.55,(10,-3,-2)),(H,O)),
      'head':R((0,O),(H*.26,(-16,8,6)),(H,O)),
      'left_arm':R((0,O),(H*.25,(-11,0,-14)),(H,O)),
      'right_arm':R((0,O),(H*.25,(-20,0,17)),(H,O)),
      'tail':R((0,O),(H*.28,(0,-18,0)),(H,O)),
      'jaw':R((0,O),(H*.25,(11,0,0)),(H,O))}
    F=1.6 if adult else 1.22
    faint={
      'body':R((0,O),(F*.25,(0,0,-7)),(F*.56,(7,0,-26)),(F*.82,(5,0,-81)),(F,(5,0,-81))),
      'root':P((0,O),(F*.3,(0,-1,0)),(F*.67,(0,-5 if adult else -2.8,0)),(F*.85,(0,-12.2 if adult else -6.5,0)),(F,(0,-12.2 if adult else -6.5,0))),
      'head':R((0,O),(F*.4,(12,0,-6)),(F*.83,(17,0,5)),(F,(17,0,5))),
      'left_arm':R((0,O),(F*.72,(8,0,24)),(F,(8,0,24))),
      'right_arm':R((0,O),(F*.72,(0,0,-12)),(F,(0,0,-12))),
      'left_shin':R((0,O),(F*.5,(25,0,0)),(F,(25,0,0))),
      'right_shin':R((0,O),(F*.5,(29,0,0)),(F,(29,0,0))),
      'tail':R((0,O),(F*.75,(12,12,10)),(F,(12,12,10))),
      'tail_mid':R((0,O),(F*.8,(0,20,0)),(F,(0,20,0))),
      'tail_tip':R((0,O),(F*.8,(0,26,0)),(F,(0,26,0)))}
    m.animations={'idle':C(T,idle,True),'walk':C(W,walk,True),'attack':C(A,attack),'special':C(J,special),'hurt':C(H,hurt),'faint':C(F,faint)}
