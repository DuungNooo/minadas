"""Teumbi V4 — the face IS the suspended heart, wrapped in a broken meteor.

Three continuous asymmetric pieces form one oblique crescent silhouette.
There is no separate head, no pair of arm stones, and no centered foot.
Face marks are alpha-textured planes; their pigment, not their depth, acts.
"""


def build(m, stage=1):
    m.bone('core', (0, 6.9, -.35))
    m.bone('hood', (-1.7, 10.2, .7))
    m.bone('crescent', (3.3, 4.4, .7))
    m.bone('rear', (1.8, 7.5, 2.4))
    m.bone('orbit', (0, 6.8, .4))
    m.bone('eye_left', (-.92, 7.3, -1.69), parent='core')
    m.bone('eye_right', (.92, 7.3, -1.69), parent='core')

    def b(n, p, s, mat='stone', bone='hood', r=(0, 0, 0), pivot=None):
        m.box(n, p, s, mat, bone, rotation=r, pivot=pivot)

    # The living body is ONE connected amber crystal, about a third of the
    # full silhouette. Its little planar eyes never become another head.
    b('living_heart', (-1.8, 5.25, -1.65), (3.6, 3.6, 3.2), 'glow', 'core')
    b('heart_facet_l', (-2.15, 5.75, -1.3), (.7, 2.6, 2.5), 'hot', 'core', (0, 0, -15))
    b('heart_facet_r', (1.48, 5.8, -1.3), (.7, 2.5, 2.5), 'hot', 'core', (0, 0, 15))
    b('heart_crown_facet', (-1.35, 8.8, -1.05), (2.7, .45, 2.1), 'hot', 'core')
    b('heart_point', (-1.02, 4.65, -.95), (2.04, 1.15, 2.05), 'glow', 'core', (0, 0, 22))
    b('heart_eye_left', (-1.27, 6.84, -1.671), (.70, .93, 0), 'eye', 'eye_left', (0, 0, -3))
    b('heart_eye_right', (.57, 6.84, -1.671), (.70, .93, 0), 'eye', 'eye_right', (0, 0, 3))

    # Fragment A: one long dorsal hood, thick behind, concave in front. Long
    # oblique planes replace the former stack of wide rectangular hats.
    b('hood_left_sweep', (-6.0, 7.7, -.55), (2.05, 3.8, 4.3), 'stone', 'hood', (0, 0, -25))
    b('hood_long_brow', (-4.9, 10.0, -.4), (5.4, 1.9, 4.15), 'stone', 'hood', (0, 0, 18))
    b('hood_right_tip', (-.15, 10.65, .05), (3.5, 1.25, 3.5), 'stone', 'hood', (0, 0, -12))
    b('hood_rear_ridge', (-3.95, 10.55, 2.75), (4.8, 1.25, 1.05), 'dark', 'hood', (0, 0, 14))
    b('hood_left_outer_bevel', (-6.15, 8.25, .1), (.75, 2.3, 3.25), 'dark', 'hood', (0, 0, -25))
    b('hood_left_break', (-5.65, 7.05, .15), (1.35, 1.2, 2.85), 'stone', 'hood', (0, 0, -32))
    b('hood_brow_inner_fracture', (-4.3, 9.8, -.65), (4.5, .33, 3.0), 'fracture', 'hood', (0, 0, 18))
    b('hood_left_inner_fracture', (-4.45, 8.1, -.74), (.31, 2.0, 2.65), 'fracture', 'hood', (0, 0, -25))
    b('hood_right_fracture', (.02, 10.45, -.12), (2.7, .28, 2.7), 'fracture', 'hood', (0, 0, -12))
    b('offcenter_meteor_crest', (-3.3, 11.75, 1.1), (2.2, .9, 1.25), 'dark', 'hood', (0, 0, 22))
    b('hood_broken_front_edge', (-2.7, 10.48, -.72), (1.1, .5, .48), 'light', 'hood', (0, 0, 18))

    # Fragment B: a single deep crescent curling from the right shoulder of
    # the silhouette down and LEFT. It is not a matching hand or a pedestal.
    b('crescent_upper_sweep', (4.75, 6.05, -.45), (1.65, 3.0, 3.8), 'stone', 'crescent', (0, 0, -18))
    b('crescent_middle_sweep', (3.85, 3.45, -.65), (2.1, 3.6, 4.0), 'stone', 'crescent', (0, 0, -32))
    b('crescent_lower_sweep', (.75, 2.3, -.8), (4.6, 1.7, 3.65), 'stone', 'crescent', (0, 0, -16))
    b('crescent_left_point', (-1.65, 2.45, -.25), (3.05, .95, 2.8), 'stone', 'crescent', (0, 0, 12))
    b('crescent_outer_bevel', (4.8, 4.05, .3), (.65, 2.7, 2.65), 'dark', 'crescent', (0, 0, -32))
    b('crescent_bottom_bevel', (1.25, 1.98, -.1), (3.1, .55, 2.4), 'dark', 'crescent', (0, 0, -16))
    b('crescent_inner_high', (4.53, 6.3, -.63), (.32, 2.0, 2.8), 'fracture', 'crescent', (0, 0, -18))
    b('crescent_inner_mid', (3.55, 4.4, -.8), (.35, 2.15, 2.9), 'fracture', 'crescent', (0, 0, -32))
    b('crescent_inner_low', (.95, 3.88, -.85), (3.65, .28, 2.7), 'fracture', 'crescent', (0, 0, -16))
    b('crescent_point_fracture', (-1.5, 3.27, -.45), (2.2, .22, 2.2), 'fracture', 'crescent', (0, 0, 12))
    b('crescent_split_edge', (5.9, 7.65, .3), (.6, .85, 2), 'light', 'crescent', (0, 0, -18))

    # Fragment C: a shallow, diagonally fractured rear wedge bridges the
    # shell volume in side view while leaving the forward heart opening clear.
    b('rear_diagonal_wedge', (.75, 6.25, 2.6), (3.65, 3.55, 1.25), 'dark', 'rear', (0, 12, -24))
    b('rear_taper_lobe', (2.9, 7.0, 2.5), (1.5, 2.7, 1.1), 'stone', 'rear', (0, 12, -24))
    b('rear_fracture_edge', (.57, 6.4, 2.53), (.28, 2.8, .85), 'fracture', 'rear', (0, 12, -24))
    b('rear_lower_tooth', (1.6, 5.65, 2.6), (1.6, 1.1, 1.0), 'dark', 'rear', (0, 12, -24))

    # Just two chips; each extends the diagonal motion rather than outlining
    # a symmetric halo or becoming little hovering fists.
    b('small_leading_chip', (-6.65, 11.55, .75), (.65, .9, .8), 'stone', 'orbit', (5, 15, 25))
    b('small_trailing_chip', (-3.25, 2.15, .2), (.8, .55, .75), 'stone', 'orbit', (10, -12, -20))


def animate(m):
    """Six character actions, all centred on the living heart and shell lag."""
    z = [0, 0, 0]
    one = [1, 1, 1]
    def clip(duration, bones, loop=False):
        return {'loop': loop, 'animation_length': duration, 'bones': bones}
    blink = {'0':one, '2.12':one, '2.18':[1,.10,1], '2.29':one,
             '3.85':one, '3.91':[1,.16,1], '4.03':one, '4.8':one}
    m.animations = {
        'idle': clip(4.8, {
            'root': {'position': {'0':z, '1.3':[0,.30,0], '2.5':[0,.08,0], '3.6':[0,.42,0], '4.8':z}},
            'core': {'rotation': {'0':[0,-3,-3], '1.2':[0,4,2], '2.6':[0,1,-1], '3.5':[0,-4,2], '4.8':[0,-3,-3]},
                     'scale': {'0':one, '1.2':[1.025,1.025,1.025], '2.4':one, '3.6':[1.025,1.025,1.025], '4.8':one}},
            'hood': {'rotation': {'0':z, '1.65':[0,-3,-2], '3.2':[0,2,1.5], '4.8':z}},
            'crescent': {'position': {'0':z, '1.95':[.09,-.08,0], '3.65':[-.06,.09,0], '4.8':z}},
            'rear': {'rotation': {'0':z, '2':[0,3,-2], '4.8':z}},
            'orbit': {'rotation': {'0':z, '2.4':[0,9,4], '4.8':z}},
            'eye_left': {'scale': blink}, 'eye_right': {'scale': blink},
        }, True),
        'walk': clip(1.4, {
            'root': {'position': {'0':z, '.35':[0,.35,-.12], '.7':[0,.08,.12], '1.05':[0,.28,-.08], '1.4':z},
                     'rotation': {'0':[5,0,-2], '.4':[8,0,2], '.9':[5,0,-2], '1.4':[5,0,-2]}},
            'core': {'rotation': {'0':[-3,0,0], '.5':[1,0,-1], '1.4':[-3,0,0]}},
            'hood': {'position': {'0':[0,0,.1], '.4':[0,-.14,.3], '.9':[0,.1,0], '1.4':[0,0,.1]}},
            'crescent': {'rotation': {'0':[0,0,-3], '.55':[0,0,3], '1.4':[0,0,-3]}},
            'rear': {'position': {'0':z, '.5':[0,0,.25], '1.4':z}},
        }, True),
        'attack': clip(1.1, {
            'root': {'position': {'0':z, '.2':[0,-.2,.7], '.34':[0,.1,-2.7], '.48':[0,.1,-2.5], '.75':[0,.2,.2], '1.1':z}},
            'core': {'rotation': {'0':z, '.2':[-7,0,0], '.4':[10,0,0], '.7':[-3,0,0], '1.1':z}},
            'hood': {'position': {'0':z, '.19':[.25,-.45,-.2], '.42':[-.15,.45,.2], '1.1':z}},
            'crescent': {'position': {'0':z, '.19':[-.4,.3,-.1], '.42':[.35,-.4,.2], '1.1':z}},
            'rear': {'rotation': {'0':z, '.2':[0,-8,0], '.42':[0,7,0], '1.1':z}},
        }),
        'special': clip(2.5, {
            'root': {'position': {'0':z, '.5':[0,.35,0], '1.25':[0,.8,0], '1.9':[0,.4,0], '2.5':z}},
            'core': {'scale': {'0':one, '.45':[.87,.87,.87], '.78':[1.20,1.20,1.20], '1.05':[1.04,1.04,1.04], '1.33':[1.19,1.19,1.19], '1.8':[1.03,1.03,1.03], '2.5':one}},
            'hood': {'position': {'0':z, '.6':[-.55,.7,.15], '1.5':[-.6,.75,.2], '2.5':z},
                     'rotation': {'0':z, '.6':[0,-9,-7], '1.5':[0,-10,-8], '2.5':z}},
            'crescent': {'position': {'0':z, '.6':[.65,-.5,.15], '1.5':[.7,-.5,.2], '2.5':z},
                         'rotation': {'0':z, '.6':[0,7,7], '1.5':[0,8,8], '2.5':z}},
            'rear': {'position': {'0':z, '.6':[.15,0,.6], '1.5':[.15,0,.7], '2.5':z}},
            'orbit': {'rotation': {'0':z, '.8':[0,18,8], '1.6':[0,27,10], '2.5':z}},
        }),
        'hurt': clip(.8, {
            'root': {'position': {'0':z, '.12':[0,.1,.7], '.3':[0,0,.3], '.8':z},
                     'rotation': {'0':z, '.12':[-9,0,7], '.32':[3,0,-2], '.8':z}},
            'core': {'rotation': {'0':z, '.15':[0,0,-8], '.8':z}},
            'hood': {'position': {'0':z, '.18':[.25,-.2,0], '.8':z}},
            'crescent': {'position': {'0':z, '.18':[-.25,.2,0], '.8':z}},
            'eye_left': {'scale': {'0':one, '.12':[1,.12,1], '.48':[1,.12,1], '.8':one}},
            'eye_right': {'scale': {'0':one, '.12':[1,.12,1], '.48':[1,.12,1], '.8':one}},
        }),
        'faint': clip(1.8, {
            'root': {'position': {'0':z, '.6':[0,-.75,0], '1.3':[0,-.85,0], '1.8':[0,-.85,0]}},
            'core': {'position': {'0':z, '.7':[0,-.55,.1], '1.8':[0,-.55,.1]},
                     'rotation': {'0':z, '.7':[0,0,12], '1.8':[0,0,12]},
                     'scale': {'0':one, '.8':[.78,.78,.78], '1.8':[.78,.78,.78]}},
            'hood': {'position': {'0':z, '.9':[-.3,-.8,.2], '1.8':[-.3,-.8,.2]},
                     'rotation': {'0':z, '.9':[0,-5,-12], '1.8':[0,-5,-12]}},
            'crescent': {'position': {'0':z, '.9':[.3,-.7,.2], '1.8':[.3,-.7,.2]},
                         'rotation': {'0':z, '.9':[0,5,12], '1.8':[0,5,12]}},
            'rear': {'position': {'0':z, '.9':[0,-.75,.15], '1.8':[0,-.75,.15]}},
            'eye_left': {'scale': {'0':one, '.5':[1,.10,1], '1.8':[1,.10,1]}},
            'eye_right': {'scale': {'0':one, '.5':[1,.10,1], '1.8':[1,.10,1]}},
        }),
    }
