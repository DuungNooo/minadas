"""Original ember construct: a juvenile cleaver and a mature twin-axe breaker.

The chest is deliberately an empty cage around one suspended core.  Axes are
forearms/hands, not accessories held by otherwise human hands.
"""


def build(m, stage):
    if stage == 2:
        return _juvenile(m)
    return _breaker(m)


def _juvenile(m):
    m.bone('body', pivot=(0, 12, 0))
    m.bone('core', pivot=(0, 14.1, 0), parent='body')
    m.bone('head', pivot=(0, 18, 0), parent='body')
    for s, side in [(-1, 'left'), (1, 'right')]:
        m.bone(side + '_arm', pivot=(s * 5.7, 16.8, 0), parent='body')
        m.bone(side + '_leg', pivot=(s * 2.2, 8.9, 0), parent='body')

    def b(n, xyz, whd, mat='stone', bone='body', rot=(0, 0, 0), pivot=None):
        m.box(n, origin=xyz, size=whd, material=mat, bone=bone,
              rotation=rot, pivot=pivot)

    # An almost circular broken stone collar with the core clearly exposed.
    b('chest_top_bridge', (-3.7, 16.5, -1.9), (7.4, 1.2, 3.8), 'dark')
    b('collar_front_edge', (-2.8, 16.3, -2.2), (5.6, .6, .6), 'trim')
    b('waist_ring', (-3.3, 10.7, -1.7), (6.6, 1.7, 3.4), 'stone')
    b('waist_ember', (-1.8, 11.05, -1.95), (3.6, .55, .3), 'hot')
    b('lower_abdomen', (-2.4, 8.7, -.9), (4.8, 1.8, 2.5), 'dark')
    b('belt_center', (-1.25, 9.4, -1.4), (2.5, .8, .6), 'metal')
    b('heart', (-1.35, 12.7, -1.35), (2.7, 2.7, 2.7), 'glow', 'core')
    b('heart_front_center', (-.65, 13.35, -1.42), (1.3, 1.3, .15), 'hot', 'core')
    for s in [-1, 1]:
        b('rib_' + str(s), (s * 3.4 - .55, 12.4, -.95), (1.1, 3.6, 2.7), 'stone', rot=(0, 0, s * 8), pivot=(s * 3.4, 14.2, .4))
        b('rib_ember_' + str(s), (s * 3.4 - .23, 13, -1.08), (.46, 2, .25), 'accent')
        b('hip_plate_' + str(s), (s * 2.4 - 1.3, 8.1, -1.8), (2.6, 2, 3.6), 'stone')

    # Young helmet has a soft broad face and only small budding horns.
    b('neck', (-1, 17.6, -.8), (2, .9, 1.6), 'dark', 'head')
    b('helmet_main', (-2.7, 18.5, -2), (5.4, 3.4, 4), 'stone', 'head')
    b('helmet_top', (-2.2, 21.9, -1.7), (4.4, .7, 3.4), 'dark', 'head')
    b('face_recess', (-2, 19.05, -2.13), (4, 1.65, .22), 'dark', 'head')
    b('jaw', (-1.9, 18.05, -2.1), (3.8, .65, 3.6), 'metal', 'head')
    b('nose_ridge', (-.3, 19.1, -2.42), (.6, 1.6, .45), 'stone', 'head')
    for s in [-1, 1]:
        b('eye_' + str(s), (s * 1.15 - .5, 19.45, -2.27), (1, .6, .18), 'eye', 'head')
        b('brow_' + str(s), (s * 1.3 - .95, 20.45, -2.4), (1.9, .65, .55), 'dark', 'head', (0, 0, -s * 7), (s * 1.3, 20.7, -2.1))
        b('horn_bud_' + str(s), (s * 1.8 - .5, 22.45, -.6), (1, 1.2, 1.2), 'dark', 'head')
        b('horn_tip_' + str(s), (s * 1.8 - .3, 23.5, -.4), (.6, .4, .8), 'hot', 'head')

    for s, side in [(-1, 'left'), (1, 'right')]:
        arm = side + '_arm'
        leg = side + '_leg'
        x = s * 5.7
        b(side + '_shoulder_inner', (x - 1.2, 15.3, -1.15), (2.4, 2.7, 2.3), 'dark', arm)
        b(side + '_pauldron', (x - 1.8, 16.5, -1.8), (3.6, 2.4, 3.6), 'stone', arm)
        b(side + '_pauldron_top', (x - 1.45, 18.8, -1.4), (2.9, .7, 2.8), 'dark', arm)
        b(side + '_shoulder_ember', (x - 1.15, 16.6, -1.93), (2.3, .35, .16), 'hot', arm)
        b(side + '_upper_arm', (x - .9, 12.4, -.9), (1.8, 2.4, 1.8), 'metal', arm)
        b(side + '_elbow', (x - 1.1, 11.1, -1), (2.2, 1, 2), 'dark', arm)
        b(side + '_axe_socket', (x - 1.2, 8.5, -1.2), (2.4, 2.2, 2.4), 'stone', arm)
        b(side + '_socket_hot', (x - .7, 9.1, -1.36), (1.4, .65, .18), 'hot', arm)
        # Its axe already has a swept edge and a little hooked beard; the notch
        # under the wrist must read as an axe rather than a rectangular glove.
        for j, (yy, hh, inner, outer) in enumerate([
                (11.7, .8, .9, 2.3), (10.9, .8, .5, 3.2),
                (10.1, .8, .4, 3.8), (9.3, .8, .8, 4.1),
                (8.5, .8, 1.3, 4.1), (7.7, .8, 1.8, 3.8),
                (6.9, .8, 1.8, 3.2), (6.1, .8, 1.8, 2.5)]):
            left = min(x + s * inner, x + s * outer)
            b(side + '_young_axe_' + str(j), (left, yy, -1.4),
              (outer-inner, hh, 2.4), 'metal', arm)
            edge_x = x + s * outer - (.45 if s < 0 else 0)
            b(side + '_young_edge_' + str(j), (edge_x, yy, -1.6),
              (.45, hh, 2.8), 'hot', arm)
        # Short grounded legs; the knee and boot stay visibly separate.
        lx = s * 2.2
        b(side + '_thigh', (lx - 1.1, 5.5, -.9), (2.2, 2.5, 2), 'metal', leg)
        b(side + '_knee', (lx - 1.3, 4.2, -1.5), (2.6, 1.35, 2.8), 'stone', leg)
        b(side + '_shin', (lx - 1.1, 1.9, -.8), (2.2, 2.1, 2.1), 'dark', leg)
        b(side + '_boot', (lx - 1.55, .3, -2), (3.1, 1.6, 4), 'stone', leg)
        b(side + '_toe', (lx - 1.35, .4, -2.3), (2.7, .8, .6), 'metal', leg)
        b(side + '_knee_crack', (lx - .2, 4.6, -1.65), (.4, .6, .2), 'hot', leg)


def _breaker(m):
    m.bone('body', pivot=(0, 20, 0))
    m.bone('core', pivot=(0, 24, -.2), parent='body')
    m.bone('head', pivot=(0, 29.8, 0), parent='body')
    for s, side in [(-1, 'left'), (1, 'right')]:
        m.bone(side + '_arm', pivot=(s * 8.6, 27, .1), parent='body')
        m.bone(side + '_leg', pivot=(s * 3.1, 15, .2), parent='body')

    def b(n, xyz, whd, mat='stone', bone='body', rot=(0, 0, 0), pivot=None):
        m.box(n, origin=xyz, size=whd, material=mat, bone=bone,
              rotation=rot, pivot=pivot)

    # Broad open chest cage: no solid breastplate blocking the single core.
    b('collar_bridge', (-5.4, 27.2, -2.5), (10.8, 1.8, 5), 'dark')
    b('collar_hot_inner', (-3.5, 27.02, -2.76), (7, .45, .35), 'hot')
    b('collar_upper', (-4, 29.05, -1.9), (8, .8, 4), 'stone')
    b('waist_block', (-4.8, 18.2, -2), (9.6, 2.7, 4.5), 'dark')
    b('waist_front_rim', (-4.3, 20.25, -2.5), (8.6, .8, .8), 'metal')
    b('waist_ember_seam', (-3.6, 19.05, -2.58), (7.2, .55, .18), 'hot')
    b('heart', (-2.05, 22, -2.05), (4.1, 4.1, 4.1), 'glow', 'core')
    b('heart_front', (-1.2, 22.85, -2.18), (2.4, 2.4, .22), 'hot', 'core')
    b('heart_highlight', (-.5, 23.55, -2.32), (1, 1, .18), 'eye', 'core')
    b('back_furnace', (-3.7, 22, 2.45), (7.4, 5, 1.3), 'dark')
    for s in [-1, 1]:
        b('side_rib_' + str(s), (s * 4.65 - .85, 21.35, -1.7), (1.7, 5.1, 4.5), 'stone', rot=(0, 0, s * 10), pivot=(s * 4.65, 23.8, .4))
        b('rib_lava_' + str(s), (s * 4.35 - .35, 22.3, -2.06), (.7, 3, .3), 'accent')
        b('hip_joint_' + str(s), (s * 3.05 - 1.65, 14.5, -1.15), (3.3, 3, 3.5), 'metal')
        b('hip_guard_' + str(s), (s * 4.2 - 1.45, 15.5, -2), (2.9, 3.6, 4.8), 'stone', rot=(0, 0, s * 12), pivot=(s * 4.2, 18.5, .4))
    b('belt_furnace', (-1.8, 16.7, -2.8), (3.6, 2.1, 1.2), 'metal')
    b('belt_hot_slit', (-1.1, 17.4, -2.93), (2.2, .6, .2), 'hot')
    b('loin_guard', (-1.8, 13.8, -2.3), (3.6, 2.7, .9), 'dark')

    # Heavy samurai-like crag helmet; glowing slit eyes remain the face focus.
    b('neck', (-1.35, 29.1, -1.2), (2.7, 1.3, 2.4), 'metal', 'head')
    b('helmet_skull', (-3.6, 30.25, -2.7), (7.2, 5.2, 5.4), 'stone', 'head')
    b('helmet_crown', (-2.9, 35.35, -2.15), (5.8, 1, 4.3), 'dark', 'head')
    b('face_dark', (-2.8, 31, -2.83), (5.6, 2.6, .2), 'dark', 'head')
    b('face_center_crest', (-.5, 31.9, -3.3), (1, 4.3, .7), 'metal', 'head')
    b('chin', (-2.4, 29.75, -2.75), (4.8, 1.25, 4.5), 'dark', 'head')
    b('mouth_ember', (-1.2, 30.2, -2.91), (2.4, .4, .2), 'accent', 'head')
    for s in [-1, 1]:
        b('eye_' + str(s), (s * 1.65 - .8, 32.05, -3.01), (1.6, .7, .22), 'eye', 'head')
        b('angry_brow_' + str(s), (s * 1.75 - 1.2, 33.1, -3.31), (2.4, .85, .65), 'dark', 'head', (0, 0, -s * 11), (s * 1.75, 33.45, -3))
        b('cheek_' + str(s), (s * 3.0 - .65, 30.5, -2.95), (1.3, 2.4, 1.1), 'metal', 'head')
        b('horn_base_' + str(s), (s * 2.5 - .8, 35.6, -.65), (1.6, 1.7, 1.7), 'stone', 'head')
        b('horn_outer_' + str(s), (s * 3.25 - .65, 36.7, -.45), (1.3, 2.7, 1.3), 'dark', 'head', (0, 0, -s * 16), (s * 3.25, 36.7, .2))
        b('horn_tip_' + str(s), (s * 3.8 - .4, 39, -.25), (.8, 1, .9), 'hot', 'head')

    for s, side in [(-1, 'left'), (1, 'right')]:
        arm=side+'_arm'; leg=side+'_leg'; x=s*8.6; lx=s*3.1
        b(side+'_shoulder_joint', (x-1.65,24.8,-1.65), (3.3,3.8,3.3), 'metal',arm)
        b(side+'_pauldron_body', (x-2.7,26.5,-3), (5.4,4,6), 'stone',arm)
        b(side+'_pauldron_cap', (x-2.3,30.5,-2.6), (4.6,1.2,5.2), 'dark',arm)
        b(side+'_pauldron_lower', (x-2.3,25.5,-2.75), (4.6,1,5.5), 'dark',arm)
        b(side+'_pauldron_hot', (x-1.8,26.05,-2.96), (3.6,.45,.3), 'hot',arm)
        b(side+'_pauldron_front_plate', (x-1.8,27.25,-3.3), (3.6,2.3,.6), 'dark',arm)
        b(side+'_pauldron_corner', (x+s*2.35-.6,28.6,-1.9), (1.2,2.5,3.8), 'metal',arm, (0,0,-s*16),(x+s*2.35,28.6,0))
        b(side+'_upper_arm', (x-1.3,21.65,-1.3), (2.6,2.8,2.6), 'dark',arm)
        b(side+'_upper_front_plate', (x-1.65,22,-1.7), (3.3,2,1), 'stone',arm)
        b(side+'_elbow_joint', (x-1.1,20,-1.15), (2.2,1.2,2.3), 'metal',arm)
        b(side+'_forearm_furnace', (x-1.75,15.1,-1.7), (3.5,4.4,3.4), 'stone',arm)
        b(side+'_forearm_dark_panel', (x-1.15,15.7,-1.94), (2.3,2.9,.5), 'dark',arm)
        b(side+'_forearm_slit', (x-.3,16.05,-2.17), (.6,2.2,.18), 'hot',arm)
        b(side+'_blade_socket', (x-1.8,13.4,-1.6), (3.6,1.4,3.2), 'metal',arm)
        # Swept bearded axe, grown directly from the wrist.  The stepped polygon
        # is convex outside and deeply concave under the wrist inside: empty
        # space remains under its neck, so it cannot read as a tower shield.
        rows=[
            (19.8,.9,3.0,4.1), (18.9,.9,1.5,5.4),
            (18.0,.9,.8,6.3), (16.8,1.2,.5,7.1),
            (15.6,1.2,.8,7.7), (14.4,1.2,1.5,8.0),
            (13.2,1.2,2.3,8.0), (12.0,1.2,3.0,7.7),
            (10.8,1.2,3.2,7.1), (9.6,1.2,3.2,6.4),
            (8.4,1.2,3.2,5.5), (7.2,1.2,3.2,4.3)]
        for j,(yy,hh,inner,outer) in enumerate(rows):
            left=min(x+s*inner,x+s*outer)
            span=outer-inner
            b(side+'_axe_mass_'+str(j),(left,yy,-1.35),(span,hh,2.7),'dark',arm)
            # Recessed steel face, kept thinner than the structural blade.
            b(side+'_axe_face_'+str(j),(left+.08,yy+.03,-1.73),(span-.16,hh-.06,.4),'metal',arm)
            edge_x=x+s*outer-(.55 if s<0 else 0)
            b(side+'_axe_edge_'+str(j),(edge_x,yy,-1.85),(.55,hh,3.2),'hot',arm)
        # Armour layers keep the massive fighter grounded.
        b(side+'_thigh',(lx-1.55,10.6,-1.25),(3.1,3.2,3),'dark',leg)
        b(side+'_thigh_front',(lx-1.8,11,-1.8),(3.6,2.7,1),'stone',leg)
        b(side+'_knee',(lx-1.9,8.9,-2.1),(3.8,1.7,3.9),'metal',leg)
        b(side+'_knee_ember',(lx-.65,9.4,-2.26),(1.3,.55,.2),'hot',leg)
        b(side+'_shin',(lx-1.45,4.3,-1.1),(2.9,4,3),'dark',leg)
        b(side+'_shin_plate',(lx-1.65,4.9,-1.7),(3.3,3.1,.9),'stone',leg)
        b(side+'_boot',(lx-2,1,-2.5),(4,3.1,5.3),'stone',leg)
        b(side+'_heel',(lx-1.7,.5,.6),(3.4,1,2.4),'dark',leg)
        b(side+'_toe',(lx-1.85,.7,-3.1),(3.7,1.5,1),'metal',leg)
        b(side+'_toe_seam',(lx-.3,.85,-3.26),(.6,.9,.2),'accent',leg)
