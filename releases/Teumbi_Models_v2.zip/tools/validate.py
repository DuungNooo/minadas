#!/usr/bin/env python3
"""Validate model/UV/animation parity without depending on Blockbench or Blender.

Usage: python validate.py [pack-directory]
The checks establish structural consistency; they do not claim game validation.
"""
import argparse
import base64
from collections import Counter
import io
import json
import math
from pathlib import Path
import sys

from PIL import Image


FACES = {'north', 'south', 'east', 'west', 'up', 'down'}


class InvalidModel(Exception):
    pass


def require(condition, message):
    if not condition:
        raise InvalidModel(message)


def unique(items, label):
    duplicate = [key for key, count in Counter(items).items() if count > 1]
    require(not duplicate, f'duplicate {label}: {duplicate[:5]}')


def vector(value, length=3):
    return isinstance(value, list) and len(value) == length and all(
        isinstance(x, (int, float)) and math.isfinite(x) for x in value)


def same(a, b, label):
    require(len(a) == len(b) and all(abs(x-y) < 1e-5 for x, y in zip(a, b)),
            f'{label}: {a!r} differs from {b!r}')


def flip_pivot(value):
    """Bedrock codec mirrors X relative to Blockbench editor space."""
    return [-value[0], value[1], value[2]]


def flip_rotation(value):
    return [-value[0], -value[1], value[2]]


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f'duplicate JSON key: {key}')
        result[key] = value
    return result


def read_json(path):
    return json.loads(path.read_text(encoding='utf8'), object_pairs_hook=no_duplicate_keys)


def validate_model(pack, path):
    name = path.name.removesuffix('.geo.json')
    bb = read_json(pack/'blockbench'/f'{name}.bbmodel')
    geometry_file = read_json(path)
    require(len(geometry_file['minecraft:geometry']) == 1, 'expected one geometry')
    geo = geometry_file['minecraft:geometry'][0]
    desc = geo['description']
    require(desc['identifier'] == f'geometry.{name}', 'geometry identifier mismatch')
    width, height = desc['texture_width'], desc['texture_height']
    require(isinstance(width, int) and isinstance(height, int) and min(width, height) > 0,
            'invalid atlas resolution')
    require(bb['resolution'] == {'width': width, 'height': height}, 'BB atlas resolution mismatch')
    png = pack/'textures'/f'{name}.png'
    with Image.open(png) as image:
        require(image.size == (width, height), 'PNG/geometry size mismatch')
        image.verify()
    emissive = pack/'textures'/f'{name}_emissive.png'
    require(emissive.is_file(), 'missing emissive atlas')
    with Image.open(emissive) as image:
        require(image.size == (width, height), 'emissive atlas size mismatch')
        image.verify()
    require(len(bb['textures']) == 1, 'expected one embedded texture')
    texture = bb['textures'][0]
    require((texture['width'], texture['height']) == (width, height), 'BB texture dimensions mismatch')
    data_url = texture['source']
    require(data_url.startswith('data:image/png;base64,'), 'missing embedded PNG')
    embedded = base64.b64decode(data_url.split(',', 1)[1], validate=True)
    require(embedded == png.read_bytes(), 'embedded texture differs from external PNG')

    bones = geo['bones']
    bone_names = [b['name'] for b in bones]
    unique(bone_names, 'bone names')
    lookup = {b['name']: b for b in bones}
    roots = [b for b in bones if not b.get('parent')]
    require(len(roots) == 1 and roots[0]['name'] == 'root', 'invalid root bone')
    for bone in bones:
        require(vector(bone['pivot']), f'{bone["name"]}: invalid bone pivot')
        require(vector(bone.get('rotation', [0, 0, 0])), 'invalid bone rotation')
        seen = set()
        current = bone
        while current.get('parent'):
            require(current['name'] not in seen, f'bone hierarchy cycle at {current["name"]}')
            seen.add(current['name'])
            require(current['parent'] in lookup, f'missing parent {current["parent"]}')
            current = lookup[current['parent']]

    elements = bb['elements']
    unique([e['name'] for e in elements], 'cube names')
    unique([e['uuid'] for e in elements], 'cube UUIDs')
    element_by_id = {e['uuid']: e for e in elements}
    require(len(elements) == sum(len(b.get('cubes', [])) for b in bones), 'BB/geometry cube count mismatch')
    groups = {}
    parents = {}
    children_by_group = {}
    referenced = []

    def walk(group, parent=None):
        n = group['name']
        require(n not in groups, f'duplicate BB group {n}')
        groups[n] = group
        parents[n] = parent
        children_by_group[n] = []
        for child in group['children']:
            if isinstance(child, str):
                require(child in element_by_id, f'unknown element reference {child}')
                referenced.append(child)
                children_by_group[n].append(element_by_id[child])
            else:
                require(isinstance(child, dict), 'invalid outliner child')
                walk(child, n)

    require(len(bb['outliner']) == 1, 'expected one BB root group')
    walk(bb['outliner'][0])
    unique(referenced, 'outliner cube references')
    require(set(referenced) == set(element_by_id), 'unreferenced BB cube')
    require(set(groups) == set(lookup), 'BB/geometry bone set mismatch')

    occupied = bytearray(width * height)
    face_count = 0
    for bone in bones:
        bn = bone['name']; group = groups[bn]
        require(parents[bn] == bone.get('parent'), f'{bn}: parent mismatch')
        same(group['origin'], flip_pivot(bone['pivot']), f'{bn}: bone pivot')
        same(group.get('rotation', [0,0,0]), flip_rotation(bone.get('rotation', [0,0,0])), f'{bn}: bone rotation')
        geo_cubes = bone.get('cubes', [])
        bb_cubes = children_by_group[bn]
        require(len(geo_cubes) == len(bb_cubes), f'{bn}: per-bone cube count mismatch')
        for index, (cube, element) in enumerate(zip(geo_cubes, bb_cubes)):
            label = f'{bn}/{element["name"]}'
            require(element.get('type') == 'cube', f'{label}: invalid element type')
            require(vector(cube['origin']) and vector(cube['size']), f'{label}: invalid bounds')
            require(min(cube['size']) > 0, f'{label}: nonpositive size')
            require(vector(element['from']) and vector(element['to']), f'{label}: invalid BB bounds')
            require(all(b > a for a,b in zip(element['from'], element['to'])), f'{label}: nonpositive BB bounds')
            canonical_origin=[-(cube['origin'][0]+cube['size'][0]), cube['origin'][1], cube['origin'][2]]
            same(canonical_origin, element['from'], f'{label}: origin')
            same(cube['size'], [b-a for a,b in zip(element['from'], element['to'])], f'{label}: size')
            same(flip_rotation(cube.get('rotation', [0,0,0])), element.get('rotation', [0,0,0]), f'{label}: rotation')
            if any(cube.get('rotation', [0,0,0])):
                require(vector(cube.get('pivot')), f'{label}: missing rotation pivot')
                same(flip_pivot(cube['pivot']), element['origin'], f'{label}: cube pivot')
            require(set(cube['uv']) == FACES and set(element['faces']) == FACES, f'{label}: missing face')
            for face in sorted(FACES):
                face_count += 1
                uv = cube['uv'][face]
                require(vector(uv['uv'], 2) and vector(uv['uv_size'], 2), f'{label}: invalid UV')
                x,y = uv['uv'];w,h = uv['uv_size']
                require(w != 0 and h != 0, f'{label}: zero UV size')
                if face in {'up','down'}:
                    require(w<0 and h<0, f'{label}/{face}: missing Bedrock top/bottom UV reversal')
                else:
                    require(w>0 and h>0, f'{label}/{face}: unexpected UV reversal')
                x0,y0,x1,y1=min(x,x+w),min(y,y+h),max(x,x+w),max(y,y+h)
                require(x0 >= 0 and y0 >= 0 and x1 <= width and y1 <= height,
                        f'{label}/{face}: UV outside atlas')
                require(all(v == int(v) for v in (x,y,w,h)), f'{label}: fractional pixel bounds')
                euv = element['faces'][face]
                same([x0,y0,x1,y1], euv['uv'], f'{label}/{face}: BB UV')
                require(euv['texture'] == 0, f'{label}: bad texture index')
                x,y,w,h = map(int,(x0,y0,x1-x0,y1-y0))
                for row in range(y,y+h):
                    start=row*width+x
                    require(not any(occupied[start:start+w]), f'{label}/{face}: overlapping UV island')
                    occupied[start:start+w] = b'\x01'*w

    exported = read_json(pack/'animations'/f'{name}.animation.json')['animations']
    embedded_anims = bb['animations']
    unique([a['name'] for a in embedded_anims], 'animation names')
    require(set(exported) == {a['name'] for a in embedded_anims}, 'animation names differ')
    require(len(exported) >= 3, 'expected idle, walk, action animations')
    uuid_to_bone = {g['uuid']: n for n,g in groups.items()}
    uuid_set = [e['uuid'] for e in elements] + list(uuid_to_bone) + [texture['uuid']]
    key_count = 0
    for anim in embedded_anims:
        uuid_set.append(anim['uuid'])
        counterpart = exported[anim['name']]
        length=counterpart['animation_length']
        require(isinstance(length,(int,float)) and math.isfinite(length) and length>0, 'invalid animation length')
        require(abs(anim['length']-length)<1e-6, 'animation length differs')
        require(anim['loop'] == ('loop' if counterpart['loop'] else 'once'), 'animation loop differs')
        require(set(counterpart['bones']) <= set(lookup), 'animation references unknown bone')
        require(set(anim['animators']) <= set(uuid_to_bone), 'embedded animator references unknown UUID')
        animated_names = {uuid_to_bone[u] for u in anim['animators']}
        require(animated_names == set(counterpart['bones']), 'embedded/exported animated bones differ')
        for bone_uuid, animator in anim['animators'].items():
            bn=uuid_to_bone[bone_uuid]
            require(animator['name'] == bn and animator['type']=='bone', 'animator name/type mismatch')
            require(animator['keyframes'], f'{anim["name"]}/{bn}: no embedded keys')
            expected={}
            for channel,frames in counterpart['bones'][bn].items():
                require(channel in {'rotation','position','scale'}, 'unsupported animation channel')
                for time,values in frames.items():
                    t=float(time)
                    require(math.isfinite(t) and 0<=t<=length+1e-6, 'exported keyframe outside animation')
                    require(vector(values), 'invalid exported keyframe vector')
                    expected[(channel,t)] = values
            actual={}
            for frame in animator['keyframes']:
                key_count += 1;uuid_set.append(frame['uuid'])
                t=frame['time'];channel=frame['channel']
                require(isinstance(t,(int,float)) and math.isfinite(t) and 0<=t<=length+1e-6,
                        'embedded keyframe outside animation')
                require((channel,t) not in actual, 'duplicate channel/time keyframe')
                require(len(frame['data_points'])==1, 'expected one linear data point')
                point=frame['data_points'][0]
                values=[float(point[k]) for k in ('x','y','z')]
                require(vector(values), 'invalid embedded keyframe vector')
                actual[(channel,t)] = values
            require(set(actual)==set(expected), 'embedded/exported channel/time keys differ')
            for key in expected:
                same(actual[key], expected[key], f'{anim["name"]}/{bn}/{key}: keyframe')
    unique(uuid_set, 'model UUIDs')
    return dict(name=name,cubes=len(elements),bones=len(bones),faces=face_count,
                atlas=f'{width}x{height}',animations=len(exported),keyframes=key_count)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pack', nargs='?', type=Path, default=Path(__file__).parent/'pack')
    args=parser.parse_args();pack=args.pack
    paths=sorted((pack/'models').glob('*.geo.json'))
    try:
        require(len(paths)==9, f'expected 9 geometries, found {len(paths)}')
        names={p.name.removesuffix('.geo.json') for p in paths}
        require(names=={p.stem for p in (pack/'blockbench').glob('*.bbmodel')}, 'model filename sets differ')
        require(names=={p.name.removesuffix('.animation.json') for p in (pack/'animations').glob('*.animation.json')},
                'animation filename sets differ')
    except InvalidModel as error:
        print(f'FAIL: {error}');return 1
    rows=[];failed=0
    for path in paths:
        try:
            row=validate_model(pack,path);rows.append(row)
            print(f'PASS {row["name"]}: {row["cubes"]} cubes, {row["bones"]} bones, '
                  f'{row["faces"]} unique UV faces, {row["atlas"]}, {row["keyframes"]} keys')
        except (InvalidModel,KeyError,ValueError,TypeError,OSError) as error:
            failed+=1;print(f'FAIL {path.name}: {error}')
    if failed:
        print(f'Validation failed: {failed}/{len(paths)} models');return 1
    print(f'PASS all {len(rows)} models: {sum(r["cubes"] for r in rows)} cubes, '
          f'{sum(r["faces"] for r in rows)} nonoverlapping UV islands, '
          f'{sum(r["animations"] for r in rows)} matching embedded/exported animations')
    print('Structural checks only; Blockbench UI and Minecraft runtime validation are separate.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
