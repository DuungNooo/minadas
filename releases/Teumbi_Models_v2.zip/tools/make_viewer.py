"""Build a genuinely offline WebGL asset viewer: no CDN, no fetch, no server."""
import base64
import json
from pathlib import Path

ROOT = Path(__file__).parent
PACK = ROOT / 'pack'


def main():
    models=[]
    for f in sorted((PACK/'source').glob('*.json')):
        data=json.loads(f.read_text())
        png=(PACK/'textures'/(data['name']+'.png')).read_bytes()
        data['image']='data:image/png;base64,'+base64.b64encode(png).decode()
        data['animations']=json.loads((PACK/'animations'/(data['name']+'.animation.json')).read_text())['animations']
        # Source geometry uses Blockbench axes; exported runtime keyframes use
        # Bedrock axes. Reverse the codec signs for the canonical viewer.
        for animation in data['animations'].values():
            for channels in animation['bones'].values():
                for channel,frames in channels.items():
                    for time,vec in frames.items():
                        if channel=='rotation':frames[time]=[-vec[0],-vec[1],vec[2]]
                        elif channel=='position':frames[time]=[-vec[0],vec[1],vec[2]]
        models.append(data)
    payload=json.dumps(models,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    page=HTML.replace('__MODEL_DATA__',payload)
    (PACK/'VIEW_MODELS.html').write_text(page,encoding='utf8')
    # Convenient syntax-check target, not needed by the finished HTML.
    (ROOT/'viewer-check.js').write_text(page.split('<script>')[1].split('</script>')[0],encoding='utf8')
    print('Offline WebGL viewer:',PACK/'VIEW_MODELS.html',len(models),'models')


HTML=r'''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>틈비 · 모델 뷰어</title><style>
*{box-sizing:border-box}body{margin:0;background:#101a20;color:#e2e8e7;font:15px/1.5 system-ui,-apple-system,sans-serif}main{display:grid;grid-template-columns:290px 1fr;min-height:100vh}aside{padding:32px 24px;background:#152229;border-right:1px solid #ffffff12}h1{font-size:27px;letter-spacing:-1px;margin:0 0 4px}.eyebrow{color:#8db1ac;font-size:11px;letter-spacing:2px}.intro{font-size:12px;color:#90a7ab;margin:14px 0 28px}label{display:block;margin-top:22px;font-size:12px;color:#a5bbbe}select,button{font:inherit;color:inherit;background:#20343e;border:1px solid #37515a;border-radius:8px;padding:10px 11px}select{display:block;width:100%;margin-top:6px}button{cursor:pointer;margin-top:10px;font-size:13px}button:hover{background:#2d4953}.buttons{display:flex;gap:8px;flex-wrap:wrap}#role{margin-top:26px;color:#dcf0e7;font-size:16px}#count{font-size:12px;color:#819ca4;margin-top:6px}.note{font-size:11px;color:#718d94;margin-top:32px}section{position:relative;min-height:700px;overflow:hidden;background:radial-gradient(ellipse at 50% 42%,#283f46 0%,#15242c 70%,#101c23 100%)}canvas{width:100%;height:100%;position:absolute;inset:0;display:block;touch-action:none}#top{position:absolute;top:26px;left:30px;pointer-events:none}#modelName{font-size:26px;font-weight:600;letter-spacing:-.5px}#stage{font-size:12px;color:#8eacaf;margin-top:3px}.help{position:absolute;bottom:22px;left:30px;font-size:12px;color:#87a3aa;pointer-events:none}a{color:#a5d8cd;text-decoration:none}#error{position:absolute;inset:20%;display:none;color:#ffbaa8;background:#2a2020;padding:24px;border-radius:8px}#badge{position:absolute;right:25px;top:30px;border:1px solid #55747766;padding:6px 10px;border-radius:20px;font-size:10px;letter-spacing:1px;color:#89b5ad;pointer-events:none}@media(max-width:740px){main{grid-template-columns:1fr}aside{padding:20px}section{min-height:70vh}h1{font-size:22px}.intro,.note{display:none}label{margin-top:10px}#role{margin-top:12px}.help{font-size:10px}}
</style></head><body><main><aside><div class="eyebrow">ORIGINAL CREATURES · V2</div><h1>틈비 도감</h1><p class="intro">이미지가 아닌 실제 모델입니다.<br>각도를 돌려 파츠와 텍스처를 확인하세요.</p><label for="model">몬스터</label><select id="model"></select><label for="animation">애니메이션</label><select id="animation"></select><div class="buttons"><button id="front">정면</button><button id="angle">입체 보기</button><button id="spin">자동 회전</button></div><div id="role"></div><div id="count"></div><p class="note">인터넷 연결 없이 동작합니다.<br>실제 생성한 geometry와 PNG를 표시합니다.<br>게임 렌더러의 발광·투명 효과와는 차이가 있습니다.</p><p class="note"><a id="file" href="#">Blockbench 파일 열기 ↗</a></p></aside><section id="scene"><canvas id="canvas"></canvas><div id="top"><div id="modelName"></div><div id="stage"></div></div><div id="badge">LIVE 3D · OFFLINE</div><div class="help">드래그: 회전 &nbsp;·&nbsp; 휠: 확대/축소 &nbsp;·&nbsp; 모바일: 한 손가락 회전</div><div id="error"></div></section></main>
<script>
'use strict';
const DATA=__MODEL_DATA__;
const $=id=>document.getElementById(id),canvas=$('canvas');
const gl=canvas.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:true});
const LABEL={normal:['틈비','노말 · 떠 있는 코어 정령'],fire:['불꽃','도끼 팔 · 근접 물리 딜러'],electric:['전기','피뢰침 스태프 · 특수 딜러'],grass:['풀','결합 방패 · 수호자'],water:['물','물의 하프 · 서포터']};
let model,texture,time=0,start=performance.now(),yaw=.48,pitch=.15,zoom=1,spin=false,last=performance.now(),extent=35,center=[0,17,0],buffer,program,loc={},ready=false;
const names=DATA.slice().sort((a,b)=>['normal','fire','electric','grass','water'].indexOf(a.kind)-['normal','fire','electric','grass','water'].indexOf(b.kind)||a.stage-b.stage);
for(const m of names){const opt=document.createElement('option');opt.value=m.name;opt.textContent=m.kind==='normal'?'틈비 · 1단계':`${LABEL[m.kind][0]} · ${m.stage}단계`; $('model').append(opt)}
function fail(msg){$('error').style.display='block';$('error').textContent=msg}
function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s}
function setup(){if(!gl){fail('이 브라우저에서 WebGL을 시작할 수 없습니다. 최신 Chrome, Edge 또는 Firefox에서 여세요.');return false}
 const vs=shader(gl.VERTEX_SHADER,`attribute vec3 p;attribute vec3 n;attribute vec2 uv;attribute float glow;uniform vec3 center,right,up,eye;uniform float halfHeight,aspect;varying vec2 vUV;varying float light;void main(){vec3 v=p-center;gl_Position=vec4(dot(v,right)/(halfHeight*aspect),dot(v,up)/halfHeight,-dot(v,eye)/150.0,1.0);vUV=uv;float key=max(0.0,dot(normalize(n),normalize(vec3(-0.45,0.8,-0.6))));float fill=max(0.0,dot(normalize(n),normalize(vec3(0.8,0.3,0.2))));light=mix(0.55+key*0.43+fill*0.13,1.15,glow);}`);
 const fs=shader(gl.FRAGMENT_SHADER,`precision mediump float;varying vec2 vUV;varying float light;uniform sampler2D atlas;void main(){vec4 t=texture2D(atlas,vUV);if(t.a<0.1)discard;gl_FragColor=vec4(t.rgb*light,t.a);}`);
 program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));gl.useProgram(program);
 for(const k of ['center','right','up','eye','halfHeight','aspect','atlas'])loc[k]=gl.getUniformLocation(program,k);
 buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
 const stride=9*4;for(const [name,count,offset] of [['p',3,0],['n',3,3],['uv',2,6],['glow',1,8]]){const i=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,count,gl.FLOAT,false,stride,offset*4)}
 gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(0,0,0,0);return true}
function rotate(v,degrees){let [x,y,z]=v;const [a,b,c]=degrees.map(v=>v*Math.PI/180);let cs=Math.cos(a),sn=Math.sin(a);[y,z]=[y*cs-z*sn,y*sn+z*cs];cs=Math.cos(b);sn=Math.sin(b);[x,z]=[x*cs+z*sn,-x*sn+z*cs];cs=Math.cos(c);sn=Math.sin(c);[x,y]=[x*cs-y*sn,x*sn+y*cs];return[x,y,z]}
const add=(a,b)=>a.map((v,i)=>v+b[i]), sub=(a,b)=>a.map((v,i)=>v-b[i]);
function around(v,p,r){return add(rotate(sub(v,p),r),p)}
function lerpFrames(frames,t,fallback){if(!frames)return fallback;const keys=Object.keys(frames).map(Number).sort((a,b)=>a-b);if(!keys.length)return fallback;if(t<=keys[0])return frames[Object.keys(frames).find(k=>Number(k)===keys[0])].map(Number);let i=0;while(i<keys.length-1&&t>keys[i+1])i++;const a=keys[i],b=keys[Math.min(i+1,keys.length-1)],va=frames[Object.keys(frames).find(k=>Number(k)===a)].map(Number),vb=frames[Object.keys(frames).find(k=>Number(k)===b)].map(Number);return va.map((v,j)=>v+(vb[j]-v)*(a===b?0:Math.min(1,(t-a)/(b-a))))}
function transforms(t){const anim=model.animations[$('animation').value],states={};if(anim)t=anim.loop?t%anim.animation_length:Math.min(t,anim.animation_length);for(const b of model.bones){const a=anim&&anim.bones[b.name];states[b.name]={b,rotation:add(b.rotation,lerpFrames(a&&a.rotation,t,[0,0,0])),position:lerpFrames(a&&a.position,t,[0,0,0])}}return states}
function point(v,box,states,isNormal=false){if(isNormal)v=rotate(v,box.rotation);else v=around(v,box.pivot,box.rotation);let name=box.bone;while(name){const s=states[name];if(isNormal)v=rotate(v,s.rotation);else v=add(around(v,s.b.pivot,s.rotation),s.position);name=s.b.parent}return v}
const faceDefs=[['north',[0,0,-1],[1,0,3,2]],['south',[0,0,1],[4,5,6,7]],['east',[1,0,0],[1,5,6,2]],['west',[-1,0,0],[4,0,3,7]],['up',[0,1,0],[3,2,6,7]],['down',[0,-1,0],[0,1,5,4]]];
function vertices(t){const states=transforms(t),out=[],ts=model.texture_size;for(const box of model.boxes){const [x,y,z]=box.origin,[w,h,d]=box.size;const raw=[[x,y,z],[x+w,y,z],[x+w,y+h,z],[x,y+h,z],[x,y,z+d],[x+w,y,z+d],[x+w,y+h,z+d],[x,y+h,z+d]],ps=raw.map(v=>point(v,box,states));for(const [f,normal,indices] of faceDefs){const n=point(normal,box,states,true),r=box.uv[f],u0=(r[0]+.05)/ts,u1=(r[2]-.05)/ts,v0=(r[1]+.05)/ts,v1=(r[3]-.05)/ts,uvs=[[u0,v1],[u1,v1],[u1,v0],[u0,v0]],e=['glow','eye','hot'].includes(box.material)?1:0;for(const i of [0,1,2,0,2,3])out.push(...ps[indices[i]],...n,...uvs[i],e)}}return new Float32Array(out)}
function choose(){ready=false;model=DATA.find(m=>m.name===$('model').value);$('modelName').textContent=model.kind==='normal'?'틈비':LABEL[model.kind][0]+' 분기';$('stage').textContent=`STAGE ${model.stage} / ORIGINAL VOXEL CREATURE`;$('role').textContent=LABEL[model.kind][1];$('count').textContent=`${model.boxes.length} 큐브 · ${model.bones.length} 본 · ${model.texture_size}px 텍스처`;$('file').href='blockbench/'+model.name+'.bbmodel';$('animation').replaceChildren();const blank=document.createElement('option');blank.value='';blank.textContent='정지 · 기본 포즈';$('animation').append(blank);for(const k of Object.keys(model.animations)){const opt=document.createElement('option');opt.value=k;const word=k.split('.').pop();opt.textContent=({idle:'대기 · 코어 부유',walk:'걷기',guard:'방어',perform:'연주',attack:'공격'})[word]||word;$('animation').append(opt)}
 const bounds=[Infinity,Infinity,Infinity,-Infinity,-Infinity,-Infinity],states=transforms(0);for(const b of model.boxes){const [x,y,z]=b.origin,[w,h,d]=b.size;for(const q of [[x,y,z],[x+w,y,z],[x,y+h,z],[x,y,z+d],[x+w,y+h,z+d]]){const v=point(q,b,states);for(let i=0;i<3;i++){bounds[i]=Math.min(bounds[i],v[i]);bounds[i+3]=Math.max(bounds[i+3],v[i])}}}center=bounds.slice(0,3).map((v,i)=>(v+bounds[i+3])/2);extent=Math.max(bounds[4]-bounds[1],bounds[3]-bounds[0])*1.16;zoom=1;yaw=.48;pitch=.15;time=0;start=performance.now();const chosen=model.name;const img=new Image();img.onload=()=>{if(model.name!==chosen)return;if(texture)gl.deleteTexture(texture);texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);ready=true};img.src=model.image}
function frame(now){const dt=Math.min(.1,(now-last)/1000);last=now;if(spin)yaw+=dt*.28;if(ready){const dpr=Math.min(2,window.devicePixelRatio||1),w=Math.round(canvas.clientWidth*dpr),h=Math.round(canvas.clientHeight*dpr);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h}gl.viewport(0,0,w,h);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const verts=vertices((now-start)/1000),right=[Math.cos(yaw),0,Math.sin(yaw)],up=[-Math.sin(yaw)*Math.sin(pitch),Math.cos(pitch),Math.cos(yaw)*Math.sin(pitch)],eye=[Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch)];gl.uniform3fv(loc.center,center);gl.uniform3fv(loc.right,right);gl.uniform3fv(loc.up,up);gl.uniform3fv(loc.eye,eye);gl.uniform1f(loc.aspect,w/h);gl.uniform1f(loc.halfHeight,extent*.54/zoom*Math.max(1,h/w*.8));gl.uniform1i(loc.atlas,0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.bufferData(gl.ARRAY_BUFFER,verts,gl.DYNAMIC_DRAW);gl.drawArrays(gl.TRIANGLES,0,verts.length/9)}requestAnimationFrame(frame)}
$('model').onchange=choose;$('animation').onchange=()=>{start=performance.now()};$('front').onclick=()=>{yaw=0;pitch=0;spin=false;updateSpin()};$('angle').onclick=()=>{yaw=.48;pitch=.15;zoom=1};function updateSpin(){$('spin').textContent=spin?'회전 멈춤':'자동 회전'}$('spin').onclick=()=>{spin=!spin;updateSpin()};let drag=null;canvas.onpointerdown=e=>{drag=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId)};canvas.onpointerup=()=>{drag=null};canvas.onpointercancel=()=>{drag=null};canvas.onpointermove=e=>{if(!drag)return;yaw-=(e.clientX-drag[0])*.009;pitch=Math.max(-1.2,Math.min(1.2,pitch+(e.clientY-drag[1])*.007));drag=[e.clientX,e.clientY]};canvas.onwheel=e=>{e.preventDefault();zoom=Math.max(.55,Math.min(2.8,zoom*Math.exp(-e.deltaY*.001)));};
try{if(setup()){choose();requestAnimationFrame(frame)}}catch(e){fail('뷰어 초기화 오류: '+e.message);console.error(e)}
</script></body></html>'''

if __name__=='__main__':main()
