"""Aquatic harp spirit: junior lyrist and ceremonial tide cantor."""
def build(m,stage):
    final=stage==3
    s=1 if final else .68
    def bone(n,p,parent='body',r=(0,0,0)):
        m.bone(n,tuple(v*s for v in p),parent,r)
    def box(n,p,z,mat='stone',b='body',r=(0,0,0),pivot=None):
        m.box(n,tuple(v*s for v in p),tuple(v*s for v in z),mat,b,r,tuple(v*s for v in pivot) if pivot else None)
    bone('body',(0,19,0),'root');bone('core',(0,24,0));bone('head',(0,32,0))
    bone('left_arm',(-5,27,0),r=(-8,0,-22 if final else -12));bone('right_arm',(5,27,0),r=(-12,0,34 if final else 18))
    bone('left_leg',(-2,12,0));bone('right_leg',(2,12,0))
    bone('harp',(10,18,-1));bone('ribbons',(0,28,2))
    box('pearl_heart',(-1.65,22.4,-1.65),(3.3,3.3,3.3),'glow','core',(0,0,45))
    box('heart_streak',(-.45,22,-1.85),(.9,4,.3),'eye','core')
    # Open ring chest, narrow waist, layered throat armor.
    box('collar',(-4.5,28,-1.5),(9,1.3,3.5),'light')
    box('collar_inlay',(-3.2,27.5,-1.8),(6.4,.5,.5),'trim')
    box('neck',(-1.15,29,-1),(2.3,2.8,2),'dark')
    for side,sg in [('l',-1),('r',1)]:
        box(side+'_chest_rail',(sg*3.6-.7,22.5,-1.25),(1.4,5.3,2.5),'light',r=(0,0,sg*13))
        box(side+'_pearl_clasp',(sg*3.5-.45,26.1,-1.8),(.9,1.5,.6),'trim')
    box('waist',(-2,17.5,-1.3),(4,3.2,2.6),'dark')
    box('belt',(-3.2,17.4,-1.9),(6.4,1,3.8),'trim')
    box('belt_gem',(-.7,17.35,-2.3),(1.4,1.4,.5),'accent',r=(0,0,45))
    box('hip',(-3.1,15,-1.6),(6.2,2,3.2),'stone')
    # Modest long open ceramic skirt: separate tapered stepped panels.
    for side,sg in [('l',-1),('r',1)]:
        for j in range(4 if final else 2):
            z=1+j*.55;x=sg*(3+j*.85)
            box(side+f'_skirt_{j}',(x-1,4+j*.4,z),(2,11-j*.7,1.1),'light' if j%2==0 else 'stone',r=(0,0,-sg*(10+j*4)))
            box(side+f'_skirt_trim_{j}',(x-1,4+j*.4,z-.15),(2,.6,.35),'trim',r=(0,0,-sg*(10+j*4)))
        box(side+'_front_panel',(sg*2.4-1.1,7,-2.8),(2.2,8.5,.9),'light',r=(0,0,-sg*10))
        box(side+'_front_sash',(sg*2.4-.3,7.4,-3.02),(.6,8,.25),'water',r=(0,0,-sg*10))
        leg='left_leg' if sg<0 else 'right_leg'
        box(side+'_thigh',(sg*1.8-.8,8.5,-.8),(1.6,5,1.6),'dark',leg)
        box(side+'_shin',(sg*1.8-1,3.5,-1),(2,4,2),'light',leg,r=(0,0,sg*3))
        box(side+'_boot',(sg*1.8-1.1,1,-1.8),(2.2,2.3,3.5),'stone',leg)
        box(side+'_boot_tip',(sg*1.8-.6,1,-2.3),(1.2,.8,1),'trim',leg)
        arm='left_arm' if sg<0 else 'right_arm';x=sg*5.3
        box(side+'_shoulder',(x-1.5,26,-1.7),(3,2.4,3.4),'light',arm,r=(0,0,sg*12))
        box(side+'_pauldron_edge',(x-1.6,25.7,-2),(3.2,.6,4),'trim',arm)
        box(side+'_upper_arm',(x-.9,21.6,-1),(1.8,4,2),'stone',arm)
        box(side+'_elbow',(x-.8,20,-.8),(1.6,1.3,1.6),'dark',arm)
        box(side+'_forearm',(x-1,16.5,-1.1),(2,3,2.2),'light',arm,r=(0,0,-sg*8))
        box(side+'_cuff',(x-1.2,16,-1.3),(2.4,.8,2.6),'trim',arm)
        box(side+'_hand',(x-.8,14.3,-1),(1.6,1.4,1.8),'stone',arm)
        for k in range(2):box(side+f'_finger_{k}',(x-.65+k*.7,13.6,-1),( .45,.9,1),'light',arm)
    # Face: shaped jaw, framed dark inset, bright kind blue eyes.
    box('face_recess',(-2.6,32,-1.9),(5.2,3.6,3.8),'dark','head')
    box('forehead',(-2.7,35.1,-2.1),(5.4,1.2,4.2),'light','head')
    box('jaw',(-1.9,31.3,-1.9),(3.8,1,3.4),'stone','head')
    for sg in [-1,1]:
        tag='l' if sg<0 else 'r'
        box(tag+'_cheek',(sg*2.3-.45,32.1,-2.2),(.9,3,3.8),'light','head')
        box(tag+'_eye',(sg*1.2-.45,33.5,-2.05),(.9,1.15,.22),'eye','head')
        box(tag+'_brow',(sg*1.2-.6,34.85,-2.3),(1.2,.25,.4),'trim','head',r=(0,0,sg*8))
        box(tag+'_temple',(sg*3-.7,33,-.8),(1.4,3.4,1.6),'trim','head')
        box(tag+'_fin',(sg*3.8-.5,35,-.2),(1,4,1.4),'light','head',r=(0,0,-sg*22))
        if final:
            box(tag+'_fin_crest',(sg*4.8-.4,36.7,.1),(.8,3,1),'water','head',r=(0,0,-sg*25))
            for k in range(3):box(tag+f'_hair_tide_{k}',(sg*(3+k*.45)-.6,27.5-k*1.4,2.1),(1.2,6-k*.4,1),'water','head',r=(0,0,sg*(8+k*7)))
    box('crown_gem',(-.7,35.5,-2.3),(1.4,2,.65),'accent','head',r=(0,0,45))
    # The body-mounted harp is framed with bent stepped arms, 6 tuned strings.
    if final:
        base_y=9;top=29;outside=14
    else:base_y=14;top=25;outside=12
    box('harp_base',(7,base_y,-2.4),(outside-5,1.7,2),'light','harp')
    box('harp_base_gold',(7,base_y+.4,-2.65),(outside-5,.6,.35),'trim','harp')
    box('harp_pillar',(outside,base_y+1,-2.1),(1.4,top-base_y-2.2,1.4),'stone','harp')
    box('harp_pillar_inlay',(outside+.35,base_y+1,-2.3),(.6,top-base_y-2.2,.35),'water','harp')
    box('harp_neck',(6.7,base_y+1,-2),(1,top-base_y-3,1.3),'trim','harp',r=(0,0,5))
    box('harp_crossbar',(7,top-1.2,-2.2),(outside-5,1.2,1.8),'light','harp')
    for j in range(6 if final else 4):
        x=8+j*(outside-8)/5
        box(f'harp_string_{j}',(x,base_y+1.7,-1.75),(.18,top-base_y-2.8,.2),'string','harp')
        if j%2==0:box(f'harp_water_{j}',(x-.18,base_y+5+j*1.7,-2.2),(.55,2.3,.55),'water','harp')
    box('harp_connection',(4.5,24,-.2),(3,1,1),'trim')
    # Curving pixel water ribbons flow from the mantle into the harp. NO particles as model cubes.
    if final:
        path=[(-4.5,29,0),(-6.5,29,-.4),(-8.5,28.5,-1),(-10.5,27,-1.7),(-12.2,25,-2.2),(-13,22.5,-2.7),(-12.5,20,-2.9),(-11,18,-3),(-9.5,16.5,-3),(-9,14.5,-3),(-10,12.5,-2.8),(-12,11,-2.5),(-14,10.7,-2.2)]
        for j,(x,y,z) in enumerate(path):
            box('flow_'+str(j),(x,y,z),(2.2,1.5,1),'water' if j%3 else 'accent','ribbons',r=(0,0,(-15+j*8)%40-20))
            if j%3==0:box('flow_light_'+str(j),(x+.2,y+.7,z-.15),(1.6,.35,.25),'light','ribbons')
    else:
        for j in range(5):box('junior_flow_'+str(j),(-4-j*.7,29-j*2,2.5),(1.8,2,.8),'water','ribbons',r=(0,0,-12))
