"""Teumbi: a broken, orbiting reliquary around one living heart.

The shell is a single interrupted egg silhouette, never a small humanoid.
Front is negative Z. All small boxes contribute an intentional silhouette,
carved seam, expression, or exposed inner surface.
"""


def build(m, stage=1):
    m.bone('core', pivot=(0, 9.3, 0))
    m.bone('crown', pivot=(0, 14, 0))
    m.bone('shell_left', pivot=(-5.6, 9, 0))
    m.bone('shell_right', pivot=(5.3, 10.1, 0))
    m.bone('shell_bottom', pivot=(.4, 4.5, .4))
    m.bone('orbit', pivot=(0, 9, 0))

    def b(n, o, s, mat='stone', bone='crown', r=(0, 0, 0), p=None):
        m.box(n, origin=o, size=s, material=mat, bone=bone,
              rotation=r, pivot=p)

    # One luminous heart. The large cube is the living body; the subdued
    # shallow frame and four bevel facets belong to the same heart, not
    # additional floating cores.
    b('heart', (-1.65, 7.65, -1.65), (3.3, 3.3, 3.3), 'glow', 'core')
    b('heart_face', (-1.18, 8.12, -1.74), (2.36, 2.36, .1), 'light', 'core')
    b('heart_pupil', (-.69, 8.61, -1.82), (1.38, 1.38, .1), 'glow', 'core')
    b('heart_top_bevel', (-1.18, 10.94, -1.18), (2.36, .15, 2.36), 'trim', 'core')
    b('heart_bottom_bevel', (-1.18, 7.5, -1.18), (2.36, .15, 2.36), 'trim', 'core')
    b('heart_side_bevel_l', (-1.8, 8.12, -1.18), (.15, 2.36, 2.36), 'trim', 'core')
    b('heart_side_bevel_r', (1.65, 8.12, -1.18), (.15, 2.36, 2.36), 'trim', 'core')

    # The crown is the TOP of the cracked shell, rather than a detached
    # head. The broad flat forehead and little eyes give a calm curious face.
    b('crown_main', (-3.6, 13.6, -2.1), (6.8, 2.5, 4.7))
    b('crown_left_step', (-4.6, 13.1, -.9), (1.3, 2.1, 3.4))
    b('crown_right_step', (2.6, 13.2, -1.2), (1.4, 1.9, 3.1))
    b('crown_back_curl', (-2.6, 12.1, 2), (4.6, 2.6, 1.3), 'dark')
    b('crown_top_plate', (-2.8, 16.1, -1.3), (4.6, .65, 3), 'light')
    b('crown_top_scar', (-.4, 16.11, -1.31), (.3, .7, 2.8), 'trim')
    b('crown_inner_rim', (-3.1, 13.2, -1.9), (5.8, .4, 3.6), 'dark')
    b('crown_front_brow', (-3.2, 15.2, -2.4), (5.9, .6, .4), 'light')
    b('crown_broken_corner', (2.5, 12.65, -.2), (1, 1.1, 1.9))

    # Eyes are inset in the shell face; the large dark sockets keep tiny
    # emissive rectangles readable from game-camera distance.
    for side, x in [('left', -2.3), ('right', .85)]:
        b('eye_socket_' + side, (x-.12, 13.93, -2.25), (1.45, 1.15, .2), 'dark')
        b('eye_' + side, (x+.25, 14.05, -2.38), (.65, .85, .15), 'eye')
    b('tiny_mouth', (-.45, 13.6, -2.22), (.8, .2, .15), 'trim')

    # Long left shard: the outer part of an eggshell with a jagged bottom.
    # It has depth, a worn pale rim, and a dark cavity-facing inner cut.
    b('left_outer', (-7.25, 7, -.6), (2, 5.5, 3.4), 'stone', 'shell_left', r=(0, 0, -12), p=(-5.7, 9.4, 0))
    b('left_front', (-6.8, 7.9, -2.4), (1.9, 3.3, 2), 'stone', 'shell_left')
    b('left_back', (-6.6, 8, 2.6), (1.7, 3.2, 1.4), 'dark', 'shell_left')
    b('left_top_lip', (-6.1, 11.8, -.3), (1.6, .8, 2.8), 'light', 'shell_left')
    b('left_jagged_lower', (-6.2, 6.25, -.8), (1.6, 1.6, 2.1), 'stone', 'shell_left')
    b('left_inner_cut', (-4.95, 8.1, -1.9), (.4, 2.9, 2.8), 'dark', 'shell_left')
    b('left_gold_fissure', (-6.86, 9.5, -2.46), (1.8, .24, .12), 'trim', 'shell_left')
    b('left_gold_fissure_up', (-6.85, 9.5, -2.46), (.24, 1.2, .12), 'trim', 'shell_left')

    # The right shell is a differently shaped concave fragment, deliberately
    # higher and broader than the left. This asymmetry avoids paired arms.
    b('right_outer', (5.45, 9, -.8), (2, 3.3, 3.5), 'stone', 'shell_right')
    b('right_front_wedge', (4.6, 9.4, -2.1), (1.1, 2.5, 2), 'light', 'shell_right')
    b('right_high_prong', (5.1, 12.3, .5), (1.5, 1.4, 2.2), 'stone', 'shell_right')
    b('right_back_return', (4.8, 9.7, 2.6), (1.7, 2.5, 1.2), 'dark', 'shell_right')
    b('right_inner_cut', (4.3, 9.6, -.6), (.5, 2, 2.9), 'dark', 'shell_right')
    b('right_lower_shard', (5.6, 7.9, .1), (1.25, 1.2, 2.2), 'stone', 'shell_right')
    b('right_gold_seam', (5.55, 11.8, -.9), (1.8, .3, .2), 'trim', 'shell_right')

    # Bottom cradle hangs to one side, without feet or a pelvis. Three
    # overlapping angular layers form an incomplete pointed egg end.
    b('cradle_bottom', (-1.4, 2.9, -.8), (3.3, 1.1, 2.7), 'stone', 'shell_bottom')
    b('cradle_middle', (-2.5, 4, -1.8), (5.1, 1.35, 4.3), 'stone', 'shell_bottom')
    b('cradle_left_jag', (-3.6, 5.35, -.9), (1.45, 1.2, 3), 'light', 'shell_bottom')
    b('cradle_right_jag', (1.6, 5.3, -.8), (2, 1.35, 2.9), 'stone', 'shell_bottom')
    b('cradle_inner', (-1.9, 5.32, -.8), (3.4, .2, 2.3), 'dark', 'shell_bottom')
    b('cradle_front_lip', (-1.9, 4.85, -2.03), (3.7, .45, .35), 'trim', 'shell_bottom')
    b('cradle_back_lip', (-1.3, 5.1, 2.4), (2.6, 1, .8), 'dark', 'shell_bottom')

    # Six orbiting stone chips complete the imaginary shell volume. Their
    # varied sizes and depth give the floating silhouette a living motion.
    b('chip_front_left', (-4.2, 8, -4), (.8, 1.1, .9), 'stone', 'orbit', r=(10, 15, -15))
    b('chip_back_high', (3.9, 14.6, 1.5), (.85, .9, 1), 'stone', 'orbit', r=(0, 20, 10))
    b('chip_lower_left', (-4.7, 3.6, -.1), (1.1, .9, 1.2), 'stone', 'orbit', r=(15, 0, 18))
    b('chip_upper_left', (-5.5, 15.6, 1.7), (.7, .8, .9), 'light', 'orbit', r=(0, 15, 20))
    b('chip_lower_right', (4.5, 5.3, -1.8), (1.1, 1.3, 1), 'stone', 'orbit', r=(0, -10, -15))
    b('chip_rear', (.1, 10.7, 4), (1, 1.2, .8), 'dark', 'orbit', r=(20, 10, 0))
