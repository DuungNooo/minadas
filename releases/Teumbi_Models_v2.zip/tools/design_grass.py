"""Mossbound guardians: two distinct shield-bearing evolution stages."""


def build(m, stage):
    if stage == 2:
        _sapling(m)
    else:
        _bastion(m)


def _sapling(m):
    # The intermediate form is deliberately a squat, open-chested young golem.
    m.bone('body', pivot=(0, 12, 0))
    m.bone('core', pivot=(0, 14.7, 0), parent='body')
    m.bone('head', pivot=(0, 19, 0), parent='body')
    for side, s in [('left', -1), ('right', 1)]:
        m.bone(side + '_arm', pivot=(s * 5.1, 16.2, 0), parent='body')
        m.bone(side + '_leg', pivot=(s * 2.1, 8.2, 0), parent='body')

    def b(n, p, s, mat='stone', bone='body', **kw):
        m.box(n, p, s, material=mat, bone=bone, **kw)

    # An actual void surrounds the one heart; outer ribs float around it.
    b('heart', (-1.35, 13.5, -1.35), (2.7, 2.7, 2.7), 'glow', 'core')
    b('heart_front_inlay', (-.65, 14.2, -1.43), (1.3, 1.3, .12), 'light', 'core')
    b('shoulder_bridge', (-3.7, 17.4, -1.6), (7.4, 1.6, 3.5), 'wood')
    b('waist_ring', (-3.4, 10.7, -1.8), (6.8, 1.8, 3.8), 'wood')
    b('belt_leaf', (-1.2, 10.6, -2.1), (2.4, 1.8, .7), 'leaf')
    b('belt_gem', (-.45, 11.1, -2.25), (.9, .9, .25), 'accent')
    for s in [-1, 1]:
        x = s * 3.5
        b('floating_side_rib', (x - .55, 13.1, -.9), (1.1, 3.3, 2.2), 'stone')
        b('rib_moss', (x - .4, 15.5, -1.15), (.8, .8, .4), 'leaf')
    b('pelvis', (-2.3, 8.4, -1.4), (4.6, 1.8, 3.2), 'dark')
    b('rear_shell', (-2.5, 12.4, 2.1), (5, 5.3, 1), 'stone')
    b('rear_shell_moss', (-2.7, 16.7, 2.2), (5.4, 1.1, 1.2), 'leaf')

    # Broad face and small asymmetrical sprout provide a memorable juvenile.
    b('head_stone', (-2.7, 18.7, -2), (5.4, 3.8, 4), 'stone', 'head')
    b('face_recess', (-2.2, 19.5, -2.18), (4.4, 1.8, .25), 'dark', 'head')
    for x in [-1.7, .85]:
        b('eye', (x, 20.05, -2.35), (.85, .85, .22), 'eye', 'head')
        b('eye_glint', (x + .12, 20.5, -2.4), (.22, .2, .12), 'light', 'head')
    b('brow', (-2.9, 21.2, -2.3), (5.8, 1, 1.2), 'wood', 'head')
    b('small_chin', (-1.5, 18.4, -2.1), (3, .7, 1.4), 'stone', 'head')
    b('head_moss', (-2.2, 22.2, -.9), (4.6, .65, 2.6), 'leaf', 'head')
    b('sprout_trunk', (-.5, 22.8, .2), (.8, 1.6, .8), 'wood', 'head')
    b('sprout_left', (-2, 23.3, .1), (1.7, .65, 1.3), 'leaf', 'head', rotation=(0, 0, -12))
    b('sprout_right', (.15, 24, .15), (1.7, .65, 1.3), 'accent', 'head', rotation=(0, 0, 12))

    for side, s in [('left', -1), ('right', 1)]:
        arm = side + '_arm'
        x = s * 5.4
        b('arm_wood_joint', (x - .7, 13.5, -.7), (1.4, 3, 1.7), 'wood', arm)
        b('shoulder_block', (x - 1.9, 15.6, -1.7), (3.8, 2.6, 3.8), 'stone', arm)
        b('shoulder_canopy', (x - 2.05, 17.8, -1.8), (4.1, .7, 3.9), 'leaf', arm)
        b('elbow', (x - .9, 12.5, -1), (1.8, 1.5, 2), 'dark', arm)
        b('forearm', (x - 1.15, 9.4, -.8), (2.3, 3, 2), 'wood', arm)
        # Two side shields foreshadow the adult's complete gate.
        b('half_shield_wood', (x - 1.8, 8.1, -2.7), (3.6, 6.8, 1.35), 'wood', arm)
        b('half_shield_plate', (x - 1.45, 8.5, -3.05), (2.9, 6, .55), 'stone', arm)
        b('shield_top_rim', (x - 1.9, 14.55, -3.15), (3.8, .65, 1), 'leaf', arm)
        b('shield_bottom_rim', (x - 1.75, 7.85, -3.15), (3.5, .65, .9), 'wood', arm)
        b('shield_tree_stripe', (x - .28, 9.1, -3.3), (.56, 4.7, .25), 'wood', arm)
        b('shield_branch', (x - 1.05, 11.6, -3.35), (2.1, .5, .25), 'leaf', arm)
        b('shield_rune', (x - .4, 11.15, -3.48), (.8, .8, .2), 'accent', arm)
        leg = side + '_leg'; lx = s * 2.05
        b('thigh', (lx - 1, 5.7, -1), (2, 2.7, 2.4), 'wood', leg)
        b('knee', (lx - 1.15, 4.8, -1.65), (2.3, 1.3, 2), 'stone', leg)
        b('shin', (lx - 1.05, 2.5, -.9), (2.1, 2.4, 2.2), 'stone', leg)
        b('shin_moss', (lx - .7, 3.2, -1.2), (1.4, 1.5, .4), 'leaf', leg)
        b('foot', (lx - 1.5, .5, -2.2), (3, 1.8, 4), 'stone', leg)
        b('toe_cap', (lx - 1.25, .6, -2.4), (2.5, 1.1, .5), 'wood', leg)


def _bastion(m):
    # A tree-root portcullis with two arm-mounted interlocking shield wings.
    m.bone('body', pivot=(0, 17, 0))
    m.bone('core', pivot=(0, 24, -.2), parent='body')
    m.bone('head', pivot=(0, 30, 0), parent='body')
    for side, s in [('left', -1), ('right', 1)]:
        m.bone(side + '_arm', pivot=(s * 10.7, 27.1, 0), parent='body')
        m.bone(side + '_leg', pivot=(s * 4.35, 12.2, .2), parent='body')

    def b(n, p, s, mat='stone', bone='body', **kw):
        m.box(n, p, s, material=mat, bone=bone, **kw)

    b('single_heart', (-1.9, 22.4, -2), (3.8, 3.8, 3.8), 'glow', 'core')
    b('heart_rune_vertical', (-.3, 23.1, -2.12), (.6, 2.4, .2), 'light', 'core')
    b('heart_rune_horizontal', (-1.1, 24, -2.14), (2.2, .6, .2), 'light', 'core')
    b('upper_collar', (-6.2, 28, -2.8), (12.4, 2.2, 5.6), 'wood')
    b('lower_collar', (-5.5, 18.8, -2.5), (11, 2.3, 5), 'wood')
    for s in [-1, 1]:
        x = s * 5.1
        b('curving_rib', (x - .8, 21.7, -1.7), (1.6, 5.6, 3.4), 'stone')
        b('rib_root', (x - 1, 25.5, -2), (2, 2.3, 3.8), 'wood')
        b('rib_moss', (x - .7, 23.1, -2.05), (1.4, 1.2, .5), 'leaf')
    b('rear_plate', (-4.7, 20.2, 2.3), (9.4, 8, 1.5), 'dark')
    b('rear_wood_ridge', (-1.4, 19.5, 3.7), (2.8, 10, 1), 'wood')
    b('belt', (-5.8, 15, -2.5), (11.6, 2.2, 5), 'wood')
    b('belt_front_cap', (-2.5, 14.5, -3), (5, 2.8, 1.1), 'stone')
    b('belt_center_moss', (-1.6, 15.3, -3.2), (3.2, 1.4, .4), 'leaf')
    b('hip_joint', (-3.7, 12.6, -1.5), (7.4, 2.1, 3.7), 'dark')

    # Stacked brow, recess, beard-like roots, leafy crown: no smooth parts.
    b('head_main', (-4, 30.1, -2.7), (8, 5.5, 5.5), 'stone', 'head')
    b('face_recess', (-3.4, 31.2, -2.9), (6.8, 2.3, .4), 'dark', 'head')
    for x in [-2.75, 1.4]:
        b('watchful_eye', (x, 31.8, -3.15), (1.35, 1.1, .3), 'eye', 'head')
        b('eye_glint', (x + .2, 32.4, -3.25), (.3, .3, .15), 'light', 'head')
    b('brow_heavy', (-4.4, 33.6, -3.2), (8.8, 1.4, 1.8), 'wood', 'head')
    b('nose_guard', (-.55, 31.2, -3.5), (1.1, 2.1, 1), 'stone', 'head')
    b('jaw_left', (-3.9, 29.7, -2.8), (2.6, 1.7, 2), 'wood', 'head')
    b('jaw_right', (1.3, 29.7, -2.8), (2.6, 1.7, 2), 'wood', 'head')
    b('chin', (-1.5, 29.2, -2.7), (3, 1.5, 2), 'stone', 'head')
    b('crown_moss', (-3.8, 35.4, -2), (7.6, .8, 4.3), 'leaf', 'head')
    for x,h,z in [(-3,2.1,.2),(-.8,3.4,1),(2.1,2.5,.1)]:
        b('crown_branch', (x, 36, z), (1.2, h, 1.1), 'wood', 'head')
        b('crown_leaf', (x-.5, 36+h-.5, z-.4), (2.2, .9, 1.8), 'leaf', 'head')
    b('crown_front_leaf', (-1.5, 35.8, -2.3), (3, 1.1, 1), 'accent', 'head')

    for side, s in [('left', -1), ('right', 1)]:
        arm = side + '_arm'; x=s*10.7
        b('upper_arm_trunk', (x-1.55, 21, -1), (3.1, 5.6, 3.4), 'wood', arm)
        b('shoulder_fortress', (x-4.1, 25.4, -3.4), (8.2, 4.4, 6.8), 'stone', arm)
        b('shoulder_root_lip', (x-4.4, 25.2, -3.6), (8.8, 1.2, 7.2), 'wood', arm)
        b('shoulder_moss_canopy', (x-4.3, 29.4, -3.4), (8.6, .85, 6.9), 'leaf', arm)
        b('shoulder_moss_patch', (x-3, 30.1, -1.8), (3.8, .6, 4), 'accent', arm)
        b('shoulder_inner_plate', (x-2.1, 26, -3.8), (4.2, 2.2, .7), 'wood', arm)
        b('elbow_hinge', (x-1.6, 19.5, -1.3), (3.2, 2.2, 3.5), 'dark', arm)
        b('forearm_inner', (s*5.3-2, 16.7, -4.6), (4, 3.1, 3.6), 'wood', arm)
        b('stone_knuckles', (s*2.2-1.7, 16.8, -5.2), (3.4, 2.6, 2.1), 'stone', arm)

        # Two asymmetrically detailed halves form one shield, center seam .4.
        sx = -12.2 if s < 0 else .2
        b('shield_wood_back', (sx, 6.8, -6.3), (12, 14.1, 2.1), 'wood', arm)
        b('shield_stone_panel', (sx+.7, 7.5, -7.1), (10.6, 12.7, 1), 'stone', arm)
        b('shield_top_cap', (sx-.25, 20.6, -7.25), (12.5, 1, 3), 'wood', arm)
        b('shield_bottom_cap', (sx+.2, 6.5, -7.2), (11.6, .9, 2.6), 'wood', arm)
        ox = sx if s < 0 else sx+11
        b('shield_outside_rim', (ox, 7.3, -7.3), (1, 13.1, 2.8), 'wood', arm)
        ix = -.95 if s < 0 else .2
        b('shield_seam_root', (ix, 7, -7.55), (.75, 13.7, 1), 'wood', arm)
        # Tree trunk shared across both shields and angular branch inlays.
        tx = -1.55 if s < 0 else .45
        b('world_tree_trunk', (tx, 8, -8.25), (1.1, 10.8, .55), 'trim', arm)
        for y,extent in [(12.8,7),(16.6,9.2)]:
            bx = -extent if s < 0 else 1
            b('world_tree_branch', (bx, y, -8.22), (extent-1, .8, .5), 'wood', arm)
            bx2 = -extent if s < 0 else extent-1.9
            b('world_tree_branch_up', (bx2, y, -8.21), (.9, 1.7, .45), 'wood', arm)
            b('world_tree_leaf', (bx2-.5, y+1.3, -8.4), (2, 1.25, .5), 'leaf', arm)
        for dx,y in [(2,8.7),(8.5,9.2),(3,18.5),(8.8,18.1)]:
            b('shield_moss_island', (sx+dx, y, -7.37), (1.8, 1.2, .4), 'leaf', arm)
        for dx,y in [(1.2,8),(9.8,8),(1.2,19.1),(9.8,19.1)]:
            b('shield_stone_rivet', (sx+dx,y,-7.6), (.8,.8,.6), 'light', arm)
        # Small joining runes read as a clasp without adding another core.
        clasp_x=-.9 if s<0 else .2
        b('shield_clasp', (clasp_x,14.2,-8.5), (.7,1.3,.6), 'accent', arm)

        leg=side+'_leg';lx=s*4.35
        b('thigh_log', (lx-1.9,8.5,-1.4),(3.8,4.2,3.8),'wood',leg)
        b('thigh_cap', (lx-2.35,10,-2.1),(4.7,2.6,4.6),'stone',leg)
        b('knee_dark_hinge', (lx-1.6,7,-1.5),(3.2,1.8,3.3),'dark',leg)
        b('knee_plate', (lx-2.1,6.5,-2.8),(4.2,2.7,1.6),'wood',leg)
        b('shin_stone', (lx-1.9,2.5,-1.4),(3.8,4.2,3.8),'stone',leg)
        b('shin_moss', (lx-1.4,3.1,-1.8),(2.8,2.6,.5),'leaf',leg)
        b('foot_root', (lx-2.8,.4,-3.6),(5.6,2.1,6.3),'stone',leg)
        b('toe_root', (lx-2.4,.55,-4),(4.8,1.2,.7),'wood',leg)
        b('foot_moss', (lx-2.1,2.45,-2.5),(4.2,.6,3.2),'leaf',leg)

