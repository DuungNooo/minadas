"""Small, repeatable hand-styled pixel surfaces for the Teumbi voxel models.

Tiles are generated at their final pixel size.  Nothing is blurred, so nearest
filtering in the game and Blockbench preserves the deliberately chunky marks.
"""

from __future__ import annotations

import hashlib
import random
from PIL import Image, ImageDraw


PALETTES = {
    'normal': {
        'stone': '#8C929A', 'dark': '#414858', 'light': '#CCD0C9',
        'trim': '#C2AF75', 'accent': '#E8DCA7', 'glow': '#FFDC80',
        'hot': '#EAB85E', 'wood': '#7A6F60', 'leaf': '#8D9C74',
        'water': '#A8DCD8', 'metal': '#B2B7B5', 'string': '#F6E6BA',
        'eye': '#FFF1BC',
    },
    'fire': {
        'stone': '#4C4652', 'dark': '#252734', 'light': '#81707A',
        'trim': '#A46E4D', 'accent': '#C25D38', 'glow': '#FFB43A',
        'hot': '#F67826', 'wood': '#56443B', 'leaf': '#765740',
        'water': '#E6904F', 'metal': '#897D83', 'string': '#FFD38C',
        'eye': '#FFE8A8',
    },
    'grass': {
        'stone': '#78876D', 'dark': '#344A40', 'light': '#BDCAA0',
        'trim': '#AC9860', 'accent': '#9DC866', 'glow': '#B9ED77',
        'hot': '#D8F4A2', 'wood': '#796146', 'leaf': '#4F865B',
        'water': '#7DBB90', 'metal': '#8D9D7A', 'string': '#DBD1A0',
        'eye': '#ECFFD0',
    },
    'electric': {
        'stone': '#E6E0CF', 'dark': '#303747', 'light': '#FFF6DB',
        'trim': '#C69B48', 'accent': '#D9B861', 'glow': '#FFDF55',
        'hot': '#FFF0A2', 'wood': '#B68855', 'leaf': '#8EAA7C',
        'water': '#CDE4CC', 'metal': '#AF8049', 'string': '#FFEBC0',
        'eye': '#FFFFDB',
    },
    'water': {
        'stone': '#C9DDD9', 'dark': '#35536B', 'light': '#F0EED9',
        'trim': '#AF9F6C', 'accent': '#458EAA', 'glow': '#83EBF5',
        'hot': '#B9FCFF', 'wood': '#6F9292', 'leaf': '#5A9D94',
        'water': '#40BBD7', 'metal': '#77A8B2', 'string': '#E8FFE9',
        'eye': '#D8FFFF',
    },
}


def _rgb(value):
    value = value.lstrip('#')
    return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))


def _mix(a, b, fraction):
    return tuple(round(x*(1-fraction)+y*fraction) for x, y in zip(a, b))


def tile(kind, material, width, height, seed, face='north'):
    """Return a fully opaque RGBA tile, exactly ``width`` by ``height`` pixels.

    Seed and face are combined with SHA-256 rather than Python's randomized
    hash, so fresh machines produce byte-identical surfaces.
    """
    width, height = max(1, int(width)), max(1, int(height))
    kind = kind if kind in PALETTES else 'normal'
    material = material if material in PALETTES[kind] else 'stone'
    palette = PALETTES[kind]
    rng = random.Random(int.from_bytes(hashlib.sha256(
        f'{kind}/{material}/{seed}/{face}'.encode('utf8')
    ).digest()[:8], 'little'))
    base = _rgb(palette[material])
    # Very restrained directional baking. Real scene lighting supplies most
    # shading, while this makes the raw unlit texture legible in Blockbench.
    shift = {'up': 0.07, 'down': -0.09, 'east': -0.015, 'west': 0.015}.get(face, 0)
    base = _mix(base, (255, 255, 241) if shift >= 0 else (22, 30, 43), abs(shift))
    hi = _mix(base, (255, 255, 238), .16)
    low = _mix(base, (22, 29, 42), .20)
    mid = _mix(base, (31, 38, 49), .065)
    image = Image.new('RGBA', (width, height), base + (255,))
    draw = ImageDraw.Draw(image)

    def line(points, color, stroke=1):
        draw.line(points, fill=color+(255,), width=stroke)

    def rect(box, color):
        draw.rectangle(box, fill=color+(255,))

    def bevel(strength=1):
        # One-pixel bevels stay readable even on small 2x4 armor strips.
        if width > 2:
            line([(0, 0), (width-2, 0)], hi)
            line([(1, height-1), (width-1, height-1)], low)
        if height > 2:
            line([(0, 1), (0, height-2)], hi)
            line([(width-1, 1), (width-1, height-1)], low)

    if material in ('glow', 'eye', 'hot'):
        # Stepped luminous mineral rather than a smooth photographic gradient.
        edge = _mix(base, _rgb(palette['accent']), .28)
        image.paste(edge+(255,), (0, 0, width, height))
        inset = 1 if min(width, height) >= 4 else 0
        rect((inset, inset, width-1-inset, height-1-inset), base)
        if min(width, height) >= 5:
            inset = max(1, min(width, height)//4)
            rect((inset, inset, width-1-inset, height-1-inset), _mix(base, (255,255,240), .55))
        if material != 'hot':
            cx, cy = (width-1)//2, (height-1)//2
            line([(cx, max(0, cy-height//4)), (cx, min(height-1, cy+height//4))], (255,255,236))
            if min(width,height) > 3:
                line([(max(0,cx-width//5),cy), (min(width-1,cx+width//5),cy)], (255,255,236))

    elif material == 'wood':
        bevel()
        # Vertical bark strips, occasional short crossgrain, a single knot.
        for x in range(2, width-1, 4):
            line([(x, 1), (x, height-2)], low)
            if x+1 < width-1: line([(x+1, 1), (x+1, height-2)], hi)
        if width >= 7 and height >= 7:
            cx, cy = width//2, height//2
            rect((cx-1,cy-1,cx+1,cy+1),low)
            rect((cx,cy,cx,cy),base)

    elif material == 'leaf':
        bevel()
        # Broad pixel-cluster veins with light exposed tips.
        if width > 4 and height > 4:
            cx = width//2
            line([(cx,1),(cx,height-2)],low)
            for y in range(3,height-1,4):
                line([(cx,y),(max(1,cx-2),y-2)],hi)
                line([(cx,y),(min(width-2,cx+2),y-2)],hi)
        for _ in range(max(1,width*height//95)):
            x,y=rng.randrange(width),rng.randrange(height)
            rect((x,y,min(width-1,x+1),min(height-1,y+1)),mid)

    elif material == 'water':
        # Layered rectangular blue bands imply water without alpha sorting.
        bevel()
        for y in range(2,height-1,5):
            x0 = 1 if (y//5)%2 else max(1,width//3)
            x1 = max(x0,min(width-2,x0+max(1,width//2)))
            line([(x0,y),(x1,y)],_mix(base,(188,255,255),.5))
            if y+1 < height-1:line([(x0,y+1),(x1,y+1)],mid)
        if width > 3:
            line([(1,1),(1,height-2)],_mix(base,(224,255,255),.45))

    elif material == 'string':
        # Bright clean instrument filaments, no surface clutter.
        if width > 2:line([(width//2,0),(width//2,height-1)],hi)

    elif material in ('metal','trim'):
        bevel()
        if width >= 6 and height >= 6:
            # A restrained inlaid panel, not a checkerboard over every piece.
            if rng.random()<.65:
                line([(2,2),(width-3,2)],hi)
                line([(2,height-3),(width-3,height-3)],mid)
            if width > 10 and height > 8:
                for x in (2,width-3):
                    rect((x,2,x,2),_mix(base,(255,242,193),.6))
        if material=='metal' and kind=='electric' and height>6:
            line([(width//2,2),(width//2,height-3)],_mix(base,_rgb(palette['glow']),.32))

    elif material == 'accent':
        bevel()
        if kind == 'electric' and width >= 5 and height >= 6:
            # One simple copper trace and block contact pad.
            x = width//2
            line([(x,1),(x,height//2),(max(1,x-2),height//2),(max(1,x-2),height-2)],low)
            rect((max(1,x-1),1,min(width-2,x+1),2),hi)
        elif kind == 'grass':
            if min(width,height)>=6:
                line([(width//2,1),(width//2,height-2)],low)
                line([(width//2,height//2),(max(1,width//2-2),height//2-2)],hi)
        else:
            if height > 4:line([(1,2),(max(1,width-2),2)],hi)

    else:
        # Main stone / ceramic plates: large quiet areas, edge chips, only
        # sparse clustered marks. Tiny armor parts get no noisy grain at all.
        bevel()
        if min(width,height) >= 5:
            for _ in range(max(1,width*height//90)):
                x=rng.randrange(1,max(2,width-2));y=rng.randrange(1,max(2,height-2))
                color=mid if rng.random()<.7 else hi
                rect((x,y,min(width-2,x+rng.choice([0,1,2])),y),color)
            if kind not in ('electric','water') and rng.random()<.55 and height>7:
                x=rng.randrange(2,width-1)
                y=rng.randrange(1,max(2,height//3))
                crack=[(x,y),(x,y+2),(max(1,x-1),y+2),(max(1,x-1),min(height-2,y+4))]
                line(crack,low)
            if kind=='grass' and material=='stone':
                moss=_mix(base,_rgb(palette['leaf']),.5)
                # Moss hugs one top corner, leaving the center plane quiet.
                if rng.random()<.65:
                    rect((1,1,min(width-2,3),2),moss)
                    if height>6:rect((1,3,2,3),moss)
            elif kind=='fire' and material in ('stone','dark') and width>8 and height>9 and rng.random()<.45:
                c=_mix(_rgb(palette['hot']),base,.6)
                x=rng.randrange(2,width-2)
                line([(x,1),(x,3),(x-1,3),(x-1,5)],c)
            elif kind in ('electric','water') and width>8 and height>8:
                # Ceramic inset corner lines sharpen the crafted aesthetic.
                line([(2,4),(2,2),(min(width-3,5),2)],_mix(base,_rgb(palette['trim']),.23))

    return image

