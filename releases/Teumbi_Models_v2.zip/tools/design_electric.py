"""Original lightning conductor constructs: apprentice and mature storm oracle."""


def build(m, stage):
    if stage == 2:
        apprentice(m)
    else:
        oracle(m)


def apprentice(m):
    m.bone('body', pivot=(0, 12, 0))
    m.bone('core', pivot=(0, 13.6, -.2), parent='body')
    m.bone('head', pivot=(0, 18, 0), parent='body')
    m.bone('left_arm', pivot=(-3.9, 15.6, 0), parent='body', rotation=(0, 0, -7))
    m.bone('right_arm', pivot=(3.9, 15.6, 0), parent='body', rotation=(-8, 0, 8))
    m.bone('left_leg', pivot=(-1.35, 8.5, .1), parent='body')
    m.bone('right_leg', pivot=(1.35, 8.5, .1), parent='body')
    m.bone('conductor', pivot=(3.8, 12, 1.8), parent='body')
    B = lambda n, p, s, mat='stone', bone='body', **kw: m.box(n, p, s, mat, bone, **kw)
    # An incomplete cage protects one luminous core, rather than a solid chest.
    B('spinal_ceramic', (-1.2, 10, 1), (2.4, 6.4, 1.4), 'dark')
    B('upper_yoke', (-2.8, 16, -.9), (5.6, 1.1, 2.5), 'light')
    B('collar_band', (-1.5, 17.1, -.6), (3, .6, 1.8), 'trim')
    B('waist_belt', (-2.1, 10, -1), (4.2, 1.2, 2.7), 'trim')
    B('waist_under', (-1.4, 8.9, -.7), (2.8, 1.1, 2.2), 'dark')
    for side in [-1, 1]:
        B('chest_edge', (side*2.2-.35, 11.4, -.8), (.7, 3.5, 1.6), 'light')
        B('collar_point', (side*2.4-.45, 15.3, -1.3), (.9, 1.2, 1.1), 'accent')
    B('heart', (-1.25, 12.4, -1.5), (2.5, 2.5, 2.5), 'glow', 'core', rotation=(0, 20, 0), pivot=(0,13.65,-.25))
    B('heart_inner', (-.65, 13.0, -1.62), (1.3, 1.3, .2), 'eye', 'core')
    # Apprentice hood and unmistakable tiny rectangular gaze.
    B('helmet_back', (-2, 18, -.2), (4, 3.6, 2.2), 'light', 'head')
    B('mask_dark', (-1.7, 18.3, -1.55), (3.4, 2.5, 1.4), 'dark', 'head')
    B('helmet_brow', (-2.1, 20.7, -1.7), (4.2, .8, 2.8), 'light', 'head')
    B('chin', (-1.25, 17.9, -1.7), (2.5, .5, 2.3), 'trim', 'head')
    for side in [-1,1]:
        B('eye', (side*.95-.35, 19.1, -1.7), (.7, .65, .22), 'eye', 'head')
        B('temple', (side*1.9-.3, 18.5, -1.6), (.6, 2.5, 1.2), 'light', 'head')
        B('temple_fin', (side*2.2-.25, 20, .1), (.5, 2.1, 1.1), 'trim', 'head')
    B('crown_single', (-.35, 21.4, -.25), (.7, 2.1, .7), 'metal', 'head')
    B('crown_tip', (-.55, 23.3, -.45), (1.1, .6, 1.1), 'accent', 'head')
    for side, limb in [(-1,'left'),(1,'right')]:
        arm=limb+'_arm'; leg=limb+'_leg'; x=side*3.9
        B('shoulder_armor', (x-1.05,14.6,-1.2), (2.1,2.1,2.4),'light',arm)
        B('shoulder_gilt', (x-1.2,16.1,-1.3),(2.4,.4,2.6),'trim',arm)
        B('upper_arm', (x-.45,12.3,-.45),(.9,2.1,.9),'dark',arm)
        B('elbow_ring',(x-.8,11.7,-.8),(1.6,.6,1.6),'metal',arm)
        B('bracer',(x-.8,9.8,-.9),(1.6,1.9,1.8),'light',arm)
        B('bracer_circuit',(x-.2,10,-1.02),(.4,1.6,.2),'accent',arm)
        B('hand',(x-.6,8.8,-.7),(1.2,.9,1.4),'dark',arm)
        B('hand_glint',(x-.3,9,-.85),(.6,.5,.2),'glow',arm)
        xx=side*1.35
        B('thigh',(xx-.7,5.5,-.65),(1.4,3,1.7),'dark',leg)
        B('knee_cap',(xx-.8,4.8,-1.05),(1.6,.8,1.2),'trim',leg)
        B('boot',(xx-.65,1,-.9),(1.3,3.7,1.8),'light',leg)
        B('foot',(xx-.8,.3,-1.8),(1.6,.8,2.7),'dark',leg)
        B('boot_front_inlay',(xx-.15,1.4,-1.03),(.3,2.6,.2),'accent',leg)
        # Side coat panels remain separate from limbs and leave a central slit.
        B('coat_panel',(side*2.45-.6,5.7,.65),(1.2,4.3,1.1),'light',rotation=(0,0,-side*9),pivot=(side*2,10,1))
        B('coat_tip',(side*2.95-.5,4.8,.65),(1,1,1.1),'trim')
    B('rod_spine_mount',(1.2,13.7,1.4),(2.8,.8,.8),'metal')
    B('rod_lower',(3.55,9.5,1.65),(.65,12,.65),'metal','conductor')
    B('rod_band',(3.3,17.6,1.4),(1.15,.7,1.15),'accent','conductor')
    B('rod_upper',(3.6,21.5,1.7),(.55,3.7,.55),'trim','conductor')
    B('collector_block',(3.1,25,1.2),(1.55,.7,1.55),'accent','conductor')
    B('collector_prong',(3.55,25.7,1.65),(.65,1.3,.65),'glow','conductor')


def oracle(m):
    m.bone('body', pivot=(0, 17, 0))
    m.bone('core', pivot=(0, 22, -.15), parent='body')
    m.bone('head', pivot=(0, 27.3, .1), parent='body')
    m.bone('left_arm', pivot=(-5, 24.3, 0), parent='body', rotation=(0,0,-10))
    m.bone('right_arm', pivot=(5, 24.3, 0), parent='body', rotation=(-12,0,12))
    m.bone('left_leg', pivot=(-1.6, 13, .2), parent='body')
    m.bone('right_leg', pivot=(1.6, 13, .2), parent='body')
    m.bone('conductor', pivot=(6.8, 23, 2.8), parent='body')
    B = lambda n,p,s,mat='stone',bone='body',**kw: m.box(n,p,s,mat,bone,**kw)
    # Open ribcage with a thin dark rear spine and separated porcelain ribs.
    B('spine',(-.8,15,1.6),(1.6,11,1),'dark')
    B('upper_yoke',(-3.6,25,-1),(7.2,1.2,3),'light')
    B('collar_gilt',(-2.1,26.2,-.7),(4.2,.55,2.4),'trim')
    B('waist_belt',(-2.5,15.5,-1.3),(5,1,3.3),'metal')
    B('waist_upper',(-1.8,16.5,-1),(3.6,.65,2.6),'light')
    B('waist_dark',(-1.9,13.1,-.8),(3.8,2.3,2.7),'dark')
    B('front_belt_clasp',(-.8,15.3,-1.6),(1.6,1.5,.5),'accent')
    for side in [-1,1]:
        B('floating_rib',(side*3-.45,18.3,-1),(.9,4.9,2.4),'light',rotation=(0,0,-side*8),pivot=(side*3,23,0))
        B('floating_rib_gilt',(side*3-.5,18.2,-1.3),(1,.55,2.8),'trim')
        B('collar_arrow',(side*3.2-.5,24.1,-1.9),(1,1.5,1.1),'accent')
    B('heart',(-1.6,20.35,-1.75),(3.2,3.2,3.2),'glow','core',rotation=(0,25,0),pivot=(0,21.95,-.15))
    B('heart_sigil',(-.55,21.2,-1.9),(1.1,1.5,.18),'eye','core')
    # Hoodless ceramic face with long temple vanes, not a featureless robot cube.
    B('helmet_rear',(-2.55,28,-.3),(5.1,4.5,2.9),'light','head')
    B('face_dark',(-2.15,28.05,-2.05),(4.3,3.2,1.85),'dark','head')
    B('brow',(-2.7,31.3,-2.15),(5.4,1,3.5),'light','head')
    B('brow_gold',(-2.4,31.15,-2.38),(4.8,.4,.5),'trim','head')
    B('chin',(-1.1,27.7,-2.15),(2.2,.6,2.4),'light','head')
    B('forehead_sigil',(-.5,31.7,-2.3),(1,1.4,.5),'accent','head')
    for side in [-1,1]:
        B('eye',(side*1.25-.5,29.25,-2.22),(1,.65,.22),'eye','head')
        B('eye_tail',(side*1.75-.18,29.75,-2.2),(.36,.5,.2),'glow','head')
        B('cheek_plate',(side*2.3-.35,28.15,-2.1),(.7,2.7,1.4),'light','head')
        B('temple_fin',(side*2.9-.3,29.3,-.1),(.6,4.3,1.7),'trim','head',rotation=(0,0,-side*15),pivot=(side*2.9,29.3,.6))
        B('temple_tip',(side*3.3-.35,33.2,-.2),(.7,1.9,.9),'accent','head')
        B('rear_head_panel',(side*1.6-.6,26.7,2),(1.2,4.7,.7),'light','head')
        B('crown_branch',(side*1.15-.3,32.3,.5),(.6,3,.6),'metal','head')
        B('crown_terminal',(side*1.15-.6,35.1,.2),(1.2,.8,1.2),'accent','head')
    B('crown_center',(-.3,32.3,.5),(.6,4.8,.6),'metal','head')
    B('crown_center_terminal',(-.65,36.9,.15),(1.3,.9,1.3),'glow','head')
    for side,limb in [(-1,'left'),(1,'right')]:
        arm=limb+'_arm';leg=limb+'_leg';x=side*5
        B('shoulder_inner',(x-1.2,23.3,-1.2),(2.4,2.8,2.6),'dark',arm)
        B('shoulder_porcelain',(x-1.65,24,-1.7),(3.3,1.9,3.6),'light',arm)
        B('shoulder_gold',(x-1.8,25.8,-1.8),(3.6,.45,3.8),'trim',arm)
        B('shoulder_wing',(x-2,26.1,-1),(4,.6,2),'light',arm,rotation=(0,0,side*12),pivot=(x,26,0))
        B('upper_arm',(x-.6,19.4,-.6),(1.2,3.7,1.2),'dark',arm)
        B('upper_arm_conductor',(x-.2,19.8,-.78),(.4,2.9,.25),'accent',arm)
        B('elbow_cuff',(x-1,18.4,-1),(2,1,2),'metal',arm)
        B('bracer',(x-1.05,15.1,-1.25),(2.1,3.1,2.5),'light',arm)
        B('bracer_gold',(x-1.15,15,-1.35),(2.3,.55,2.7),'trim',arm)
        B('bracer_channel',(x-.35,15.8,-1.4),(.7,1.6,.2),'accent',arm)
        B('wrist',(x-.5,14.3,-.65),(1,.65,1.3),'dark',arm)
        B('hand',(x-.8,12.8,-1.15),(1.6,1.4,1.9),'light',arm)
        B('palm_conductor',(x-.4,13.05,-1.35),(.8,.8,.25),'glow',arm)
        xx=side*1.6
        B('thigh',(xx-.85,8,-.6),(1.7,4.6,2.1),'dark',leg)
        B('thigh_plate',(xx-.9,9,-.9),(1.8,3.2,.6),'light',leg)
        B('knee',(xx-.9,7,-1),(1.8,1,2.2),'trim',leg)
        B('shin',(xx-.7,2.2,-.7),(1.4,4.6,1.8),'light',leg)
        B('shin_circuit',(xx-.2,2.6,-.9),(.4,3.6,.25),'accent',leg)
        B('heel',(xx-.8,.7,-.5),(1.6,1.4,1.8),'dark',leg)
        B('toe',(xx-.8,.6,-2.1),(1.6,.9,2.2),'light',leg)
        B('toe_gold',(xx-.9,.6,-2.25),(1.8,.45,.4),'trim',leg)
        # Three offset angular coat panels per side form a long open silhouette.
        for j in range(3):
            px=side*(2.7+j*.65);pz=.8+j*.75; py=3.6+j*.45
            B('coat_panel',(px-.6,py,pz),(1.2,10.8-j*.5,.8),'light',rotation=(0,side*8,-side*(8+j*3)),pivot=(side*2.4,14.3,pz))
            B('coat_gilt',(px-.6,py,pz-.06),(1.2,.75,.95),'trim',rotation=(0,side*8,-side*(8+j*3)),pivot=(side*2.4,14.3,pz))
    # A lightning-collector staff is mechanically linked to the back, not held.
    B('back_bracket',(1,21,2),(6,.9,1),'metal')
    B('back_bracket_upper',(3,24,2),(4,.7,.8),'trim')
    B('staff_shaft',(6.6,11,2.6),(.8,27,.8),'metal','conductor')
    B('staff_base',(6.35,10.4,2.35),(1.3,1.8,1.3),'dark','conductor')
    for y in [16,24,31,36.5]:
        B('staff_collar',(6.3,y,2.3),(1.4,.65,1.4),'trim','conductor')
        B('staff_collar_light',(6.55,y+.65,2.55),(.9,.35,.9),'accent','conductor')
    B('collector_bar',(3.5,37.5,2.25),(7,.85,1.5),'trim','conductor')
    for xx,yy,hh in [(3.5,38.3,3),(6.55,38.3,5),(9.7,38.3,3)]:
        B('collector_prong',(xx,yy,2.6),(.8,hh,.8),'metal','conductor')
        B('collector_terminal',(xx-.35,yy+hh,2.25),(1.5,1.1,1.5),'glow','conductor')
