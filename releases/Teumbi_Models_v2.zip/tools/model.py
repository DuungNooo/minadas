"""Cuboid authoring and lossless Blockbench/Bedrock export, no mesh smoothing."""
import base64, hashlib, io, json, math, pathlib, uuid
from PIL import Image
from textures import tile

def uid(text): return str(uuid.uuid5(uuid.NAMESPACE_DNS, 'teumbi.v2.'+text))
FACE_DIMS={'north':(0,1),'south':(0,1),'east':(2,1),'west':(2,1),'up':(0,2),'down':(0,2)}

def bedrock_pivot(vector):
    """Blockbench's editor X axis is reflected in the Bedrock codec."""
    return [-vector[0], vector[1], vector[2]]

def bedrock_rotation(vector):
    return [-vector[0], -vector[1], vector[2]]

def bedrock_keyframe(channel, vector):
    """Canonical editor motion -> Bedrock and legacy .bbmodel 4.x motion.

    Reference: Blockbench's bedrock_animation.js importer/exporter and the
    bbmodel.js export_legacy_project compatibility path. Modern Blockbench
    flips these same channels while importing a 4.10 project.
    """
    def negate(value):
        return -value if isinstance(value, (int, float)) else f'-({value})'
    result = list(vector)
    if channel in ('position', 'rotation'):
        result[0] = negate(result[0])
    if channel == 'rotation':
        result[1] = negate(result[1])
    return result

def bedrock_face(face, uv):
    x, y, x2, y2 = uv
    if face in ('up', 'down'):
        return {'uv': [x2, y2], 'uv_size': [x-x2, y-y2]}
    return {'uv': [x, y], 'uv_size': [x2-x, y2-y]}

class Model:
    def __init__(self,name,kind,stage):
        self.name,self.kind,self.stage=name,kind,stage
        self.bones=[]; self.boxes=[]; self.animations={}
        self.bone('root',parent=None)
    def bone(self,name,pivot=(0,0,0),parent='root',rotation=(0,0,0)):
        assert name not in {b['name'] for b in self.bones},name
        assert parent is None or parent in {b['name'] for b in self.bones},parent
        self.bones.append(dict(name=name,pivot=list(pivot),parent=parent,rotation=list(rotation)))
        return name
    def box(self,name,origin,size,material='stone',bone='body',rotation=(0,0,0),pivot=None):
        assert bone in {b['name'] for b in self.bones},bone
        assert len(size)==3 and min(size)>0,(name,size)
        base=name; counter=2; existing={b['name'] for b in self.boxes}
        while name in existing:name=base+'_'+str(counter);counter+=1
        self.boxes.append(dict(name=name,origin=list(origin),size=list(size),material=material,bone=bone,rotation=list(rotation),pivot=list(pivot) if pivot is not None else [origin[i]+size[i]/2 for i in range(3)]))
    def animate(self):
        names={b['name'] for b in self.bones}
        idle={'root':{'position':{'0.0':[0,0,0],'1.0':[0,.28,0],'2.0':[0,0,0]}}}
        if 'core' in names:idle['core']={'rotation':{'0.0':[0,0,0],'2.0':[0,180,0],'4.0':[0,360,0]},'position':{'0.0':[0,0,0],'1.0':[0,.22,0],'2.0':[0,0,0],'3.0':[0,-.12,0],'4.0':[0,0,0]}}
        if self.kind=='normal':
            for i,n in enumerate(['shell_left','shell_right','shell_bottom','crown','orbit']):
                if n in names:idle[n]={'rotation':{'0.0':[0,0,0],'2.0':[0,0,(-1 if i%2 else 1)*3],'4.0':[0,0,0]}}
        elif 'head' in names:idle['head']={'rotation':{'0.0':[0,-3,0],'2.0':[0,3,0],'4.0':[0,-3,0]}}
        walk={'root':{'position':{'0.0':[0,0,0],'.25':[0,.35,0],'.5':[0,0,0],'.75':[0,.35,0],'1.0':[0,0,0]}}}
        for n,sgn in [('left_leg',1),('right_leg',-1),('left_arm',-1),('right_arm',1)]:
            if n in names:
                angle=18 if n.endswith('leg') else (3 if self.kind=='grass' else 7)
                walk[n]={'rotation':{'0.0':[sgn*angle,0,0],'.5':[-sgn*angle,0,0],'1.0':[sgn*angle,0,0]}}
        action={}
        if self.kind=='fire':
            for n in ['left_arm','right_arm']:
                if n in names:action[n]={'rotation':{'0.0':[0,0,0],'.25':[-65,0,0],'.45':[35,0,0],'.85':[0,0,0]}}
        elif self.kind=='grass':
            action['body']={'rotation':{'0.0':[0,0,0],'.3':[5,0,0],'.8':[5,0,0],'1.2':[0,0,0]}}
            for n in ['left_arm','right_arm']:
                if n in names:action[n]={'position':{'0.0':[0,0,0],'.3':[0,.8,-.5],'.8':[0,.8,-.5],'1.2':[0,0,0]}}
        elif self.kind in ['water','electric']:
            if 'left_arm' in names:action['left_arm']={'rotation':{'0.0':[0,0,0],'.3':[-35,0,-15],'.7':[-35,0,-15],'1.2':[0,0,0]}}
            if 'right_arm' in names:action['right_arm']={'rotation':{'0.0':[0,0,0],'.3':[-15,0,10],'.7':[-25,0,10],'1.2':[0,0,0]}}
        else:action={'root':{'position':{'0.0':[0,0,0],'.25':[0,1,-1],'.5':[0,0,0]}}}
        self.animations={'idle':{'loop':True,'animation_length':4,'bones':idle},'walk':{'loop':True,'animation_length':1,'bones':walk},('guard' if self.kind=='grass' else 'perform' if self.kind=='water' else 'attack'):{'loop':False,'animation_length':1.2 if self.kind!='fire' else .85,'bones':action}}
    def export(self,out):
        out=pathlib.Path(out);(out/'textures').mkdir(parents=True,exist_ok=True)
        # Pixel density follows physical face dimensions; atlas faces never overlap.
        faces=[]
        for i,b in enumerate(self.boxes):
            b['uv']={}
            for f,(a,c) in FACE_DIMS.items():
                w=max(2,math.ceil(b['size'][a]*2));h=max(2,math.ceil(b['size'][c]*2))
                faces.append((i,f,w,h))
        for resolution in [128,256,512,1024]:
            x=y=1;row=0;placements=[]
            for i,f,w,h in faces:
                if x+w+1>resolution:x=1;y+=row+2;row=0
                if y+h+1>resolution:break
                placements.append((i,f,x,y,w,h));x+=w+2;row=max(row,h)
            if len(placements)==len(faces):break
        assert len(placements)==len(faces),'Atlas overflow'
        atlas=Image.new('RGBA',(resolution,resolution),(0,0,0,0));emissive=Image.new('RGBA',atlas.size,(0,0,0,0))
        for i,f,x,y,w,h in placements:
            b=self.boxes[i]
            t=tile(self.kind,b['material'],w,h,f'{self.name}.{b["name"]}.{f}',f)
            atlas.paste(t,(x,y));b['uv'][f]=[x,y,x+w,y+h]
            # Pad borders to keep texture filtering safe.
            atlas.paste(t.crop((0,0,w,1)),(x,y-1));atlas.paste(t.crop((0,h-1,w,h)),(x,y+h))
            atlas.paste(t.crop((0,0,1,h)),(x-1,y));atlas.paste(t.crop((w-1,0,w,h)),(x+w,y))
            if b['material'] in ['glow','eye','hot']:emissive.paste(t,(x,y))
        atlas.save(out/'textures'/f'{self.name}.png');emissive.save(out/'textures'/f'{self.name}_emissive.png')
        encoded=io.BytesIO();atlas.save(encoded,format='PNG')
        groups={};bones=[];elements=[]
        for b in self.bones:
            g={'name':b['name'],'origin':b['pivot'],'rotation':b['rotation'],'uuid':uid(self.name+'.bone.'+b['name']),'children':[],'export':True,'isOpen':False,'visibility':True}
            groups[b['name']]=g
            if b['parent']:groups[b['parent']]['children'].append(g)
            bone={'name':b['name'],'pivot':bedrock_pivot(b['pivot']),'rotation':bedrock_rotation(b['rotation']),'cubes':[]}
            if b['parent']:bone['parent']=b['parent']
            bones.append(bone)
        for b in self.boxes:
            e={'name':b['name'],'uuid':uid(self.name+'.box.'+b['name']),'type':'cube','from':b['origin'],'to':[round(b['origin'][i]+b['size'][i],5) for i in range(3)],'origin':b['pivot'],'rotation':b['rotation'],'box_uv':False,'rescale':False,'autouv':0,'visibility':True,'export':True,'faces':{f:{'uv':uv,'texture':0,'rotation':0} for f,uv in b['uv'].items()}}
            elements.append(e);groups[b['bone']]['children'].append(e['uuid'])
            c={'origin':[-b['origin'][0]-b['size'][0],b['origin'][1],b['origin'][2]],'size':b['size'],'uv':{f:bedrock_face(f,uv) for f,uv in b['uv'].items()}}
            if any(b['rotation']):c.update(rotation=bedrock_rotation(b['rotation']),pivot=bedrock_pivot(b['pivot']))
            next(v for v in bones if v['name']==b['bone'])['cubes'].append(c)
        anims=[]
        for n,a in self.animations.items():
            animators={}
            for bn,channels in a['bones'].items():
                keyframes=[]
                for channel,frames in channels.items():
                    for time,vec in frames.items():keyframes.append({'channel':channel,'time':float(time),'interpolation':'linear','data_points':[dict(zip(['x','y','z'],[str(v) for v in bedrock_keyframe(channel,vec)]))],'uuid':uid(self.name+n+bn+channel+time)})
                animators[groups[bn]['uuid']]={'name':bn,'type':'bone','keyframes':keyframes}
            anims.append({'uuid':uid(self.name+n),'name':f'animation.{self.name}.{n}','loop':'loop' if a['loop'] else 'once','override':False,'length':a['animation_length'],'snapping':24,'animators':animators})
        bb={'meta':{'format_version':'4.10','model_format':'bedrock','box_uv':False},'name':self.name,'model_identifier':self.name,'visible_box':[5,5,2],'resolution':{'width':resolution,'height':resolution},'elements':elements,'outliner':[groups['root']],'textures':[{'path':f'../textures/{self.name}.png','name':self.name+'.png','uuid':uid(self.name+'.texture'),'id':'0','folder':'','namespace':'','mode':'bitmap','saved':True,'visible':True,'render_mode':'default','width':resolution,'height':resolution,'uv_width':resolution,'uv_height':resolution,'source':'data:image/png;base64,'+base64.b64encode(encoded.getvalue()).decode()}],'animations':anims}
        geometry={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':f'geometry.{self.name}','texture_width':resolution,'texture_height':resolution,'visible_bounds_width':5,'visible_bounds_height':6,'visible_bounds_offset':[0,1.5,0]},'bones':bones}]}
        def write(folder,file,data):
            p=out/folder/file;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
        write('blockbench',self.name+'.bbmodel',bb)
        write('models',self.name+'.geo.json',geometry)
        runtime_animations={}
        for n,a in self.animations.items():
            runtime_animations[f'animation.{self.name}.{n}']={
                'loop':a['loop'], 'animation_length':a['animation_length'],
                'bones':{bn:{channel:{time:bedrock_keyframe(channel,vec) for time,vec in frames.items()} for channel,frames in channels.items()} for bn,channels in a['bones'].items()}
            }
        write('animations',self.name+'.animation.json',{'format_version':'1.8.0','animations':runtime_animations})
        write('source',self.name+'.json',{'name':self.name,'kind':self.kind,'stage':self.stage,'bones':self.bones,'boxes':self.boxes,'texture_size':resolution})
        return {'name':self.name,'kind':self.kind,'stage':self.stage,'cubes':len(elements),'bones':len(bones),'texture_size':resolution,'animations':list(self.animations)}
