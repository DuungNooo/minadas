/* Capture exact viewer poses for short GIFs or motion strips. */
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const os=require('os');
(async()=>{
 const root=__dirname,args=process.argv.slice(2);
 const options={clip:'special',view:'threequarter',compare:args.includes('--compare-electric'),kinds:[]};
 for(let i=0;i<args.length;i++){
  if(args[i]==='--clip')options.clip=args[++i];
  else if(args[i]==='--view')options.view=args[++i];
  else if(args[i]==='--compare-electric')continue;
  else if(args[i].startsWith('--'))throw Error('Unknown option '+args[i]);
  else options.kinds.push(args[i]);
 }
 if(!['front','side','threequarter'].includes(options.view))throw Error('Unknown view '+options.view);
 const out=path.join(os.tmpdir(),'teumbi-v5-motion-frames',options.clip+'-'+options.view);fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 if(options.compare){await electricComparison(root,browser);await browser.close();return}
 const page=await browser.newPage({viewport:{width:1020,height:720},deviceScaleFactor:1});
 const html=fs.readFileSync(path.join(root,'pack/VIEW_MODELS.html'),'utf8');
 await page.setContent(html);
 await page.addStyleTag({content:'html,body{background:transparent!important}main{grid-template-columns:300px 720px;min-height:720px}section{min-height:720px;height:720px;width:720px;background:transparent!important}#top,#badge,.help{display:none}aside{max-height:720px;overflow:hidden}'});
 await page.waitForFunction(()=>viewer.getState().ready);
 const kinds=options.kinds.length?options.kinds:['fire','electric','grass','water'];
 for(const kind of kinds){
  const name=kind==='normal'?'teumbi':`teumbi_${kind}_3`;
  await page.selectOption('#model',name);await page.waitForFunction(()=>viewer.getState().ready);
  const key=await page.locator('#animation option').evaluateAll((v,clip)=>v.find(x=>x.value.endsWith('.'+clip))?.value,options.clip);
  if(!key)throw Error('No '+options.clip+' clip for '+name);
  await page.selectOption('#animation',key);
  const len=await page.evaluate(()=>selectedAnimation().animation_length);
  await page.evaluate(({view})=>{viewer.setView(view==='side'?Math.PI/2:view==='front'?.12:.48,.12,1);viewer.fitMotion();viewer.setTime(0)},{view:options.view});
  const dir=path.join(out,kind);fs.rmSync(dir,{recursive:true,force:true});fs.mkdirSync(dir,{recursive:true});
  const frames=Math.max(32,Math.min(64,Math.ceil(len*15)+1));
  for(let i=0;i<frames;i++){
   await page.evaluate(({t})=>viewer.setTime(t),{t:len*i/(frames-1)});
   await page.locator('#canvas').screenshot({path:path.join(dir,String(i).padStart(3,'0')+'.png'),omitBackground:true});
  }
  const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
  const record={kind,name,animation:key,clip:options.clip,view:options.view,duration:len,frames,source_sha256:sha(fs.readFileSync(path.join(root,'pack/source',name+'.json'))),texture_sha256:sha(fs.readFileSync(path.join(root,'pack/textures',name+'.png'))),html_sha256:sha(html),alpha_cutout:true,background:'transparent'};
  fs.writeFileSync(path.join(dir,'timing.json'),JSON.stringify(record));
  const stem='motion-'+kind+(options.clip==='special'?'':'-'+options.clip)+(options.view==='threequarter'?'':'-'+options.view);
  fs.writeFileSync(path.join(root,'pack/previews',stem+'.render.json'),JSON.stringify(record,null,2));
  console.log('Captured',kind,frames,'frames across',len,'seconds');
 }
 assembleGifs(root,out,options.clip,options.view);
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});

function assembleGifs(root,out,clip,view){
 const {spawnSync}=require('child_process');
 const code=String.raw`
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json,sys
r=Path(sys.argv[1]); out=Path(sys.argv[2]);clip=sys.argv[3];view=sys.argv[4];models=[]
for kind in ['fire','electric','grass','water']:
 d=out/kind
 if not (d/'timing.json').exists():continue
 info=json.loads((d/'timing.json').read_text());frames=[Image.open(f).convert('RGBA').resize((512,512),Image.Resampling.LANCZOS) for f in sorted(d.glob('*.png'))]
 sample=Image.new('RGB',(768,512))
 for i in range(24):
  f=frames[round(i*(len(frames)-1)/23)].resize((128,128));sample.paste(f,((i%6)*128,(i//6)*128),f)
 palette=sample.quantize(colors=255,method=Image.Quantize.MEDIANCUT)
 palette.putpalette(palette.getpalette()[:765]+[255,0,255])
 encoded=[]
 for f in frames:
  background=Image.new('RGB',f.size,'#e8eddf');background.paste(f,mask=f.getchannel('A'))
  indexed=background.quantize(palette=palette,dither=Image.Dither.NONE)
  indexed.paste(255,mask=f.getchannel('A').point(lambda alpha:255 if alpha<128 else 0));encoded.append(indexed)
 ms=max(30,round(info['duration']*1000/(len(frames)-1)));dur=[ms]*len(frames);dur[-1]=450
 stem='motion-'+kind+('' if clip=='special' else '-'+clip)+('' if view=='threequarter' else '-'+view)
 encoded[0].save(r/'pack/previews'/(stem+'.gif'),save_all=True,append_images=encoded[1:],duration=dur,loop=0,disposal=2,optimize=False,transparency=255,background=255)
 models.append((kind,info,frames))
if len(models)==4 and clip=='special' and view=='threequarter':
 maxlen=max(v['duration'] for k,v,f in models); allframes=[]
 labels={'fire':'불꽃 · 도끼 강타','electric':'전기 · 축전 방출','grass':'풀 · 방패 격돌','water':'물 · 물결 연주'}
 fontpath=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc');font=ImageFont.truetype(str(fontpath),19) if fontpath.exists() else ImageFont.load_default()
 for j in range(48):
  t=j/47*maxlen;im=Image.new('RGB',(1280,365),'#edf2e6');dr=ImageDraw.Draw(im)
  for i,(kind,info,frames) in enumerate(models):
   index=min(len(frames)-1,round(t/info['duration']*(len(frames)-1)))
   frame=frames[index].resize((320,320),Image.Resampling.LANCZOS);im.paste(frame,(i*320,45),frame);dr.text((i*320+16,10),labels[kind],fill='#294238',font=font)
  allframes.append(im)
 sample=Image.new('RGB',(1280,365*4))
 for j,index in enumerate([0,12,24,36]):sample.paste(allframes[index],(0,j*365))
 palette=sample.quantize(colors=192);encoded=[f.quantize(palette=palette,dither=Image.Dither.NONE) for f in allframes];dur=[round(maxlen*1000/47)]*48;dur[-1]=500
 encoded[0].save(r/'pack/previews/role-motions.gif',save_all=True,append_images=encoded[1:],duration=dur,loop=0,disposal=2,optimize=False)
 print('Created 4 individual motion GIFs and simultaneous role-motions.gif')
`;
 const r=spawnSync('python',['-c',code,root,out,clip,view],{stdio:'inherit'});if(r.status!==0)throw new Error('GIF assembly failed');
}

async function electricComparison(root,browser){
 const output=path.join(os.tmpdir(),'teumbi-v5-electric-attack-comparison');fs.mkdirSync(output,{recursive:true});
 const versions=[{label:'V4',root:path.resolve(root,'../teumbi-v4')},{label:'V5',root}];
 const name='teumbi_electric_3',cases=[];
 const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
 for(const version of versions){
  const file=path.join(version.root,'pack/VIEW_MODELS.html');
  if(!fs.existsSync(file))throw Error('Comparison reference is unavailable: '+file);
  version.html=fs.readFileSync(file,'utf8');
  version.page=await browser.newPage({viewport:{width:1020,height:720},deviceScaleFactor:1});
  await version.page.setContent(version.html);
  await version.page.addStyleTag({content:'html,body{background:transparent!important}main{grid-template-columns:300px 720px;min-height:720px}section{min-height:720px;height:720px;width:720px;background:transparent!important}#top,#badge,.help{display:none}aside{max-height:720px;overflow:hidden}'});
  await version.page.waitForFunction(()=>viewer.getState().ready);
  await version.page.selectOption('#model',name);await version.page.waitForFunction(()=>viewer.getState().ready);
  const key=await version.page.locator('#animation option').evaluateAll(v=>v.find(x=>x.value.endsWith('.attack')).value);
  await version.page.selectOption('#animation',key);
  version.duration=await version.page.evaluate(()=>selectedAnimation().animation_length);
  version.key=key;version.sourceSha=sha(fs.readFileSync(path.join(version.root,'pack/source',name+'.json')));
 }
 const length=Math.max(...versions.map(v=>v.duration)),frames=Math.max(32,Math.ceil(length*18)+1);
 for(const [view,yaw] of [['front',.12],['side',Math.PI/2]])for(const version of versions){
  const dir=path.join(output,version.label.toLowerCase()+'-'+view);fs.rmSync(dir,{recursive:true,force:true});fs.mkdirSync(dir,{recursive:true});
  await version.page.evaluate(({yaw})=>{viewer.pause();viewer.setView(yaw,.1,1);fitMotion();viewer.setTime(0)},{yaw});
  for(let i=0;i<frames;i++){
   await version.page.evaluate(({t})=>viewer.setTime(t),{t:Math.min(version.duration,length*i/(frames-1))});
   await version.page.locator('#canvas').screenshot({path:path.join(dir,String(i).padStart(3,'0')+'.png'),omitBackground:true});
  }
  const record={version:version.label,name,view,animation:version.key,duration:version.duration,sampleDuration:length,frames,source_sha256:version.sourceSha,texture_sha256:sha(fs.readFileSync(path.join(version.root,'pack/textures',name+'.png'))),html_sha256:sha(version.html),alpha_cutout:true,background:'transparent'};
  fs.writeFileSync(path.join(dir,'timing.json'),JSON.stringify(record,null,2));cases.push(record);
  if(version.label==='V5')fs.writeFileSync(path.join(root,'pack/previews','motion-electric-attack-'+view+'.render.json'),JSON.stringify(record,null,2));
  console.log('Captured electric attack',version.label,view,frames,'frames');
 }
 const current=cases.find(c=>c.version==='V5');
 fs.writeFileSync(path.join(root,'pack/previews/electric-attack-before-after.render.json'),JSON.stringify({name,view:'electric_attack_comparison',source_sha256:current.source_sha256,texture_sha256:current.texture_sha256,html_sha256:current.html_sha256,reference_version:'V4',reference_source_sha256:versions[0].sourceSha,duration:length,frames,cases},null,2));
 const {spawnSync}=require('child_process');
 const python=String.raw`
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,sys
r=Path(sys.argv[1]);temp=Path(sys.argv[2]);out=r/'pack/previews';cases={}
for folder in sorted(temp.iterdir()):
 if not (folder/'timing.json').exists():continue
 info=json.loads((folder/'timing.json').read_text());images=[Image.open(f).convert('RGBA') for f in sorted(folder.glob('*.png'))]
 cases[(info['version'],info['view'])]=(info,images)
fontpath=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc')
font=ImageFont.truetype(str(fontpath),19) if fontpath.exists() else ImageFont.load_default()
def save_gif(images,destination,duration,transparent=False):
 sample=Image.new('RGB',(512*4,512),'#e8eddf')
 for j,fraction in enumerate([0,.3,.5,.8]):
  frame=images[round((len(images)-1)*fraction)].convert('RGBA').resize((512,512));sample.paste(frame,(j*512,0),frame)
 palette=sample.quantize(colors=255,method=Image.Quantize.MEDIANCUT);palette.putpalette(palette.getpalette()[:765]+[255,0,255]);encoded=[]
 for frame in images:
  f=frame.convert('RGBA');rgb=Image.new('RGB',f.size,'#e8eddf');rgb.paste(f,mask=f.getchannel('A'));indexed=rgb.quantize(palette=palette,dither=Image.Dither.NONE)
  if transparent:indexed.paste(255,mask=f.getchannel('A').point(lambda alpha:255 if alpha<128 else 0))
  encoded.append(indexed)
 times=[max(30,round(duration*1000/(len(images)-1)))]*len(images);times[-1]=500
 kwargs=dict(save_all=True,append_images=encoded[1:],duration=times,loop=0,disposal=2,optimize=False)
 if transparent:kwargs.update(transparency=255,background=255)
 encoded[0].save(destination,**kwargs)
count=next(iter(cases.values()))[0]['frames'];duration=next(iter(cases.values()))[0]['sampleDuration'];comparison=[]
for i in range(count):
 image=Image.new('RGB',(1024,1112),'#e8eddf');draw=ImageDraw.Draw(image)
 for row,view in enumerate(['front','side']):
  for column,version in enumerate(['V4','V5']):
   info,images=cases[(version,view)];frame=images[i].resize((512,512),Image.Resampling.LANCZOS);x=column*512;y=row*556
   label=version+' · '+('정면' if view=='front' else '측면')+' · '+str(info['duration'])+'초'
   draw.text((x+22,y+10),label,font=font,fill='#294238');image.paste(frame,(x,y+40),frame)
 comparison.append(image)
save_gif(comparison,out/'electric-attack-before-after.gif',duration)
for view in ['front','side']:
 info,images=cases[('V5',view)];save_gif([f.resize((512,512),Image.Resampling.LANCZOS) for f in images],out/('motion-electric-attack-'+view+'.gif'),duration,True)
strip=Image.new('RGB',(1280,700),'#e8eddf');draw=ImageDraw.Draw(strip);phases=[(.30,'준비'),(.38,'조준'),(.49,'방출'),(.66,'반동')]
for row,view in enumerate(['front','side']):
 info,images=cases[('V5',view)]
 for col,(phase,label) in enumerate(phases):
  index=min(len(images)-1,round(info['duration']*phase/info['sampleDuration']*(len(images)-1)));f=images[index].resize((320,320),Image.Resampling.LANCZOS);x=col*320;y=row*350
  draw.text((x+14,y+6),label+' · '+('정면' if view=='front' else '측면'),font=font,fill='#294238');strip.paste(f,(x,y+30),f)
strip.save(out/'electric-attack-phase-strip.png')
print('Created actual V4/V5 electric attack comparison, V5 front+side GIFs and phase strip')
`;
 const result=spawnSync('python',['-c',python,root,output],{stdio:'inherit'});if(result.status!==0)throw Error('Electric comparison assembly failed');
 for(const version of versions)await version.page.close();
}
