"""An original masked rabbit-fish cantor, with soft bent ears and raised hocks.

The pearl hangs before a connected torso. Young proportions are independently
chosen: short limbs, round head and a little lyre, never a uniform adult scale.
"""

def build(m, stage):
    adult=stage==3
    shoulder=22.7 if adult else 14.9
    hip=14.0 if adult else 8.4
    hx,hy,hz=(6.6,5.6,4.6) if adult else (6.0,4.8,4.25)
    head_y=24.0 if adult else 15.6
    face_z=-2.38 if adult else -2.20
    sx,ex=(3.65,4.75) if adult else (2.9,3.65)
    elbow_y=17.9 if adult else 11.3
    wrist_y=13.7 if adult else 8.5
    knee_y=8.7 if adult else 5.0
    m.bone('body',(0,hip,.3))
    m.bone('core',(0,shoulder-1.0,-2.3),'body')
    m.bone('head',(0,head_y+.4,.1),'body')
    m.bone('face_mask',(0,head_y+3,face_z),'head')
    for side,sg in [('left',-1),('right',1)]:
        m.bone(side+'_arm',(sg*sx,shoulder-.3,.1),'body')
        m.bone(side+'_forearm',(sg*ex,elbow_y,-.2),side+'_arm')
        m.bone(side+'_leg',(sg*(2.25 if adult else 1.75),hip+.1,.5),'body')
        m.bone(side+'_hock',(sg*(2.65 if adult else 1.95),knee_y,.8),side+'_leg')
        m.bone('ear_'+side,(sg*(2.05 if adult else 1.8),head_y+hy-.5,.3),'head')
        m.bone('ear_tip_'+side,(sg*(3.45 if adult else 2.5),34.2 if adult else 21.8,.6),'ear_'+side)
        m.bone('mantle_'+side,(sg*(2.7 if adult else 2.1),shoulder,1),'body')
    m.bone('tail',(0,hip+.1,2.0),'body')
    m.bone('tail_fin',(0,hip-.8,4.1 if adult else 3.4),'tail')
    harp_x,harp_y,harp_z=(5.6,14,-2.0) if adult else (3.9,8.5,-1.8)
    m.bone('harp',(harp_x,harp_y,harp_z),'right_forearm')
    def b(n,p,s,mat='stone',bone='body',r=(0,0,0),pivot=None):
        m.box(n,[round(v,5) for v in p],[round(v,5) for v in s],mat,bone,rotation=r,pivot=[round(v,5) for v in pivot] if pivot is not None else None)
    # Three connected natural body masses, not an empty rib cage. The pearl
    # floats a little in front of the ivory bib and is deliberately small.
    if adult:
        b('connected_chest',(-3.15,19.6,-1.55),(6.3,4.2,3.8),'stone',r=(-4,0,0))
        b('continuous_belly',(-2.25,15.6,-1.45),(4.5,5.1,3.4),'stone',r=(4,0,0))
        b('round_haunch_base',(-3,12.5,-1.15),(6,4,3.75),'dark',r=(-6,0,0))
        b('ivory_throat_bib',(-1.9,19.2,-1.68),(3.8,4.8,.38),'light',r=(-4,0,0))
        b('ivory_belly',(-1.55,15.5,-1.62),(3.1,4.1,.32),'light',r=(4,0,0))
        b('short_furry_neck',(-1.2,23,-.75),(2.4,2,2.45),'light')
        b('single_pearl_heart',(-.82,21,-2.67),(1.64,1.76,.85),'glow','core',(0,0,7))
    else:
        b('young_chest',(-2.6,12.1,-1.35),(5.2,3.3,3.35),'stone',r=(-3,0,0))
        b('young_round_belly',(-2.15,8.6,-1.4),(4.3,4.1,3.45),'light')
        b('young_haunch_base',(-2.45,7.5,-.9),(4.9,2.5,3.2),'dark')
        b('young_throat_bib',(-1.5,12.7,-1.5),(3,2.9,.3),'light')
        b('young_short_neck',(-1.05,14.85,-.6),(2.1,1.55,2.2),'light')
        b('single_pearl_heart',(-.65,13.1,-2.2),(1.3,1.4,.72),'glow','core',(0,0,7))
    # Broad cheeked face and connected rabbit muzzle, painted feline domino.
    b('rounded_skull',(-hx/2,head_y,-hz/2),(hx,hy,hz),'light','head')
    b('left_cheek',(-hx/2-.35,head_y+.55,-1.6),(1.25,3.25 if adult else 2.8,3.05),'light','head',(0,0,8))
    b('right_cheek',(hx/2-.9,head_y+.55,-1.6),(1.25,3.25 if adult else 2.8,3.05),'light','head',(0,0,-8))
    b('small_animal_muzzle',(-1.35,head_y+.5,face_z-.65),(2.7,1.5,.9),'light','head',(-5,0,0))
    b('painted_domino_mask',(-2.9 if adult else -2.6,head_y+2,face_z-.04),(5.8 if adult else 5.2,2.5 if adult else 2.2,0),'water_mask','face_mask')
    b('coral_nose',(-.4,head_y+1.25,face_z-.73),(.8,.56,0),'nose','head')
    b('little_muzzle_smile',(-.36,head_y+.68,face_z-.73),(.72,.44,0),'mouth','head')
    # Three volumetric pieces bend each mature ear; the young have two.
    if adult:
        ears={
            'left':[((-3.25,28.5,-.5),(2.1,4.9,1.7),(0,0,16),'ear_left'),
                    ((-4.25,32.3,-.25),(2.3,4.5,1.9),(-8,0,-8),'ear_tip_left'),
                    ((-4.05,35.8,-.65),(2.65,1.9,2.25),(-18,0,-28),'ear_tip_left')],
            'right':[((1.2,28.5,-.5),(2.1,5,1.7),(0,0,-15),'ear_right'),
                     ((2.75,32.1,-.15),(2.35,4.7,1.9),(-12,0,-23),'ear_tip_right'),
                     ((4.15,33.1,-.65),(2.6,3,2.2),(-20,0,-57),'ear_tip_right')]}
    else:
        ears={
            'left':[((-2.65,19.65,-.35),(1.9,3.55,1.5),(0,0,15),'ear_left'),
                    ((-3.05,22.1,-.4),(2.15,2,1.8),(-10,0,-25),'ear_tip_left')],
            'right':[((.8,19.65,-.35),(1.9,3.6,1.5),(0,0,-13),'ear_right'),
                     ((1.8,21.7,-.45),(2.25,2.1,1.8),(-12,0,-40),'ear_tip_right')]}
    for side,parts in ears.items():
        for i,(p,s,r,bone) in enumerate(parts):
            b(side+'_soft_fin_ear_'+str(i),p,s,'light',bone,r)
            if i<(2 if adult else 1):
                pivot=[p[j]+s[j]/2 for j in range(3)]
                b(side+'_teal_inner_ear_'+str(i),(p[0]+.32,p[1]+.38,p[2]-.025),(s[0]-.64,s[1]-.76,0),'ear_inner',bone,r,pivot)
    for side,sg in [('left',-1),('right',1)]:
        arm,fore,leg,hock=side+'_arm',side+'_forearm',side+'_leg',side+'_hock'
        if adult:
            b(side+'_soft_upper_arm',(sg*4.05-1.03,17.55,-.9),(2.06,5.3,2.4),'stone',arm,(0,0,-sg*11))
            b(side+'_soft_forearm',(sg*5.05-.94,13.1,-1),(1.88,4.9,2.3),'light',fore,(5,0,-sg*4))
            b(side+'_wrist_ruff',(sg*5.2-1.27,12.7,-1.14),(2.54,2.15,2.65),'light',fore,(0,0,-sg*6))
            b(side+'_paw_hand',(sg*5.33-.85,11.35,-1.15),(1.7,2.3,2),'stone',fore,(8,0,sg*3))
            b(side+'_wrist_fin',(sg*5.2-1.5,13.2,-1.22),(3,3.65,0),'membrane',fore,(0,0,-sg*17))
            b(side+'_powerful_haunch',(sg*2.35-1.75,8.6,-.8),(3.5,6,4),'stone',leg,(-16,0,-sg*5))
            b(side+'_raised_hock',(sg*2.65-1,3.6,0),(2,5.4,2.4),'dark',hock,(21,0,sg*3))
            b(side+'_soft_ankle_ruff',(sg*2.65-1.46,2.6,-.15),(2.92,2.5,3.05),'light',hock,(5,0,0))
            b(side+'_long_flipper_paw',(sg*2.65-1.45,.85,-3.35),(2.9,1.9,4.6),'stone',hock,(3,0,sg*3))
            b(side+'_ivory_toe_tip',(sg*2.65-1.2,.9,-3.58),(2.4,1.35,.85),'light',hock,(0,0,sg*3))
            b(side+'_ankle_fin',(sg*2.65-1.7,2.7,-.25),(3.4,3.1,0),'membrane',hock,(0,0,sg*12))
            b(side+'_shoulder_mantle_root',(sg*2.85-1.25,21.8,.9),(2.5,1.55,2.7),'dark','mantle_'+side,(0,0,-sg*12))
            b(side+'_shoulder_wave_mantle',(sg*4.3-2.25,17.8,1.4),(4.5,5.8,0),'membrane','mantle_'+side,(-10,sg*12,-sg*20))
        else:
            b(side+'_young_arm',(sg*3.15-.9,11.15,-.8),(1.8,3.9,2.05),'stone',arm,(0,0,-sg*9))
            b(side+'_young_forearm',(sg*3.85-.85,8.2,-.9),(1.7,3.3,2),'light',fore,(4,0,-sg*4))
            b(side+'_young_ruff_paw',(sg*3.95-1,7.4,-1),(2,1.9,2.2),'light',fore,(4,0,0))
            b(side+'_young_wrist_fin',(sg*4-1.1,8,-1.05),(2.2,2.4,0),'membrane',fore,(0,0,-sg*15))
            b(side+'_young_haunch',(sg*1.8-1.3,4.7,-.65),(2.6,4.2,3.1),'stone',leg,(-14,0,-sg*4))
            b(side+'_young_hock',(sg*1.95-.8,2.2,-.05),(1.6,3.1,1.95),'dark',hock,(17,0,sg*3))
            b(side+'_young_ankle_ruff',(sg*1.95-1.05,1.5,-.2),(2.1,1.9,2.35),'light',hock)
            b(side+'_young_flipper_paw',(sg*1.95-1.05,.5,-2.6),(2.1,1.5,3.5),'stone',hock,(3,0,sg*3))
            b(side+'_young_ivory_toes',(sg*1.95-.87,.55,-2.8),(1.74,1.08,.64),'light',hock,(0,0,sg*3))
            b(side+'_young_mantle',(sg*2.7-1.7,11,1.2),(3.4,4.8,0),'membrane','mantle_'+side,(-8,sg*10,-sg*17))
    # Small water tail, independent of the harp silhouette.
    b('water_tail_base',(-.8,hip-.5,1.9),(1.6,1.8,2.6 if adult else 2),'stone','tail',(-18,0,0))
    b('water_tail_tip',(-.65,hip-1.35,3.7 if adult else 3),(1.3,1.5,1.8),'water','tail_fin',(-28,0,0))
    b('little_tail_fin',(-1.85,hip-2.25,4.5 if adult else 3.8),(3.7,3.2,0),'membrane','tail_fin',(-12,0,0))
    # Harp saddle meets the supporting palm. Its six/four strings are actual
    # independently animated water surfaces, with no drawn pretend strings.
    hh,hw=(9.4,4.0) if adult else (6.2,2.9)
    b('harp_palm_saddle',(harp_x-.45,harp_y-.15,harp_z-.25),(1.8,.9,.9),'light','harp',(0,0,-8))
    b('harp_outer_swept_rim',(harp_x+hw-.5,harp_y+.4,harp_z),(.7,hh,.9),'water','harp',(0,0,-8))
    b('harp_top_bow',(harp_x+.2,harp_y+hh-.2,harp_z),(hw,.65,.9),'light','harp',(0,0,-10))
    b('harp_inner_shell',(harp_x+.05,harp_y+.5,harp_z),(.55,hh-.4,.7),'water','harp',(0,0,4))
    for j in range(6 if adult else 4):
        x=harp_x+.65+j*((hw-1.2)/(5 if adult else 3));y=harp_y+.85
        m.bone('string_'+str(j),(x,y,harp_z-.18),'harp')
        b('water_string_'+str(j),(x,y,harp_z-.18),(.10,hh-1.2-j*.07,0),'string','string_'+str(j))


def animate(m):
    adult=m.stage==3
    def k(*items):return {str(t):v for t,v in items}
    def R(*items):return {'rotation':k(*items)}
    def P(*items):return {'position':k(*items)}
    def S(*items):return {'scale':k(*items)}
    names={b['name'] for b in m.bones}
    def clip(length,loop,bones):return {'animation_length':length,'loop':loop,'bones':{n:v for n,v in bones.items() if n in names}}
    zero=[0,0,0]
    idle={'body':P((0,zero),(1.1,[0,.22,0]),(2.5,[0,.06,0]),(3.4,zero)),
          'head':R((0,[0,-4,-2]),(1.2,[0,3,2]),(2.3,[-2,5,1]),(3.4,[0,-4,-2])),
          'core':P((0,zero),(1.7,[0,.09,0]),(3.4,zero)),
          'face_mask':S((0,[1,1,1]),(2.4,[1,1,1]),(2.47,[1,.25,1]),(2.58,[1,1,1]),(3.4,[1,1,1])),
          'tail':R((0,[0,-7,0]),(1.2,[3,8,0]),(2.4,[-2,-4,0]),(3.4,[0,-7,0])),
          'tail_fin':R((0,[0,5,0]),(1.35,[0,-8,0]),(3.4,[0,5,0]))}
    for side,sg in [('left',-1),('right',1)]:
        idle['ear_'+side]=R((0,[0,0,sg*3]),(1.4,[sg*2,0,-sg*2]),(3.4,[0,0,sg*3]))
        idle['ear_tip_'+side]=R((0,[4,0,-sg*3]),(1.7,[-3,0,sg*5]),(3.4,[4,0,-sg*3]))
        idle['mantle_'+side]=R((0,[0,sg*2,sg*2]),(1.8,[2,-sg*3,-sg*2]),(3.4,[0,sg*2,sg*2]))
    # Digitigrade prance, hock out of phase with thigh; ears lag push-off.
    walk={'root':P((0,zero),(.22,[0,.65,-.12]),(.48,[0,.1,0]),(.72,[0,.65,-.1]),(1,zero)),
          'body':R((0,[3,0,-3]),(.5,[3,0,3]),(1,[3,0,-3])),
          'head':R((0,[-2,3,2]),(.5,[0,-3,-2]),(1,[-2,3,2])),
          'left_leg':R((0,[21,0,-3]),(.5,[-17,0,2]),(1,[21,0,-3])),
          'right_leg':R((0,[-17,0,3]),(.5,[21,0,-2]),(1,[-17,0,3])),
          'left_hock':R((0,[-14,0,0]),(.25,[10,0,0]),(.5,[4,0,0]),(.75,[-9,0,0]),(1,[-14,0,0])),
          'right_hock':R((0,[4,0,0]),(.25,[-9,0,0]),(.5,[-14,0,0]),(.75,[10,0,0]),(1,[4,0,0])),
          'left_arm':R((0,[-7,0,-3]),(.5,[7,0,-1]),(1,[-7,0,-3])),
          'right_arm':R((0,[4,0,2]),(.5,[-4,0,4]),(1,[4,0,2])),
          'tail':R((0,[6,5,0]),(.5,[-5,-5,0]),(1,[6,5,0]))}
    for side,sg in [('left',-1),('right',1)]:
        walk['ear_'+side]=R((0,[-5,0,sg*3]),(.35,[9,0,-sg*3]),(.7,[-4,0,sg*4]),(1,[-5,0,sg*3]))
        walk['ear_tip_'+side]=R((0,[12,0,-sg*7]),(.18,[-9,0,sg*4]),(.55,[12,0,-sg*7]),(.83,[-7,0,sg*4]),(1,[12,0,-sg*7]))
        walk['mantle_'+side]=R((0,[-3,sg*3,sg*4]),(.5,[4,-sg*4,-sg*4]),(1,[-3,sg*3,sg*4]))
    attack={'body':R((0,zero),(.18,[0,14,5]),(.34,[0,-12,-5]),(.9,zero)),
            'head':R((0,zero),(.18,[0,-8,0]),(.45,[0,4,0]),(.9,zero)),
            'left_arm':R((0,zero),(.18,[-16,0,-20]),(.35,[-35,0,-40]),(.6,[-13,0,-14]),(.9,zero)),
            'left_forearm':R((0,zero),(.2,[0,0,-12]),(.38,[0,0,22]),(.9,zero)),
            'tail':R((0,zero),(.2,[0,-18,0]),(.43,[0,15,0]),(.9,zero)),
            'ear_tip_left':R((0,zero),(.25,[12,0,-10]),(.52,[-8,0,8]),(.9,zero)),
            'ear_tip_right':R((0,zero),(.3,[10,0,8]),(.57,[-7,0,-6]),(.9,zero))}
    # Support harp with right paw, cross left paw to touch and pluck strings.
    reach_x,reach_z=(11.7,60) if adult else (19.35,84.5)
    wrist_x,wrist_z=(7.7,40) if adult else (12.05,-12.3)
    harp_shift=[-1.8,.3,-.65] if adult else [v/.68 for v in [-2.3,.3,-.65]]
    special={'body':R((0,zero),(.4,[0,-5,1]),(1.45,[0,4,-2]),(2.5,zero)),
             'head':R((0,zero),(.4,[5,-8,-3]),(1.15,[2,2,2]),(1.9,[-3,5,-1]),(2.5,zero)),
             'left_arm':R((0,zero),(.4,[7,0,reach_z*.7]),(.65,[reach_x,0,reach_z]),(1.2,[reach_x,0,reach_z+1]),(1.8,[reach_x,0,reach_z-1]),(2.5,zero)),
             'left_forearm':R((0,zero),(.4,[3,0,wrist_z*.7]),(.58,[wrist_x,0,wrist_z+3]),(.8,[wrist_x,0,wrist_z-3]),(1.02,[wrist_x,0,wrist_z+4]),(1.24,[wrist_x,0,wrist_z-3]),(1.46,[wrist_x,0,wrist_z+4]),(1.72,[wrist_x,0,wrist_z-2]),(2.5,zero)),
             'right_arm':R((0,zero),(.35,[-3,0,3]),(1.9,[-3,0,3]),(2.5,zero)),
             'right_forearm':R((0,zero),(.35,[0,0,-3]),(1.9,[0,0,-3]),(2.5,zero)),
             'harp':P((0,zero),(.4,harp_shift),(1.85,harp_shift),(2.5,zero)),
             'tail':R((0,zero),(.65,[5,10,0]),(1.4,[-3,-9,0]),(2.5,zero)),
             'core':S((0,[1,1,1]),(.55,[1.06,1.06,1.06]),(1.2,[.98,.98,.98]),(1.75,[1.06,1.06,1.06]),(2.5,[1,1,1]))}
    for j in range(6 if adult else 4):
        t=.59+j*.16
        special['string_'+str(j)]=P((0,zero),(t,zero),(t+.055,[0,0,.22]),(t+.13,[0,0,-.12]),(t+.22,[0,0,.05]),(t+.33,zero),(2.5,zero))
    for side,sg in [('left',-1),('right',1)]:
        special['ear_'+side]=R((0,zero),(.55,[-3,0,-sg*4]),(1.3,[3,0,sg*4]),(2.5,zero))
        special['ear_tip_'+side]=R((0,zero),(.8,[4,0,sg*5]),(1.55,[-3,0,-sg*5]),(2.5,zero))
        special['mantle_'+side]=R((0,zero),(.6,[-3,sg*8,sg*4]),(1.35,[4,-sg*7,-sg*4]),(2.5,zero))
    hurt={'body':R((0,zero),(.12,[-9,-9,7]),(.32,[3,3,-2]),(.7,zero)),
          'head':R((0,zero),(.12,[-9,0,-8]),(.7,zero)),
          'ear_tip_left':R((0,zero),(.18,[18,0,-14]),(.4,[-6,0,5]),(.7,zero)),
          'ear_tip_right':R((0,zero),(.21,[15,0,13]),(.45,[-5,0,-4]),(.7,zero)),
          'harp':R((0,zero),(.15,[0,0,9]),(.35,[0,0,-3]),(.7,zero)),
          'face_mask':S((0,[1,1,1]),(.12,[1,.35,1]),(.45,[1,.35,1]),(.7,[1,1,1]))}
    faint={'root':P((0,zero),(.45,[0,-1,0]),(1,[0,-2.5,.2]),(1.8,[0,-2.5,.2])),
           'body':R((0,zero),(.6,[8,0,-10]),(1.25,[13,0,-17]),(1.8,[13,0,-17])),
           'head':R((0,zero),(.7,[16,0,5]),(1.8,[16,0,5])),
           'left_leg':R((0,zero),(.75,[-15,0,-5]),(1.8,[-15,0,-5])),
           'right_leg':R((0,zero),(.75,[-12,0,5]),(1.8,[-12,0,5])),
           'left_hock':R((0,zero),(.75,[18,0,0]),(1.8,[18,0,0])),
           'right_hock':R((0,zero),(.75,[18,0,0]),(1.8,[18,0,0])),
           'ear_left':R((0,zero),(.75,[12,0,-12]),(1.8,[12,0,-12])),
           'ear_right':R((0,zero),(.8,[12,0,12]),(1.8,[12,0,12])),
           'ear_tip_left':R((0,zero),(.9,[22,0,-17]),(1.8,[22,0,-17])),
           'ear_tip_right':R((0,zero),(.95,[22,0,17]),(1.8,[22,0,17])),
           'core':S((0,[1,1,1]),(.8,[.65,.65,.65]),(1.8,[.65,.65,.65])),
           'face_mask':S((0,[1,1,1]),(.5,[1,.2,1]),(1.8,[1,.2,1]))}
    # The domino is a stable facial marking, not a sheet that collapses when
    # blinking. Let head/ear poses carry expression without warping the mask.
    for tracks in (idle,hurt,faint):tracks.pop('face_mask',None)
    m.animations={'idle':clip(3.4,True,idle),'walk':clip(1,True,walk),'attack':clip(.9,False,attack),'special':clip(2.5,False,special),'hurt':clip(.7,False,hurt),'faint':clip(1.8,False,faint)}
    if not adult:
        for a in m.animations.values():
            a['animation_length']=round(a['animation_length']*.86,4)
            for tracks in a['bones'].values():
                for channel,frames in list(tracks.items()):
                    tracks[channel]={str(round(float(t)*.86,4)):[round(v*(.68 if channel=='position' else 1),5) for v in vec] for t,vec in frames.items()}
