"""Functional checks for the requested V5 changes, independent of the viewer."""
import hashlib,json,math,sys
from pathlib import Path

PACK=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'pack'
def add(a,b):return [x+y for x,y in zip(a,b)]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def rotate(v,r):
    x,y,z=v;a,b,c=[math.radians(q) for q in r]
    y,z=y*math.cos(a)-z*math.sin(a),y*math.sin(a)+z*math.cos(a)
    x,z=x*math.cos(b)+z*math.sin(b),-x*math.sin(b)+z*math.cos(b)
    return [x*math.cos(c)-y*math.sin(c),x*math.sin(c)+y*math.cos(c),z]
def track(frames,t,default):
    if not frames:return default[:]
    keys=sorted((float(k),v) for k,v in frames.items())
    if t<=keys[0][0]:return keys[0][1][:]
    for (a,x),(b,y) in zip(keys,keys[1:]):
        if t<=b:return [v+(w-v)*(t-a)/(b-a) for v,w in zip(x,y)]
    return keys[-1][1][:]
def posed(m,bone,v,t,clip,normal=False):
    bones={b['name']:b for b in m['bones']};an=m['animations'][clip]
    while bone:
        b=bones[bone];channels=an['bones'].get(bone,{})
        r=add(b['rotation'],track(channels.get('rotation'),t,[0,0,0]))
        s=track(channels.get('scale'),t,[1,1,1])
        if normal:v=rotate([x/y for x,y in zip(v,s)],r)
        else:
            v=add(rotate([x*y for x,y in zip(sub(v,b['pivot']),s)],r),b['pivot'])
            v=add(v,track(channels.get('position'),t,[0,0,0]))
        bone=b['parent']
    if normal:
        length=math.sqrt(sum(x*x for x in v));v=[x/length for x in v]
    return v
def box_point(m,b,t,clip,normal=False):
    if normal:v=rotate([0,0,-1],b['rotation'])
    else:
        v=[p+s/2 for p,s in zip(b['origin'],b['size'])]
        v=add(rotate(sub(v,b['pivot']),b['rotation']),b['pivot'])
    return posed(m,b['bone'],v,t,clip,normal)

approved=json.loads((PACK/'APPROVED_BASE_SHA256.json').read_text())
for name,sha in approved.items():
    assert hashlib.sha256((PACK/name).read_bytes()).hexdigest()==sha,'Approved base changed: '+name
print('PASS approved base: all',len(approved),'artifacts byte-identical to V4')
for stage in [2,3]:
    m=json.loads((PACK/'source'/f'teumbi_fire_{stage}.json').read_text())
    bevels=[b for b in m['boxes'] if 'cutting_bevel' in b['name']]
    fills=[b for b in m['boxes'] if b['material']=='blade']
    assert len(bevels)==14 and len(fills)==2
    assert all(0<b['size'][2]<=.300001 for b in bevels)
    assert all(b['size'][2]==0 for b in fills)
    print('PASS fire',stage,': blade bevel depth',min(b['size'][2] for b in bevels),'to',max(b['size'][2] for b in bevels))

    m=json.loads((PACK/'source'/f'teumbi_electric_{stage}.json').read_text())
    hand=next(b for b in m['boxes'] if b['name']==('right_small_hand' if stage==3 else 'right_little_hand'))
    core=next(b for b in m['bones'] if b['name']=='core')
    for name,fraction in [('attack',.49),('special',.69)]:
        length=m['animations'][name]['animation_length'];t=length*fraction
        palm=box_point(m,hand,t,name);center=posed(m,'core',core['pivot'],t,name)
        facing=box_point(m,hand,t,name,True)
        assert palm[2]<center[2]-(3.5 if stage==3 else 2),f'Electric {stage} {name}: palm is not forward'
        assert -facing[2]>.9,f'Electric {stage} {name}: palm faces away from target'
        start=box_point(m,hand,0,name);end=box_point(m,hand,length,name)
        assert math.dist(start,end)<1e-5,'Action does not recover to rest'
        print('PASS electric',stage,name,': hand Z',round(palm[2],3),'core Z',round(center[2],3),'forward-facing',round(-facing[2],3))

    m=json.loads((PACK/'source'/f'teumbi_water_{stage}.json').read_text())
    hand=next(b for b in m['boxes'] if b['name']==('left_paw_hand' if stage==3 else 'left_young_ruff_paw'))
    string=next(b for b in m['boxes'] if b['name']=='water_string_0')
    t=.9 if stage==3 else .774
    p=box_point(m,hand,t,'special')
    q=[o+s*f for o,s,f in zip(string['origin'],string['size'],[.5,.57,.5])]
    q=posed(m,string['bone'],q,t,'special')
    distance=math.dist(p,q)
    assert distance<.85,f'Water {stage}: plucking paw misses string by {distance}'
    assert any(b['material']=='water_mask' and b['size'][2]==0 for b in m['boxes'])
    assert sum('soft_fin_ear_' in b['name'] for b in m['boxes'])>=(6 if stage==3 else 4)
    print('PASS water',stage,': plucking paw/string distance',round(distance,3),'units; animal mask and articulated ears present')

    m=json.loads((PACK/'source'/f'teumbi_grass_{stage}.json').read_text())
    left=next(b for b in m['boxes'] if b['name']=='left_grown_leaf_shield_half')
    right=next(b for b in m['boxes'] if b['name']=='right_grown_leaf_shield_half')
    t=1.34*(.82 if stage==2 else 1)
    def seam(b,side,time):
        v=[b['origin'][0]+(b['size'][0] if side=='left' else 0),b['origin'][1]+b['size'][1]/2,b['origin'][2]]
        return posed(m,b['bone'],v,time,'special')
    distance=math.dist(seam(left,'left',t),seam(right,'right',t))
    assert distance<.05,f'Grass {stage}: shield halves fail to join, gap={distance}'
    assert math.dist(seam(left,'left',0),seam(right,'right',0))>2,'Shield must open at rest'
    assert m['animations']['special']['animation_length']>2.5,'Heavy guard needs preparation and hold'
    print('PASS grass',stage,': actual joined shield seam gap',round(distance,8),'units; opens at rest')
print('PASS all V5 change checks')
