/* Exact unlabelled WebGL rest poses, seven-percent projected margin. */
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const ROOT=__dirname,PACK=path.join(ROOT,'pack'),OUT=path.join(PACK,'previews');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
(async()=>{
 fs.mkdirSync(OUT,{recursive:true});
 const html=fs.readFileSync(path.join(PACK,'VIEW_MODELS.html'),'utf8');
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:900,height:1000},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.setContent(html);
 await page.addStyleTag({content:'html,body{width:900px;height:1000px;margin:0;overflow:hidden}main{display:block;min-height:0}aside{display:none}section{width:900px;height:1000px;min-height:0;background:#e8eddf}canvas{width:900px;height:1000px}#top,#badge,.help,#error{display:none}'});
 await page.waitForFunction(()=>window.viewer&&viewer.getState().ready);
 const allModels=await page.locator('#model option').evaluateAll(v=>v.map(x=>x.value));
 // The user explicitly approved this existing card. Preserve its bytes and
 // original provenance, even though the surrounding V5 viewer has new labels.
 const priority=['teumbi_water_3','teumbi_fire_3'];
 const models=allModels.filter(name=>name!=='teumbi'||process.argv.includes('--include-base')).sort((a,b)=>{
  const rank=name=>priority.includes(name)?priority.indexOf(name):-1;
  return (rank(a)<0?99:rank(a))-(rank(b)<0?99:rank(b));
 });
 for(const name of models){
  await page.selectOption('#model',name,{force:true});await page.waitForFunction(()=>viewer.getState().ready);
  await page.selectOption('#animation','',{force:true});
  const result=await page.evaluate(()=>{
   viewer.pause();viewer.setView(.48,.12,1);viewer.fitRest(.07);viewer.setTime(0);
   const vertices=viewer.getVertices(0);return {state:viewer.getState(),bounds:viewer.getBounds(),vertexCount:vertices.length/9,finite:[...vertices].every(Number.isFinite)};
  });
  if(!result.finite||result.state.glError||result.state.animation)throw Error('REST capture failed '+name+': '+JSON.stringify(result));
  const file=path.join(OUT,name+'_game.png');
  await page.locator('#canvas').screenshot({path:file});
  const sourceBytes=fs.readFileSync(path.join(PACK,'source',name+'.json'));
  const source=JSON.parse(sourceBytes),geometry={name:source.name,bones:source.bones,boxes:source.boxes};
  const record={name,view:'webgl_rest_threequarter',source_sha256:hash(sourceBytes),geometry_sha256:hash(JSON.stringify(geometry)),texture_sha256:hash(fs.readFileSync(path.join(PACK,'textures',name+'.png'))),html_sha256:hash(html),cube_count:source.boxes.length,plane_count:source.boxes.filter(b=>b.size.includes(0)).length,width:900,height:1000,margin:.07,pose:'rest',yaw:.48,pitch:.12,vertices:result.vertexCount};
  fs.writeFileSync(path.join(OUT,name+'_game.render.json'),JSON.stringify(record,null,2));
  console.log('PASS clean game card',name,source.boxes.length,'elements',record.plane_count,'alpha planes');
 }
 // Axes must retain a physical side edge rather than read as paper sprites.
 // Capture the final fire creature at both diagnostic angles without posing
 // its arms or otherwise flattering the blade's real geometry.
 const fire='teumbi_fire_3';
 await page.selectOption('#model',fire,{force:true});await page.waitForFunction(()=>viewer.getState().ready);
 await page.selectOption('#animation','',{force:true});
 for(const [view,yaw] of [['front',0],['edge',Math.PI/2]]){
  await page.evaluate(({yaw})=>{viewer.pause();viewer.setView(yaw,.08,1);viewer.fitRest(.07);viewer.setTime(0)},{yaw});
  const filename=fire+'_'+view+'_game';
  await page.locator('#canvas').screenshot({path:path.join(OUT,filename+'.png')});
  const sourceBytes=fs.readFileSync(path.join(PACK,'source',fire+'.json'));
  const source=JSON.parse(sourceBytes);
  fs.writeFileSync(path.join(OUT,filename+'.render.json'),JSON.stringify({name:fire,view:'webgl_rest_'+view,source_sha256:hash(sourceBytes),texture_sha256:hash(fs.readFileSync(path.join(PACK,'textures',fire+'.png'))),html_sha256:hash(html),cube_count:source.boxes.length,width:900,height:1000,margin:.07,pose:'rest',yaw,pitch:.08},null,2));
  console.log('PASS physical axe diagnostic',view,fire);
 }
 if(errors.length)throw Error(errors.join('\n'));
 await browser.close();console.log('Captured',models.length,'exact rest poses; approved base card intentionally preserved');
})().catch(e=>{console.error(e);process.exit(1)});
