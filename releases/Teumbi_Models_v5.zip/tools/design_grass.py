"""Original cedar-mantled grass ape: living leaf hands form one heavy shield.

The silhouette is a knuckle-leaning forest animal, with a connected barrel
chest and small floating heart pearl. Six motions use genuine three-dimensional
two-link arm IK: no detached shoulders, elbows, wrists or sliding leaf planes.
"""
import math


def dimensions(stage):
    if stage == 2:
        return dict(hip=6.6, body_z=1.0, sx=4.3, sy=14.2, sz=-.4,
                    ex=7.2, ey=8.5, ez=-1.5, wx=6.7, wy=2.3, wz=-3.5,
                    legx=2.35, knee=3.2, face=17.2, neck=15.1,
                    shield_w=4.5, shield_h=8.2, leaf_y=.9, core_y=12.3,
                    guard_x=2.25, guard_y=8.8, guard_z=-6.4)
    return dict(hip=10.7, body_z=1.8, sx=7.4, sy=22.2, sz=-.8,
                ex=12.0, ey=13.1, ez=-2.8, wx=11.6, wy=3.4, wz=-5.6,
                legx=3.85, knee=5.5, face=25.6, neck=23.5,
                shield_w=7.3, shield_h=13.2, leaf_y=1.6, core_y=19.4,
                guard_x=3.65, guard_y=12.1, guard_z=-8.9)


# Small pure-Python matrix helpers keep source reproduction independent of
# Blender, NumPy or SciPy. Euler convention is exactly viewer/Blockbench XYZ.
def add(a,b):return [x+y for x,y in zip(a,b)]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def mul(a,s):return [x*s for x in a]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def norm(a):return math.sqrt(dot(a,a))
def unit(a):
    n=norm(a)
    return mul(a,1/n) if n>1e-9 else [1,0,0]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def ident():return [[1,0,0],[0,1,0],[0,0,1]]
def transpose(a):return [list(v) for v in zip(*a)]
def mv(a,v):return [dot(row,v) for row in a]
def mm(a,b):return [[dot(row,col) for col in zip(*b)] for row in a]
def axis_rotation(axis,angle):
    x,y,z=unit(axis);c=math.cos(angle);s=math.sin(angle);k=1-c
    return [[c+x*x*k,x*y*k-z*s,x*z*k+y*s],
            [y*x*k+z*s,c+y*y*k,y*z*k-x*s],
            [z*x*k-y*s,z*y*k+x*s,c+z*z*k]]
def from_to(a,b):
    a=unit(a);b=unit(b);v=cross(a,b);length=norm(v);cos=max(-1,min(1,dot(a,b)))
    if length<1e-8:
        return ident() if cos>0 else axis_rotation(cross(a,[0,0,1] if abs(a[2])<.8 else [1,0,0]),math.pi)
    return axis_rotation(v,math.atan2(length,cos))
def matrix(euler):
    a,b,c=[math.radians(x) for x in euler]
    rx=[[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]]
    ry=[[math.cos(b),0,math.sin(b)],[0,1,0],[-math.sin(b),0,math.cos(b)]]
    rz=[[math.cos(c),-math.sin(c),0],[math.sin(c),math.cos(c),0],[0,0,1]]
    return mm(rz,mm(ry,rx))
def euler(r):
    y=math.asin(max(-1,min(1,-r[2][0])))
    if abs(math.cos(y))>1e-7:x=math.atan2(r[2][1],r[2][2]);z=math.atan2(r[1][0],r[0][0])
    else:x=math.atan2(-r[1][2],r[1][1]);z=0
    return [math.degrees(v) for v in (x,y,z)]


def build(m,stage):
    q=dimensions(stage);young=stage==2
    m.bone('body',(0,q['hip'],q['body_z']))
    m.bone('core',(0,q['core_y'],-2.55 if young else -3.9),'body')
    m.bone('head',(0,q['neck'],-.9 if young else -1.5),'body')
    m.bone('canopy',(0,18.5 if young else 26.2,1),'head')
    m.bone('tail',(0,q['hip']+1,3.4),'body')
    for side,s in [('left',-1),('right',1)]:
        m.bone(side+'_arm',(s*q['sx'],q['sy'],q['sz']),'body')
        m.bone(side+'_forearm',(s*q['ex'],q['ey'],q['ez']),side+'_arm')
        m.bone(side+'_palm',(s*q['wx'],q['wy'],q['wz']),side+'_forearm')
        lx=s*q['legx']
        m.bone(side+'_leg',(lx,q['hip'],2.3),'root')
        m.bone(side+'_shin',(lx+s*.9,q['knee'],3.2),side+'_leg')
        m.bone(side+'_foot',(lx+s*1.1,1.1,1.7),side+'_shin')
        m.bone(side+'_eye',(s*(1.05 if young else 1.65),q['face'],-2.95 if young else -3.72),'head')

    def b(n,p,size,mat='stone',bone='body',rot=(0,0,0),pivot=None):
        m.box(n,p,size,material=mat,bone=bone,rotation=rot,pivot=pivot)
    def segment(n,a,c,width,depth,mat,bone,overlap=.6):
        center=mul(add(a,c),.5);length=norm(sub(a,c))+overlap
        angle=euler(from_to([0,1,0],sub(a,c)))
        b(n,(center[0]-width/2,center[1]-length/2,center[2]-depth/2),
          (width,length,depth),mat,bone,angle,center)

    if young:
        b('young_seed_barrel',(-4.3,8.0,-1.5),(8.6,6.9,5.4),'stone',rot=(-8,0,0))
        b('young_lower_trunk',(-3.3,5.7,-.2),(6.6,4.5,4.8),'stone',rot=(-9,0,0))
        b('young_round_back',(-3.5,11.4,1.5),(7,4.6,3.1),'leaf',rot=(-17,0,0))
        b('young_heart_pearl',(-.66,11.64,-3.2),(1.32,1.32,1.32),'glow','core',(0,0,22))
        b('young_sunken_throat',(-1.85,14.1,-.8),(3.7,2.3,3),'stone')
        b('young_ape_skull',(-2.3,15.3,-2.2),(4.6,3.8,3.8),'stone','head',(-5,0,0))
        b('young_short_muzzle',(-1.6,14.9,-3.8),(3.2,1.6,2.4),'light','head',(-8,0,0))
        b('young_flat_nose',(-.67,15.6,-4.0),(1.34,.7,.6),'dark','head')
        b('young_mouth',(-.8,15.1,-3.97),(1.6,.45,0),'mouth','head')
        b('young_mane_root',(-2.55,17.4,.7),(5.1,2.7,2),'leaf','canopy',(-14,0,0))
        for side,s in [('left',-1),('right',1)]:
            b(side+'_young_beast_eye',(s*1.05-.64,16.65,-2.99),(1.28,1.1,0),'beast_eye',side+'_eye',(0,s*9,-s*7))
            b(side+'_young_brow',(s*1.15-.85,17.7,-2.9),(1.7,.7,.85),'stone','head',(0,0,-s*8))
            b(side+'_cedar_bud',(s*2.2-1.5,17.4,.6),(3,4.1,0),'crest','canopy',(-18,0,-s*28))
        b('young_back_leaf',(-1.7,10.1,3.8),(3.4,4.4,0),'crest','tail',(50,0,10))
    else:
        # Connected barrel anatomy, with the small floating pearl in front.
        # The plant mantle slopes into shoulders; there is no empty rib cage,
        # human chest, neck post, shoulder pauldron or trouser-shaped pelvis.
        b('massive_living_barrel',(-7.1,14.1,-2.5),(14.2,9.3,7.4),'stone',rot=(-9,0,0))
        b('heavy_lower_abdomen',(-5.15,9.3,-.45),(10.3,7.4,7.0),'stone',rot=(-13,0,0))
        b('round_ape_haunch',(-4.5,7.6,.9),(9,5.6,6.4),'stone',rot=(-11,0,0))
        b('sloping_cedar_back',(-5.7,18.8,2.2),(11.4,6.7,4.2),'leaf',rot=(-23,0,0))
        b('single_small_heart_pearl',(-.88,18.52,-4.75),(1.76,1.76,1.76),'glow','core',(0,0,22))
        b('sunken_ape_throat',(-2.8,21.7,-1.7),(5.6,3.3,4.0),'stone')
        b('broad_ape_skull',(-3.35,23.0,-2.8),(6.7,4.6,4.9),'stone','head',(-5,0,0))
        b('short_broad_animal_muzzle',(-2.2,22.6,-5.15),(4.4,2.2,3.1),'light','head',(-7,0,0))
        b('flat_ape_nose',(-1.1,23.55,-5.44),(2.2,.9,.8),'dark','head',(-5,0,0))
        b('quiet_beast_mouth',(-1.15,22.86,-5.35),(2.3,.55,0),'mouth','head',(-7,0,0))
        b('cedar_mane_underbody',(-4.3,24.0,1.0),(8.6,4.1,3.4),'leaf','canopy',(-17,0,0))
        for side,s in [('left',-1),('right',1)]:
            b(side+'_watchful_beast_eye',(s*1.65-.85,25.0,-3.76),(1.7,1.25,0),'beast_eye',side+'_eye',(0,s*11,-s*8))
            b(side+'_ape_brow',(s*1.65-1.28,26.13,-3.63),(2.56,.96,1.0),'stone','head',(0,0,-s*10))
            b(side+'_temple_root',(s*3.0-.55,23.1,-1.6),(1.1,3.5,2.6),'wood','head',(0,0,-s*13))
            # Original layered cedar boughs sweep back, rather than a copied
            # spiky green hair cap or stag antlers.
            b(side+'_cedar_mane_fan',(s*4.2-3.0,22.0,.8),(6,8.4,0),'crest','canopy',(-27,0,-s*24),(s*3.3,24,1))
            b(side+'_shoulder_fern',(s*5.0-2.1,18.8,2.5),(4.2,7.1,0),'crest','canopy',(-34,0,-s*34))
        b('back_swept_cedar_leaf',(-3.1,26.5,2.2),(6.2,4.8,0),'crest','canopy',(-46,0,-12))
        b('low_back_fern',(-2.5,11.7,5.8),(5,6.5,0),'crest','tail',(48,0,9))

    for side,s in [('left',-1),('right',1)]:
        arm=side+'_arm';fore=side+'_forearm';hand=side+'_palm'
        shoulder=[s*q['sx'],q['sy'],q['sz']]
        elbow=[s*q['ex'],q['ey'],q['ez']]
        wrist=[s*q['wx'],q['wy'],q['wz']]
        segment(side+'_great_upper_root',shoulder,elbow,3.4 if young else 5.8,3.5 if young else 5.9,'stone',arm,1.3)
        segment(side+'_massive_leaf_forearm',elbow,wrist,3.9 if young else 6.4,3.8 if young else 6.1,'stone',fore,1.2)
        # One warm bark strip runs naturally along each forearm. Leaf shields
        # grow directly from these broad hands rather than being held props.
        segment(side+'_forearm_living_bark',add(elbow,[0,0,-1.7 if young else -2.7]),
                add(wrist,[0,0,-1.5 if young else -2.5]),.8 if young else 1.25,.36,'wood',fore,.25)
        b(side+'_broad_knuckle_palm',(wrist[0]-(1.7 if young else 2.8),q['wy']-(1.6 if young else 2.45),q['wz']-1.5),
          (3.4 if young else 5.6,2 if young else 3.0,3.1 if young else 4.4),'wood',hand,(-7,0,0))
        # Each complementary half has a straight interlocking inside edge;
        # when centres become +/- halfWidth/2 they form ONE pointed shield.
        b(side+'_grown_leaf_shield_half',(wrist[0]-q['shield_w']/2,q['leaf_y'],q['wz']-1.68),
          (q['shield_w'],q['shield_h'],0),'shield_leaf_'+side,hand)
        for digit in [-1,1]:
            b(side+'_knuckle_root',(wrist[0]+digit*(.8 if young else 1.4)-(.5 if young else .75),
              q['wy']-(1.85 if young else 2.75),q['wz']-1.65),
              (1 if young else 1.5,1.1 if young else 1.7,1.8 if young else 2.7),'wood',hand,(4,0,0))

        lx=s*q['legx'];leg=side+'_leg';shin=side+'_shin';foot=side+'_foot'
        upper=[lx,q['hip'],2.3];knee=[lx+s*.9,q['knee'],3.2];ankle=[lx+s*1.1,1.1,1.7]
        segment(side+'_powerful_bowed_haunch',upper,knee,3.4 if young else 5.1,3.7 if young else 5.6,'stone',leg,1)
        segment(side+'_short_root_hock',knee,ankle,2 if young else 3.0,2.5 if young else 3.7,'stone',shin,.7)
        b(side+'_wide_root_paw',(ankle[0]-(1.35 if young else 1.9),.3,-.3),
          (2.7 if young else 3.8,1.6 if young else 2.0,3.9 if young else 5.3),'stone',foot,(5,0,0))
        for digit in [-1,1]:
            b(side+'_paw_root_toe',(ankle[0]+digit*(.65 if young else 1)-(.4 if young else .55),.25,-1.1),
              (.8 if young else 1.1,.9 if young else 1.2,2.3 if young else 3.0),'wood',foot,(5,digit*13,0))


def solve_arm(q,side,world_goal,body_position=(0,0,0),body_rotation=(0,0,0),palm_rotation=(0,0,0)):
    """Return upper/fore/palm Euler rotations and a numeric endpoint error."""
    s=-1 if side=='left' else 1
    start=[s*q['sx'],q['sy'],q['sz']];elbow=[s*q['ex'],q['ey'],q['ez']];wrist=[s*q['wx'],q['wy'],q['wz']]
    body_pivot=[0,q['hip'],q['body_z']];rb=matrix(body_rotation);inverse=transpose(rb)
    goal=add(body_pivot,mv(inverse,sub(sub(world_goal,body_position),body_pivot)))
    direction=sub(goal,start);distance=norm(direction);direction=unit(direction)
    length1=norm(sub(elbow,start));length2=norm(sub(wrist,elbow))
    reachable=max(abs(length1-length2)+.03,min(length1+length2-.03,distance))
    goal=add(start,mul(direction,reachable))
    a=(length1*length1-length2*length2+reachable*reachable)/(2*reachable)
    h=math.sqrt(max(0,length1*length1-a*a))
    pole=mv(inverse,[s,0,.15]);pole=unit(sub(pole,mul(direction,dot(pole,direction))))
    joint=add(add(start,mul(direction,a)),mul(pole,h))
    upper=from_to(sub(elbow,start),sub(joint,start))
    desired_fore=mv(transpose(upper),sub(goal,joint))
    fore=from_to(sub(wrist,elbow),desired_fore)
    global_wrist=mm(rb,mm(upper,fore))
    palm=mm(transpose(global_wrist),matrix(palm_rotation))
    result=add(start,add(mv(upper,sub(elbow,start)),mv(mm(upper,fore),sub(wrist,elbow))))
    world_result=add(add(body_pivot,mv(rb,sub(result,body_pivot))),body_position)
    return euler(upper),euler(fore),euler(palm),norm(sub(world_result,world_goal))


def animate(m):
    q=dimensions(m.stage);young=m.stage==2;pace=.82 if young else 1.0
    factor=.59 if young else 1.0
    def frames(points):return {str(round(t*pace,4)):list(v) for t,v in points}
    def ch(**channels):return {k:frames(v) for k,v in channels.items()}
    def clip(length,bones,loop=False):return {'loop':loop,'animation_length':round(length*pace,4),'bones':bones}
    def rest(side):return [(-1 if side=='left' else 1)*q['wx'],q['wy'],q['wz']]
    def hand(side,x,y,z):
        s=-1 if side=='left' else 1
        return [s*(q['wx']+(x-11.6)*factor),q['wy']+(y-3.4)*factor,q['wz']+(z+5.6)*factor]
    def arm_tracks(poses):
        """Each pose contains body transforms plus independent world targets."""
        tracks={};last={};max_error=0
        for t,bp,br,goals,palm in poses:
            for side in ['left','right']:
                angles=solve_arm(q,side,goals.get(side,rest(side)),bp,br,palm.get(side,(0,0,0)))
                max_error=max(max_error,angles[3])
                for suffix,vec in zip(['_arm','_forearm','_palm'],angles[:3]):
                    key=side+suffix
                    if key in last:
                        vec=[v+360*round((last[key][i]-v)/360) for i,v in enumerate(vec)]
                    last[key]=vec
                    tracks.setdefault(key,[]).append((t,vec))
        assert max_error<.08,('unreachable arm target',m.name,max_error)
        return {bone:ch(rotation=keys) for bone,keys in tracks.items()}
    def body_tracks(poses):
        return ch(position=[(p[0],p[1]) for p in poses],rotation=[(p[0],p[2]) for p in poses])
    def p(t,bp=(0,0,0),br=(0,0,0),left=None,right=None,lp=(0,0,0),rp=(0,0,0)):
        return (t,tuple(v*factor for v in bp),br,
                {'left':left if left is not None else rest('left'),'right':right if right is not None else rest('right')},
                {'left':lp,'right':rp})
    blink=ch(scale=[(0,(1,1,1)),(1.63,(1,1,1)),(1.72,(1,.1,1)),(1.85,(1,1,1)),(4.4,(1,1,1))])

    # Weight settles onto the left knuckles, then the free right hand rolls
    # its wrist and taps once. The head cocks, instead of symmetric bobbing.
    idle_poses=[p(0),p(.7,(-.55,-.18,.08),(-.3,0,-1.2)),
      p(1.35,(-.6,-.12,.12),(0,0,-1.3),right=add(rest('right'),[.25*factor,.9*factor,-.3*factor]),rp=(3,0,-6)),
      p(1.65,(-.5,-.18,.1),(0,0,-1),right=add(rest('right'),[.1*factor,.05*factor,-.5*factor]),rp=(-2,0,2)),
      p(2.3,(-.25,-.03,0)),p(3.25,(.25,.07,0),(0,0,.6)),p(4.4)]
    idle={'body':body_tracks(idle_poses),**arm_tracks(idle_poses),
      'head':ch(rotation=[(0,(0,-3,0)),(.7,(0,3,-6)),(1.5,(-2,7,-8)),(2.3,(1,3,-2)),(3.2,(0,-4,1)),(4.4,(0,-3,0))]),
      'core':ch(position=[(0,(0,0,0)),(1.2,(0,.11,-.05)),(2.3,(0,0,0)),(3.35,(0,.08,-.04)),(4.4,(0,0,0))]),
      'canopy':ch(rotation=[(0,(0,0,-1)),(1.3,(2,0,2)),(2.0,(-1,0,-2)),(3.0,(1,0,1)),(4.4,(0,0,-1))]),
      'tail':ch(rotation=[(0,(0,-3,0)),(2.2,(0,4,0)),(4.4,(0,-3,0))]),'left_eye':blink,'right_eye':blink}

    # Four-beat knuckle locomotion: one front arm supports the barrel while
    # the other swings forward, and the opposite short bowed leg follows.
    walk_poses=[
      p(0,(-.35,-.1,0),(2,-2,-1.3),left=hand('left',11.2,3.4,-7.5),right=hand('right',11.8,3.4,-4.6)),
      p(.18,(-.65,-.35,.1),(3,-3,-2),left=hand('left',11.2,3.4,-7.2),right=hand('right',11.1,5.5,-5.5),rp=(-7,0,-4)),
      p(.35,(-.25,.1,-.1),(1,-1,-.8),left=hand('left',11.6,3.4,-6.0),right=hand('right',11.0,4.8,-8.0)),
      p(.5,(.25,-.2,0),(2,1,1),left=hand('left',11.8,3.4,-4.8),right=hand('right',11.2,3.4,-7.5)),
      p(.68,(.65,-.35,.1),(3,3,2),left=hand('left',11.1,5.5,-5.5),right=hand('right',11.2,3.4,-7.2),lp=(-7,0,4)),
      p(.85,(.2,.1,-.1),(1,1,.7),left=hand('left',11.0,4.8,-8.0),right=hand('right',11.6,3.4,-6.0)),
      p(1.05,(-.35,-.1,0),(2,-2,-1.3),left=hand('left',11.2,3.4,-7.5),right=hand('right',11.8,3.4,-4.6))]
    walk={'body':body_tracks(walk_poses),**arm_tracks(walk_poses),
      'head':ch(rotation=[(0,(-1,2,1)),(.35,(-3,0,0)),(.5,(-1,-2,-1)),(.85,(-3,0,0)),(1.05,(-1,2,1))]),
      'canopy':ch(rotation=[(0,(-2,0,2)),(.27,(3,0,-3)),(.55,(-2,0,-2)),(.8,(3,0,3)),(1.05,(-2,0,2))])}
    for side,s in [('left',-1),('right',1)]:
        walk[side+'_leg']=ch(rotation=[(0,(s*13,0,-s*4)),(.5,(-s*13,0,s*2)),(1.05,(s*13,0,-s*4))])
        walk[side+'_shin']=ch(rotation=[(0,(-s*8,0,0)),(.5,(s*8,0,0)),(1.05,(-s*8,0,0))])
        walk[side+'_foot']=ch(rotation=[(0,(-s*5,0,0)),(.5,(s*5,0,0)),(1.05,(-s*5,0,0))])

    # Both heavy forearms wind high, then strike the earth together. This
    # overhead slam has a different silhouette and rhythm from shield special.
    attack_poses=[p(0),p(.2,(0,-.9,.5),(-4,0,0)),
      p(.42,(0,.1,.6),(-7,0,0),left=hand('left',7.8,27,-2.0),right=hand('right',7.8,27,-2.0),lp=(-22,0,0),rp=(-22,0,0)),
      p(.58,(0,.6,.4),(-9,0,0),left=hand('left',6.6,31,-3),right=hand('right',6.6,31,-3),lp=(-34,0,0),rp=(-34,0,0)),
      p(.78,(0,-2.0,-.8),(10,0,0),left=hand('left',5.8,3.4,-9.0),right=hand('right',5.8,3.4,-9.0),lp=(8,0,0),rp=(8,0,0)),
      p(.88,(0,-2.3,-.55),(12,0,0),left=hand('left',5.9,3.4,-8.8),right=hand('right',5.9,3.4,-8.8)),
      p(1.1,(0,-.8,.1),(3,0,0),left=hand('left',8.5,5.3,-7),right=hand('right',8.5,5.3,-7)),p(1.65)]
    attack={'body':body_tracks(attack_poses),**arm_tracks(attack_poses),
      'head':ch(rotation=[(0,(0,0,0)),(.2,(-7,0,0)),(.58,(-17,0,0)),(.78,(14,0,0)),(.9,(9,0,0)),(1.1,(-2,0,0)),(1.65,(0,0,0))]),
      'canopy':ch(rotation=[(0,(0,0,0)),(.42,(-12,0,0)),(.63,(-8,0,0)),(.81,(19,0,0)),(.98,(-9,0,0)),(1.24,(3,0,0)),(1.65,(0,0,0))]),
      'core':ch(scale=[(0,(1,1,1)),(.58,(1.12,1.12,1.12)),(.82,(.92,.92,.92)),(1.05,(1.06,1.06,1.06)),(1.65,(1,1,1))])}

    # Signature: two unequal percussive forearm beats, low knuckle plant,
    # upward sweep, HEAVY centre clack, impact recoil, braced hold and a weighted
    # release. The palm counter-rotations keep the two complementary cutouts
    # facing forward as ONE shield even though elbows remain widely bent.
    gx=q['guard_x'];gy=q['guard_y'];gz=q['guard_z']
    close=lambda side,x=0,y=0,z=0:[(-1 if side=='left' else 1)*(gx+x),gy+y,gz+z]
    special_poses=[p(0),p(.14,(-.4,-.4,.2),(-2,0,-2)),
      p(.31,(.2,-.55,.25),(2,-4,2),left=hand('left',3.8,14.4,-6),lp=(0,0,-12)),
      p(.43,(-.3,-.25,.1),(-1,3,-2),left=hand('left',7.6,11.3,-6.2),lp=(0,0,6)),
      p(.61,(-.6,-.7,.3),(3,5,-3),right=hand('right',3.3,16.0,-6.3),rp=(0,0,14)),
      p(.75,(.2,-.4,.15),(-1,-2,1),right=hand('right',7.7,11.0,-6.5),rp=(0,0,-6)),
      p(.96,(0,-2.1,.75),(7,0,0),left=hand('left',10.7,3.4,-6.6),right=hand('right',10.7,3.4,-6.6)),
      p(1.17,(0,-1.65,.3),(4,0,0),left=hand('left',7.7,9.3,-8.6),right=hand('right',7.7,9.3,-8.6)),
      p(1.34,(0,-.65,.1),(2,0,0),left=close('left'),right=close('right')),
      p(1.4,(0,-.45,.48),(-1,0,0),left=close('left',-.10,.1,-.2),right=close('right',-.10,.1,-.2)),
      p(1.53,(0,-.8,.35),(3,0,0),left=close('left'),right=close('right')),
      p(1.82,(0,-1.8,1.3),(-3,0,0),left=close('left',0,-.6,.75),right=close('right',0,-.6,.75),lp=(-4,0,0),rp=(-4,0,0)),
      p(2.23,(0,-1.7,1.0),(-2,0,0),left=close('left',0,-.5,.55),right=close('right',0,-.5,.55),lp=(-3,0,0),rp=(-3,0,0)),
      p(2.52,(0,-.7,.4),(1,0,0),left=hand('left',8.1,9.3,-6.8),right=hand('right',8.1,9.3,-6.8),lp=(0,0,-5),rp=(0,0,5)),
      p(2.85,(.2,-.35,0),(0,0,.5)),p(3.15)]
    special={'body':body_tracks(special_poses),**arm_tracks(special_poses),
      'head':ch(rotation=[(0,(0,0,0)),(.14,(-4,-5,-3)),(.31,(6,-6,3)),(.43,(-2,4,-2)),(.61,(8,7,-4)),(.75,(0,-2,1)),(.96,(10,0,0)),(1.17,(4,0,0)),(1.34,(-2,0,0)),(1.4,(5,0,0)),(1.53,(2,0,0)),(1.82,(-8,0,0)),(2.23,(-4,0,0)),(2.52,(2,0,0)),(3.15,(0,0,0))]),
      'canopy':ch(rotation=[(0,(0,0,0)),(.31,(6,0,-4)),(.43,(-3,0,3)),(.61,(9,0,5)),(.75,(-5,0,-3)),(.96,(7,0,0)),(1.34,(-5,0,0)),(1.42,(10,0,0)),(1.58,(-4,0,0)),(1.85,(-9,0,0)),(2.23,(-3,0,0)),(2.7,(3,0,0)),(3.15,(0,0,0))]),
      'core':ch(scale=[(0,(1,1,1)),(.31,(1.07,1.07,1.07)),(.43,(1,1,1)),(.61,(1.12,1.12,1.12)),(.8,(1,1,1)),(1.34,(1.18,1.18,1.18)),(1.53,(1,1,1)),(1.82,(1.1,1.1,1.1)),(2.23,(1,1,1)),(3.15,(1,1,1))])}
    for side,s in [('left',-1),('right',1)]:
        special[side+'_leg']=ch(rotation=[(0,(0,0,0)),(.96,(8,0,s*5)),(1.4,(4,0,s*4)),(1.82,(9,0,s*6)),(2.23,(8,0,s*5)),(3.15,(0,0,0))])
        special[side+'_shin']=ch(rotation=[(0,(0,0,0)),(.96,(-8,0,0)),(1.4,(-4,0,0)),(1.82,(-9,0,0)),(2.23,(-8,0,0)),(3.15,(0,0,0))])

    hurt_poses=[p(0),p(.1,(.35,-.25,.85),(-7,0,2)),
      p(.24,(.15,-.45,.4),(-3,0,1),left=hand('left',8.6,6.0,-6.6),right=hand('right',11.0,3.4,-5.7)),p(.72)]
    squeeze=ch(scale=[(0,(1,1,1)),(.08,(1,.1,1)),(.24,(1,.1,1)),(.47,(1,1,1)),(.72,(1,1,1))])
    hurt={'body':body_tracks(hurt_poses),**arm_tracks(hurt_poses),
      'head':ch(rotation=[(0,(0,0,0)),(.1,(-11,6,5)),(.24,(-5,3,2)),(.72,(0,0,0))]),
      'canopy':ch(rotation=[(0,(0,0,0)),(.13,(8,0,8)),(.34,(-4,0,-3)),(.72,(0,0,0))]),
      'left_eye':squeeze,'right_eye':squeeze}
    faint={'root':ch(rotation=[(0,(0,0,0)),(.48,(-3,0,4)),(.9,(-18,0,9)),(1.28,(-57,0,12)),(1.7,(-62,0,12))],position=[(0,(0,0,0)),(.48,(0,-.5,0)),(.9,(0,-.9,0)),(1.28,(0,1.2,-.5)),(1.7,(0,.9,-.5))]),
      'body':ch(position=[(0,(0,0,0)),(.5,(0,-1,0)),(1.1,(0,-2,.5)),(1.7,(0,-2,.5))]),
      'head':ch(rotation=[(0,(0,0,0)),(.5,(8,0,-4)),(1.3,(17,0,-8)),(1.7,(17,0,-8))]),
      'canopy':ch(rotation=[(0,(0,0,0)),(.8,(12,0,-7)),(1.7,(20,0,-10))]),
      'core':ch(scale=[(0,(1,1,1)),(.7,(.87,.87,.87)),(1.7,(.7,.7,.7))])}
    for side,s in [('left',-1),('right',1)]:
        faint[side+'_eye']=ch(scale=[(0,(1,1,1)),(.45,(1,.1,1)),(1.7,(1,.1,1))])
        faint[side+'_leg']=ch(rotation=[(0,(0,0,0)),(.7,(18,0,s*8)),(1.7,(25,0,s*9))])
        faint[side+'_shin']=ch(rotation=[(0,(0,0,0)),(.7,(-24,0,0)),(1.7,(-32,0,0))])
        faint[side+'_forearm']=ch(rotation=[(0,(0,0,0)),(.8,(-12,0,s*7)),(1.7,(-18,0,s*12))])
    m.animations={'idle':clip(4.4,idle,True),'walk':clip(1.05,walk,True),
      'attack':clip(1.65,attack),'special':clip(3.15,special),
      'hurt':clip(.72,hurt),'faint':clip(1.7,faint)}
