# 틈비 분기 진화 모델 — 첫 제작본

총 9종: 틈비, 불꽃/전기/풀/물의 2단계와 3단계. 직육면체 기반 실제 메시이며 콘셉트 이미지를 그대로 재현한 완성품은 아닙니다. 기본 실루엣과 역할을 구현한 편집 가능한 첫 제작본입니다.

## 파일 사용

- `blockbench/*.bbmodel`: Blockbench의 File → Open Model로 여세요. PNG 텍스처를 파일 안에도 포함했습니다.
- `models/*.geo.json`: Bedrock 형식 geometry. Java 모드에서도 해당 형식을 지원하는 렌더러/연동 계층이 필요합니다.
- `textures/*.png`: 모델별 128×128 픽셀 텍스처. 코어는 밝은 색상이며 실제 발광 셰이더는 포함하지 않습니다.
- `animations/*.animation.json`: 모델별 idle/walk Bedrock 애니메이션. Blockbench에서는 모델을 연 뒤 별도로 Import Animations로 가져오세요. geo와 animation은 동일한 본 이름을 사용합니다.
- `model-preview.png`: 실제 생성 geometry의 정적 미리보기. 픽셀 텍스처 전체나 애니메이션을 재현하는 게임 스크린샷은 아닙니다.

모델 좌표는 16 단위 = 1 블록을 기준으로 합니다. 몸통, 머리, 코어, 양팔과 양다리를 별도 본으로 나눴고 코어 회전/대기 부유 및 기본 걷기를 제공합니다. 틈비는 보행 대신 부유합니다. 물줄기는 불투명한 청색 파츠로 표현했습니다.

## 게임 연동 범위

이 ZIP은 설치 가능한 모드 JAR 또는 완성된 Cobblemon 애드온이 아닙니다. 스폰/타입/진화/능력치/전투/사운드 데이터, 모델 resolver와 poser 등 대상 모드 버전에 맞는 연결 설정은 포함하지 않습니다. Java Minecraft는 geometry 파일만 넣어 새 몬스터를 등록할 수 없습니다. Bedrock 기본 게임 역시 entity/client_entity 등록이 별도로 필요합니다.

JSON 구조, 본 계층, 요소 참조, UV 범위와 애니메이션 대상 본을 검사했습니다. 실제 Blockbench UI 및 Minecraft/Cobblemon에서의 로딩과 애니메이션 재생은 아직 검증하지 않았습니다. 풀의 방패는 결합 상태의 기본 포즈이며 별도 방어 전환 애니메이션은 없습니다.

원본 저장소는 수정하지 않았습니다. 모델 재생성 도구는 ZIP의 tools 폴더에 있습니다. Python 3 및 Pillow가 필요하며 미리보기 생성에는 matplotlib도 필요합니다. 도구는 상위 폴더의 pack 하위에 결과를 만듭니다.
