import json, pathlib, os
os.environ['MPLCONFIGDIR']='/tmp/minadas-mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image
root=pathlib.Path(__file__).parent
names=['teumbi','fire_2','fire_3','electric_2','electric_3','grass_2','grass_3','water_2','water_3']
fig=plt.figure(figsize=(15,15),facecolor='#eeeae2')
for i,name in enumerate(names):
    ax=fig.add_subplot(3,3,i+1,projection='3d',facecolor='#eeeae2')
    m=json.loads((root/'pack/models'/f'{name}.geo.json').read_text())['minecraft:geometry'][0]
    tex=Image.open(root/'pack/textures'/f'{name}.png')
    for b in m['bones']:
        for c in b['cubes']:
            x,y,z=c['origin'];w,h,d=c['size']
            vs=[(x,z,y),(x+w,z,y),(x+w,z+d,y),(x,z+d,y),(x,z,y+h),(x+w,z,y+h),(x+w,z+d,y+h),(x,z+d,y+h)]
            fs=[[vs[k] for k in ids] for ids in [(0,1,2,3),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]]
            u=c['uv']['north']['uv'][0];col=[v/255 for v in tex.getpixel((u+8,8))[:3]]
            colors=[[v*f for v in col] for f in [.65,1,.85,.72,.8,.9]]
            ax.add_collection3d(Poly3DCollection(fs,facecolors=colors,edgecolors='#363844',linewidths=.25))
    ax.set_xlim(-13,13);ax.set_ylim(-10,10);ax.set_zlim(0,33);ax.set_box_aspect((26,20,33));ax.view_init(18,-65);ax.set_axis_off();ax.set_title(name.upper().replace('_',' — STAGE '),fontsize=14)
fig.subplots_adjust(wspace=0,hspace=.02)
fig.savefig(root/'model-preview.png',dpi=130,bbox_inches='tight')
print('Preview rendered')
