import base64, io, json, math, pathlib, random, uuid, zipfile
from PIL import Image

ROOT = pathlib.Path(__file__).parent
OUT = ROOT / 'pack'
OUT.mkdir(exist_ok=True)
def uid(): return str(uuid.uuid4())
def save(path, data):
    p=OUT/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(data,indent=2),encoding='utf8')

palettes={
 'normal':['#777983','#aaa9a5','#50525e','#fff0a6','#dad3c3','#fffbe6'],
 'fire':['#393640','#65535a','#211f29','#ff8a22','#bc452c','#ffe69a'],
 'electric':['#e4dfcb','#fff0bc','#34384b','#ffdc42','#b48a43','#fffce1'],
 'grass':['#69765d','#93a16b','#404d3b','#9ceb60','#806348','#e1ffc0'],
 'water':['#d9e5e5','#f5f0db','#415b76','#59cbea','#428bb8','#dcfcff']}
names=['teumbi','fire_2','fire_3','electric_2','electric_3','grass_2','grass_3','water_2','water_3']
stats={}
for name in names:
    kind='normal' if name=='teumbi' else name.split('_')[0]
    final=name.endswith('_3'); scale=1.0 if final else .72
    rng=random.Random(name)
    tex=Image.new('RGBA',(128,128),(0,0,0,255))
    for index,col in enumerate(palettes[kind]):
        rgb=tuple(bytes.fromhex(col[1:]))
        for y in range(16):
            for x in range(16):
                d=rng.choice([-12,-5,0,0,0,6,12])
                tex.putpixel((index*16+x,y),tuple(max(0,min(255,c+d)) for c in rgb)+(255,))
    buf=io.BytesIO();tex.save(buf,format='PNG'); encoded=base64.b64encode(buf.getvalue()).decode()
    p=OUT/'textures'/f'{name}.png';p.parent.mkdir(exist_ok=True);p.write_bytes(buf.getvalue())
    groups={}; elements=[]; bones=[]
    def group(n,pivot,parent='root'):
        g={'name':n,'origin':[v*scale for v in pivot],'uuid':uid(),'children':[]}
        groups[n]=g
        bone={'name':n,'pivot':g['origin'],'cubes':[]}
        if parent: bone['parent']=parent
        bones.append(bone)
        if parent: groups[parent]['children'].append(g)
    group('root',(0,0,0),None)
    def cube(g,pos,size,c=0):
        a=[round(v*scale,4) for v in pos];s=[round(v*scale,4) for v in size]
        uv=[c*16,0,c*16+16,16]
        faces={f:{'uv':uv[:],'texture':0} for f in ['north','south','east','west','up','down']}
        e={'name':g+'_'+str(len(elements)),'uuid':uid(),'type':'cube','from':a,'to':[round(a[i]+s[i],4) for i in range(3)],'origin':groups[g]['origin'],'rotation':[0,0,0],'faces':faces,'rescale':False,'box_uv':False,'autouv':0,'color':c}
        elements.append(e);groups[g]['children'].append(e['uuid'])
        buv={f:{'uv':[c*16,0],'uv_size':[16,16]} for f in faces}
        next(b for b in bones if b['name']==g)['cubes'].append({'origin':a,'size':s,'uv':buv})
    if kind=='normal':
        scale=1
        group('core',(0,10,0));cube('core',(-2,8,-2),(4,4,4),3);cube('core',(-1,9,-2.15),(2,2,.2),5)
        group('head',(0,15,0));cube('head',(-3,14,-3),(6,4,6),0)
        for x in [-1.8,.8]:cube('head',(x,15,-3.1),(1,1.4,.2),5)
        for n,origin,pieces in [('shell_left',(-5,10,0),[(-7,8,-2,3,5,4),(-5,12,-1,2,2,3)]),('shell_right',(5,10,0),[(4,8,-2,3,4,4),(4,13,-1,2,2,3)]),('shell_bottom',(0,5,0),[(-2,3,-2,4,3,4),(-4,5,-1,2,2,2),(3,5,0,2,2,2)])]:
            group(n,origin)
            for x,y,z,w,h,d in pieces:cube(n,(x,y,z),(w,h,d),0)
    else:
        heavy=kind in ['fire','grass']; width=(10 if final else 7) if heavy else (5 if final else 4)
        group('body',(0,15,0));group('core',(0,16,0));cube('core',(-1.7,14.3,-1.7),(3.4,3.4,3.4),3)
        cube('core',(-.7,15.3,-1.8),(1.4,1.4,.2),5)
        cube('body',(-width/2,19,-2),(width,2,4),0);cube('body',(-width/2,11,-2),(width,2,4),0)
        for x in [-width/2,width/2-1]:cube('body',(x,13,-1.5),(1,6,3),1)
        group('head',(0,23,0));cube('head',(-2.8,22,-2.4),(5.6,5,4.8),0)
        cube('head',(-2,23,-2.55),(4,2,.2),2)
        for x in [-1.7,.7]:cube('head',(x,23.3,-2.7),(1,1,.2),3)
        for side,sgn in [('left',-1),('right',1)]:
            x=sgn*(width/2+2)
            group(side+'_arm',(x,20,0));cube(side+'_arm',(x-1.5,16,-1.6),(3,5,3.2),0)
            cube(side+'_arm',(x-2,19,-2),(4,3,4),1)
            cube(side+'_arm',(x-1,11,-1.2),(2,4,2.4),2)
            group(side+'_leg',(sgn*2,10,0));cube(side+'_leg',(sgn*2-1.3,5,-1.3),(2.6,5,2.6),0)
            cube(side+'_leg',(sgn*2-1.6,1,-2),(3.2,3,4.5),1)
            if kind=='fire':
                cube(side+'_arm',(x-1.5,8,-1.5),(3,4,3),2)
                cube(side+'_arm',(x-2.3,6,-3),(4.6,7,1.2),4)
                cube(side+'_arm',(x-2.3,6,-3.5),(4.6,7,.5),3)
                for j in range(3):
                    cube(side+'_arm',(x-1.5-j*.6,8+j,-2.5-j*.8),(3+j*1.2,4-j,1.5),4)
                    cube(side+'_arm',(x-1.5-j*.6,8+j,-2.8-j*.8),(3+j*1.2,1,.4),3)
                if final:cube(side+'_arm',(x-2.4,21,-2.2),(4.8,2,4.4),2)
            if kind=='grass':
                # Both shield halves form a broad guard with a visible seam.
                sx=-6.1 if sgn<0 else .1
                cube(side+'_arm',(sx,7,-5),(6,11 if final else 8,2),0)
                cube(side+'_arm',(sx+.5,8,-5.4),(5,8 if final else 5,.5),4)
                cube(side+'_arm',(sx+1,9,-5.7),(4,2,.4),1)
                cube(side+'_arm',(x-2,21,-2),(4,2,4),4)
        if kind=='fire':
            for x in [-2,1]:cube('head',(x,27,-1),(1,2,2),2)
            cube('body',(-2,11,-2.3),(4,1,.5),3)
        elif kind=='electric':
            group('rod',(3,15,1));cube('rod',(3,8,1),(.8,23 if final else 19,.8),4)
            cube('rod',(1.7,29 if final else 25,.4),(3.4,.8,2),3)
            for x in [1.7,4.3]:cube('rod',(x,29 if final else 25,.4),(.8,3,1),4)
            cube('body',(1.5,16,1),(2,1,1),4)
            for x in [-3,2]:cube('head',(x,26,0),(1,4,1),4)
            for x in [-3,-1,1]:cube('body',(x,6,1),(1.5,6,1),1)
            if final:
                for x in [-4,-2,1,3]:cube('body',(x,4,2),(1.5,8,1),0)
        elif kind=='grass':
            for x,h in [(-2,2),(0,3),(2,2)]:cube('head',(x,27,-.5),(1.5,h,2),1)
            cube('body',(-4,20,1),(8,3,3),4)
        elif kind=='water':
            group('harp',(5,16,-2))
            cube('harp',(4,9,-3),(1,12,1),4);cube('harp',(9,9,-3),(1,12,1),0)
            cube('harp',(4,9,-3),(6,1,1),1);cube('harp',(4,21,-3),(6,1,1),1)
            for x in [5.2,6.3,7.4,8.5]:cube('harp',(x,10,-2.8),(.25,11,.3),3)
            for j in range(8 if final else 5):
                x=-5-j*.6; y=24-j*1.5
                cube('body',(x,y,1),(2,1.2,1),3)
            for x in [-3,-1,1]:cube('body',(x,5,1),(1.5,7,1),1)
            if final:
                for x in [-4,-2,0,2]:cube('body',(x,3,2),(1.5,8,1),0)
            for x in [-3,2]:cube('head',(x,24,0),(1,4,1),4)
    model={'meta':{'format_version':'4.10','model_format':'bedrock','box_uv':False},'name':name,'model_identifier':'geometry.'+name,'visible_box':[4,4,1],'resolution':{'width':128,'height':128},'elements':elements,'outliner':[groups['root']],'textures':[{'path':f'../textures/{name}.png','name':name+'.png','folder':'','namespace':'','id':'0','uuid':uid(),'particle':False,'render_mode':'default','visible':True,'mode':'bitmap','saved':True,'width':128,'height':128,'uv_width':128,'uv_height':128,'source':'data:image/png;base64,'+encoded}],'animations':[]}
    save(pathlib.Path('blockbench')/(name+'.bbmodel'),model)
    save(pathlib.Path('models')/(name+'.geo.json'),{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.'+name,'texture_width':128,'texture_height':128,'visible_bounds_width':4,'visible_bounds_height':4,'visible_bounds_offset':[0,1,0]},'bones':bones}]})
    floating={'root':{'position':[0,'math.sin(query.anim_time * 180) * 0.25',0]},'core':{'rotation':[0,'query.anim_time * 30',0]}}
    walking={'root':{'position':[0,'math.sin(query.anim_time * 720) * 0.15',0]}}
    for side,sign in [('left',1),('right',-1)]:
        if side+'_leg' in groups:walking[side+'_leg']={'rotation':[f'math.sin(query.anim_time * 360) * {25*sign}',0,0]}
        if side+'_arm' in groups:walking[side+'_arm']={'rotation':[f'math.sin(query.anim_time * 360) * {-12*sign}',0,0]}
    save(pathlib.Path('animations')/(name+'.animation.json'),{'format_version':'1.8.0','animations':{f'animation.{name}.idle':{'loop':True,'animation_length':2,'bones':floating},f'animation.{name}.walk':{'loop':True,'animation_length':1,'bones':walking}}})
    stats[name]={'cubes':len(elements),'bones':len(bones)}
save(pathlib.Path('manifest.json'),stats)
print(json.dumps(stats,indent=2))

