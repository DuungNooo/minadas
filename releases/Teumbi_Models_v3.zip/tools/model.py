"""Cuboid authoring and lossless Blockbench/Bedrock export, no mesh smoothing."""
import base64, hashlib, io, json, math, pathlib, uuid
from PIL import Image
from textures import tile

def uid(text): return str(uuid.uuid5(uuid.NAMESPACE_DNS, 'teumbi.v3.'+text))
FACE_DIMS={'north':(0,1),'south':(0,1),'east':(2,1),'west':(2,1),'up':(0,2),'down':(0,2)}

def bedrock_pivot(vector):
    """Blockbench's editor X axis is reflected in the Bedrock codec."""
    return [-vector[0], vector[1], vector[2]]

def bedrock_rotation(vector):
    return [-vector[0], -vector[1], vector[2]]

def bedrock_keyframe(channel, vector):
    """Canonical editor motion -> Bedrock and legacy .bbmodel 4.x motion.

    Reference: Blockbench's bedrock_animation.js importer/exporter and the
    bbmodel.js export_legacy_project compatibility path. Modern Blockbench
    flips these same channels while importing a 4.10 project.
    """
    def negate(value):
        return -value if isinstance(value, (int, float)) else f'-({value})'
    result = list(vector)
    if channel in ('position', 'rotation'):
        result[0] = negate(result[0])
    if channel == 'rotation':
        result[1] = negate(result[1])
    return result

def bedrock_face(face, uv):
    x, y, x2, y2 = uv
    if face in ('up', 'down'):
        return {'uv': [x2, y2], 'uv_size': [x-x2, y-y2]}
    return {'uv': [x, y], 'uv_size': [x2-x, y2-y]}

class Model:
    def __init__(self,name,kind,stage):
        self.name,self.kind,self.stage=name,kind,stage
        self.bones=[]; self.boxes=[]; self.animations={}
        self.bone('root',parent=None)
    def bone(self,name,pivot=(0,0,0),parent='root',rotation=(0,0,0)):
        assert name not in {b['name'] for b in self.bones},name
        assert parent is None or parent in {b['name'] for b in self.bones},parent
        self.bones.append(dict(name=name,pivot=list(pivot),parent=parent,rotation=list(rotation)))
        return name
    def box(self,name,origin,size,material='stone',bone='body',rotation=(0,0,0),pivot=None):
        assert bone in {b['name'] for b in self.bones},bone
        assert len(size)==3 and min(size)>0,(name,size)
        base=name; counter=2; existing={b['name'] for b in self.boxes}
        while name in existing:name=base+'_'+str(counter);counter+=1
        self.boxes.append(dict(name=name,origin=list(origin),size=list(size),material=material,bone=bone,rotation=list(rotation),pivot=list(pivot) if pivot is not None else [origin[i]+size[i]/2 for i in range(3)]))
    def animate(self):
        raise RuntimeError('V3 uses species-specific animation authoring')
    def export(self,out):
        # Overlapping sculpting cubes must not leave coincident outer planes:
        # those flicker in a rasterizer and cause black self-shadow bands.
        # A sub-pixel inset preserves the silhouette and the editable cubes.
        for i,b in enumerate(self.boxes):
            for previous in self.boxes[:i]:
                if b['bone']!=previous['bone']:continue
                if any(abs(b['rotation'][a])>1e-7 or abs(previous['rotation'][a])>1e-7 for a in (0,1)):continue
                overlap=[min(b['origin'][a]+b['size'][a],previous['origin'][a]+previous['size'][a])-max(b['origin'][a],previous['origin'][a]) for a in range(3)]
                if min(overlap)<=1e-6:continue
                axes=[2] if b['rotation'][2] or previous['rotation'][2] else [0,1,2]
                for a in axes:
                    equal_min=abs(b['origin'][a]-previous['origin'][a])<1e-7
                    equal_max=abs(b['origin'][a]+b['size'][a]-previous['origin'][a]-previous['size'][a])<1e-7
                    if (equal_min or equal_max) and b['size'][a]>.08:
                        b['origin'][a]+=.0125;b['size'][a]-=.025
        out=pathlib.Path(out);(out/'textures').mkdir(parents=True,exist_ok=True)
        # Pixel density follows physical face dimensions; atlas faces never overlap.
        faces=[]
        for i,b in enumerate(self.boxes):
            b['uv']={}
            for f,(a,c) in FACE_DIMS.items():
                w=max(2,math.ceil(b['size'][a]*2));h=max(2,math.ceil(b['size'][c]*2))
                faces.append((i,f,w,h))
        for resolution in [128,256,512,1024]:
            x=y=1;row=0;placements=[]
            for i,f,w,h in faces:
                if x+w+1>resolution:x=1;y+=row+2;row=0
                if y+h+1>resolution:break
                placements.append((i,f,x,y,w,h));x+=w+2;row=max(row,h)
            if len(placements)==len(faces):break
        assert len(placements)==len(faces),'Atlas overflow'
        atlas=Image.new('RGBA',(resolution,resolution),(0,0,0,0));emissive=Image.new('RGBA',atlas.size,(0,0,0,0))
        for i,f,x,y,w,h in placements:
            b=self.boxes[i]
            t=tile(self.kind,b['material'],w,h,f'{self.name}.{b["name"]}.{f}',f)
            atlas.paste(t,(x,y));b['uv'][f]=[x,y,x+w,y+h]
            # Pad borders to keep texture filtering safe.
            atlas.paste(t.crop((0,0,w,1)),(x,y-1));atlas.paste(t.crop((0,h-1,w,h)),(x,y+h))
            atlas.paste(t.crop((0,0,1,h)),(x-1,y));atlas.paste(t.crop((w-1,0,w,h)),(x+w,y))
            if b['material'] in ['glow','hot']:emissive.paste(t,(x,y))
        atlas.save(out/'textures'/f'{self.name}.png');emissive.save(out/'textures'/f'{self.name}_emissive.png')
        encoded=io.BytesIO();atlas.save(encoded,format='PNG')
        groups={};bones=[];elements=[]
        for b in self.bones:
            g={'name':b['name'],'origin':b['pivot'],'rotation':b['rotation'],'uuid':uid(self.name+'.bone.'+b['name']),'children':[],'export':True,'isOpen':False,'visibility':True}
            groups[b['name']]=g
            if b['parent']:groups[b['parent']]['children'].append(g)
            bone={'name':b['name'],'pivot':bedrock_pivot(b['pivot']),'rotation':bedrock_rotation(b['rotation']),'cubes':[]}
            if b['parent']:bone['parent']=b['parent']
            bones.append(bone)
        for b in self.boxes:
            e={'name':b['name'],'uuid':uid(self.name+'.box.'+b['name']),'type':'cube','from':b['origin'],'to':[round(b['origin'][i]+b['size'][i],5) for i in range(3)],'origin':b['pivot'],'rotation':b['rotation'],'box_uv':False,'rescale':False,'autouv':0,'visibility':True,'export':True,'faces':{f:{'uv':uv,'texture':0,'rotation':0} for f,uv in b['uv'].items()}}
            elements.append(e);groups[b['bone']]['children'].append(e['uuid'])
            c={'origin':[-b['origin'][0]-b['size'][0],b['origin'][1],b['origin'][2]],'size':b['size'],'uv':{f:bedrock_face(f,uv) for f,uv in b['uv'].items()}}
            if any(b['rotation']):c.update(rotation=bedrock_rotation(b['rotation']),pivot=bedrock_pivot(b['pivot']))
            next(v for v in bones if v['name']==b['bone'])['cubes'].append(c)
        anims=[]
        for n,a in self.animations.items():
            animators={}
            for bn,channels in a['bones'].items():
                keyframes=[]
                for channel,frames in channels.items():
                    for time,vec in frames.items():keyframes.append({'channel':channel,'time':float(time),'interpolation':'linear','data_points':[dict(zip(['x','y','z'],[str(v) for v in bedrock_keyframe(channel,vec)]))],'uuid':uid(self.name+n+bn+channel+time)})
                animators[groups[bn]['uuid']]={'name':bn,'type':'bone','keyframes':keyframes}
            anims.append({'uuid':uid(self.name+n),'name':f'animation.{self.name}.{n}','loop':'loop' if a['loop'] else 'once','override':False,'length':a['animation_length'],'snapping':24,'animators':animators})
        bb={'meta':{'format_version':'4.10','model_format':'bedrock','box_uv':False},'name':self.name,'model_identifier':self.name,'visible_box':[5,5,2],'resolution':{'width':resolution,'height':resolution},'elements':elements,'outliner':[groups['root']],'textures':[{'path':f'../textures/{self.name}.png','name':self.name+'.png','uuid':uid(self.name+'.texture'),'id':'0','folder':'','namespace':'','mode':'bitmap','saved':True,'visible':True,'render_mode':'default','width':resolution,'height':resolution,'uv_width':resolution,'uv_height':resolution,'source':'data:image/png;base64,'+base64.b64encode(encoded.getvalue()).decode()}],'animations':anims}
        geometry={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':f'geometry.{self.name}','texture_width':resolution,'texture_height':resolution,'visible_bounds_width':5,'visible_bounds_height':6,'visible_bounds_offset':[0,1.5,0]},'bones':bones}]}
        def write(folder,file,data):
            p=out/folder/file;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
        write('blockbench',self.name+'.bbmodel',bb)
        write('models',self.name+'.geo.json',geometry)
        runtime_animations={}
        for n,a in self.animations.items():
            runtime_animations[f'animation.{self.name}.{n}']={
                'loop':a['loop'], 'animation_length':a['animation_length'],
                'bones':{bn:{channel:{time:bedrock_keyframe(channel,vec) for time,vec in frames.items()} for channel,frames in channels.items()} for bn,channels in a['bones'].items()}
            }
        write('animations',self.name+'.animation.json',{'format_version':'1.8.0','animations':runtime_animations})
        write('source',self.name+'.json',{'name':self.name,'kind':self.kind,'stage':self.stage,'bones':self.bones,'boxes':self.boxes,'texture_size':resolution,'animations':self.animations})
        return {'name':self.name,'kind':self.kind,'stage':self.stage,'cubes':len(elements),'bones':len(bones),'texture_size':resolution,'animations':list(self.animations)}
