"""Quiet creature colours, with broad pixel markings rather than armour panels.

Each surface is authored at its native pixel size.  There are deliberately no
border frames, screws, inset rectangles, circuit traces, or all-over noise.
"""
from __future__ import annotations

import hashlib
import random
from PIL import Image, ImageDraw


PALETTES = {
    'normal': {
        'stone': '#ADA99C', 'dark': '#69646B', 'light': '#E6DFC8',
        'trim': '#BDA875', 'accent': '#A4C2B3', 'glow': '#F8DEA0',
        'hot': '#F2CA7B', 'wood': '#8F7960', 'leaf': '#A4AE83',
        'water': '#9DCCC1', 'metal': '#B7AD95', 'string': '#FFF0BF',
        'eye': '#FFF9E9', 'pupil': '#333440', 'mouth': '#635760',
        'blush': '#D9A798',
    },
    'fire': {
        'stone': '#66515A', 'dark': '#3A3649', 'light': '#E8BA8D',
        'trim': '#A96B54', 'accent': '#DC7045', 'glow': '#FFD381',
        'hot': '#FA9A4B', 'wood': '#8B5A4C', 'leaf': '#C8865C',
        'water': '#F4BB78', 'metal': '#887078', 'string': '#FFE1A8',
        'eye': '#FFF1CF', 'pupil': '#352B3F', 'mouth': '#54303D',
        'blush': '#D98269',
    },
    'electric': {
        'stone': '#EED180', 'dark': '#6C6080', 'light': '#FFF1CE',
        'trim': '#D4A85E', 'accent': '#F4B94E', 'glow': '#FFE99A',
        'hot': '#FFF7C8', 'wood': '#AA8663', 'leaf': '#B5BD81',
        'water': '#C9D2D1', 'metal': '#AF9474', 'string': '#FFF6C2',
        'eye': '#FFFAEB', 'pupil': '#423854', 'mouth': '#6A4F70',
        'blush': '#E5A0A4',
    },
    'grass': {
        'stone': '#90AA79', 'dark': '#4E6B56', 'light': '#E7DEB5',
        'trim': '#B0A269', 'accent': '#B8CD7E', 'glow': '#D0EDA0',
        'hot': '#E6F4B9', 'wood': '#987755', 'leaf': '#5F955D',
        'water': '#9EC7A2', 'metal': '#A8A782', 'string': '#EFE4B2',
        'eye': '#FFFADE', 'pupil': '#354A3D', 'mouth': '#65734F',
        'blush': '#C5B785',
    },
    'water': {
        'stone': '#75B7BE', 'dark': '#435C79', 'light': '#E5F0DC',
        'trim': '#B2BA9A', 'accent': '#E4A38E', 'glow': '#ABECED',
        'hot': '#D6FBF4', 'wood': '#A0B5A2', 'leaf': '#8FC3AB',
        'water': '#60BBCC', 'metal': '#A6C8C1', 'string': '#F2F7D5',
        'eye': '#FFFCEF', 'pupil': '#344761', 'mouth': '#617088',
        'blush': '#E7B8A9',
    },
}


def _rgb(value):
    value=value.lstrip('#')
    return tuple(int(value[i:i+2],16) for i in (0,2,4))


def _mix(a,b,t):
    return tuple(round(x*(1-t)+y*t) for x,y in zip(a,b))


def tile(kind,material,width,height,seed,face='north'):
    """Return an opaque native-resolution pixel tile, deterministically."""
    width,height=max(1,int(width)),max(1,int(height))
    kind=kind if kind in PALETTES else 'normal'
    palette=PALETTES[kind]
    material=material if material in palette else 'stone'
    rng=random.Random(int.from_bytes(hashlib.sha256(
        f'{kind}/{material}/{seed}/{face}'.encode()).digest()[:8],'little'))
    base=_rgb(palette[material])
    # Flat eye/pupil/mouth patches stay readable even on a two-pixel face.
    if material in ('pupil','mouth','eye','string','blush'):
        image=Image.new('RGBA',(width,height),base+(255,))
        if material=='pupil' and width>=5 and height>=6:
            ImageDraw.Draw(image).rectangle((0,height-2,width-1,height-1),fill=_mix(base,(84,75,97),.15)+(255,))
        return image

    direction={'up':.025,'down':-.075,'east':-.012,'west':.012}.get(face,0)
    base=_mix(base,(255,252,231) if direction>=0 else (35,42,55),abs(direction))
    light=_mix(base,(255,252,231),.10)
    shade=_mix(base,(44,49,65),.11)
    image=Image.new('RGBA',(width,height),base+(255,))
    draw=ImageDraw.Draw(image)
    def rect(bounds,color):draw.rectangle(bounds,fill=color+(255,))
    def line(points,color,stroke=1):draw.line(points,fill=color+(255,),width=stroke)

    if material in ('glow','hot'):
        # A broad, soft mineral gleam, not a framed machine display.
        if min(width,height)>=5:
            cx=max(1,width//3);cy=max(1,height//3)
            rect((cx,cy,min(width-1,cx+max(1,width//3)),min(height-1,cy+max(1,height//3))),_mix(base,(255,255,232),.40))
            if width>=8 and height>=8:
                rect((cx-1,cy+1,cx,min(height-1,cy+max(2,height//3))),_mix(base,(255,255,235),.23))
        return image

    # Only a small stepped lower shadow: there is no hard border around parts.
    if min(width,height)>=5 and face!='up':
        depth=max(1,height//7)
        rect((0,height-depth,width-1,height-1),shade)
        if width>=8 and height>=8:
            left=rng.choice((0,width//2))
            rect((left,height-depth-1,min(width-1,left+width//3),height-depth-1),shade)

    if material=='wood':
        # Wide bark colour fields, not metallic channels or dense wood grain.
        if width>=7 and height>=7:
            x=max(1,width//3)
            rect((x,1,min(width-1,x+max(1,width//7)),height-2),_mix(base,shade,.60))
            if width>=13:
                x=width*3//4
                rect((x,height//3,min(width-1,x+1),height-2),_mix(base,light,.60))
    elif material in ('leaf','accent') and kind=='grass':
        # A single organic midrib, with two very quiet broad branches.
        if width>=7 and height>=9:
            x=width//2
            line([(x,2),(x,height-2)],_mix(base,shade,.55))
            line([(x,height//2),(max(1,x-width//4),max(1,height//3))],_mix(base,light,.6))
            line([(x,height*2//3),(min(width-2,x+width//4),height//2)],_mix(base,light,.6))
    elif material=='water':
        # One or two soft stepped foam marks across the whole surface.
        if width>=6 and height>=5:
            x=max(0,width//5);y=max(1,height//3)
            rect((x,y,min(width-1,x+width//2),y),_mix(base,(222,250,235),.34))
            if width>=11 and height>=9:
                rect((width//2,height*2//3,width-2,height*2//3),_mix(base,(222,250,235),.22))
    elif material in ('trim','metal'):
        # These names remain for the modelling API, but behave like warm horn,
        # mineral, or soft keratin instead of manufactured armour.
        if min(width,height)>=8:
            rect((1,1,max(1,width//2),max(1,height//7)),light)
    elif material in ('stone','light','dark','accent'):
        # Sparse broad natural markings.  The unmarked majority is intentional.
        area=width*height
        if min(width,height)>=7 and area>=100 and rng.random()<.65:
            x=rng.randrange(max(1,width//3),max(2,width*2//3))
            y=rng.randrange(max(1,height//3),max(2,height*2//3))
            w=max(2,width//5);h=max(1,height//9)
            color=_mix(base,light,.70) if rng.random()<.55 else _mix(base,shade,.65)
            rect((x,y,min(width-1,x+w),min(height-1,y+h)),color)
            if h>=2:
                rect((max(0,x-1),y+1,min(width-1,x+w+1),min(height-1,y+h-1)),color)
        if kind=='grass' and material=='stone' and min(width,height)>=9 and rng.random()<.4:
            moss=_mix(base,_rgb(palette['leaf']),.25)
            rect((0,height//2,max(1,width//5),height*3//4),moss)
        elif kind=='fire' and material=='stone' and min(width,height)>=10 and rng.random()<.35:
            # One warm ember patch reads as a natural birthmark, not a crack.
            ember=_mix(base,_rgb(palette['accent']),.28)
            x=max(1,width*2//3);y=max(1,height//3)
            rect((x,y,min(width-1,x+width//5),min(height-1,y+height//5)),ember)
    return image
