"""A warm pearl-and-tide creature. Its harp is a grown fin, not equipment."""
def build(m,stage):
    final=stage==3;s=1 if final else .72
    def bone(n,p,parent='body',r=(0,0,0)):
        p=list(p)
        if n=='harp' or n.startswith('string_'):p[0]-=4
        m.bone(n,[v*s for v in p],parent,r)
    def box(n,p,z,mat='stone',b='body',r=(0,0,0)):
        p=list(p)
        if b=='harp' or b.startswith('string_'):p[0]-=4
        m.box(n,[v*s for v in p],[v*s for v in z],mat,b,r)
    def soft(n,p,z,mat='stone',b='body'):
        x,y,z0=p;w,h,d=z;cut=min(w,h,d)*.16
        box(n,(x+cut,y,z0),(w-2*cut,h,d),mat,b)
        box(n+'_cheek',(x,y+cut,z0+cut),(w,h-2*cut,d-2*cut),mat,b)
        box(n+'_face',(x+cut*.5,y+cut*.6,z0-.02),(w-cut,h-cut*1.2,d*.14),mat,b)
    bone('body',(0,13,0),'root');bone('core',(0,20.2,-.2));bone('head',(0,25,0))
    bone('left_arm',(-4.2,21,0));bone('left_forearm',(-5.3,17,0),'left_arm')
    bone('right_arm',(4.2,21,0));bone('right_forearm',(5.1,17,0),'right_arm')
    bone('left_leg',(-2.7,7,0));bone('right_leg',(2.7,7,0))
    bone('ear_left',(-4,28,0),'head');bone('ear_right',(4,28,0),'head')
    for side,x in [('left',-2.25),('right',2.25)]:bone('eye_'+side,(x,28.6,-3.13),'head')
    bone('harp',(6.5,19,-.4),'right_forearm')
    bone('ribbon_base',(-3,22,1.4));bone('ribbon_mid',(-8.5,19.5,1.4),'ribbon_base');bone('ribbon_tip',(-9,12,1.4),'ribbon_mid')
    soft('tide_hip',(-3.6,10.3,-2.2),(7.2,5.7,4.4),'stone')
    soft('pearl_belly',(-2.7,13,-2.35),(5.4,4,4.6),'light')
    # A single continuous bell-shaped caudal fin with small feet below.
    box('bell_top',(-3.3,9,-1.7),(6.6,2.8,3.4),'water')
    box('bell_middle',(-4.4,6.8,-1.5),(8.8,2.8,3.5),'water')
    box('bell_lip',(-5.3,5.4,-1.5),(10.6,2,3.6),'stone')
    for side,sg in [('left',-1),('right',1)]:
        soft(side+'_flipper',(sg*2.7-1.25,1.6,-2),(2.5,3.4,4),'stone',side+'_leg')
        box(side+'_toe',(sg*2.7-1.1,1.7,-2.5),(2.2,1,1),'light',side+'_leg')
        # Flesh-like water shoulders with no cuffs, joints or plates.
        soft(side+'_shoulder',(sg*4.2-1.1,19,-1.3),(2.2,3.5,2.6),'stone',side+'_arm')
        soft(side+'_upper_fin',(sg*4.8-.8,16.5,-1),(1.6,3,2),'stone',side+'_arm')
        soft(side+'_hand',(sg*5.5-1.1,13.4,-1.4),(2.2,3.3,2.8),'light',side+'_forearm')
        box(side+'_hand_fin',(sg*6.2-.7,14.5,-.7),(1.4,3,1.4),'water',side+'_forearm',r=(0,0,-sg*20))
    # Soft curved pectoral tissue surrounds an exposed suspended single heart.
    box('throat',(-1.45,23.1,-1.3),(2.9,1.7,2.6),'light')
    box('upper_chest',(-3.6,22.1,-1.1),(7.2,1.2,2.2),'stone')
    for sg in [-1,1]:box('chest_side',(sg*3-.5,18,-1.2),(1,4.3,2.4),'stone',r=(0,0,sg*11))
    soft('one_heart',(-1.5,18.8,-1.7),(3,3,3),'glow','core')
    # Large rounded face with big individual pupils, cheeks and a smile.
    head_w=9.4 if final else 10.4
    soft('soft_face',(-head_w/2,25,-2.8),(head_w,7.3,5.6),'light','head')
    box('crown_patch',(-2.6,31.3,-2.3),(5.2,1.7,4.4),'stone','head')
    for side,sg in [('left',-1),('right',1)]:
        x=sg*2.25;eye='eye_'+side
        box(side+'_eye_white',(x-.9,27.7,-2.99),(1.8,2.3,.22),'eye',eye)
        box(side+'_pupil',(x-.5+sg*.08,27.8,-3.14),(.95,1.9,.18),'pupil',eye)
        box(side+'_spark',(x-.32,28.95,-3.28),(.38,.55,.16),'eye',eye)
        box(side+'_cheek',(sg*3.3-.55,26.7,-2.99),(1.1,.5,.2),'blush','head')
        ear='ear_'+side
        box(side+'_fin_base',(sg*4.9-1.2,27,.2),(2.4,2.6,2.4),'stone',ear,r=(0,0,-sg*12))
        box(side+'_fin_tip',(sg*6-1,28.2,.5),(2,1.8,1.8),'water',ear,r=(0,0,-sg*25))
        box(side+'_fin_pearl',(sg*6.7-.6,29.1,.65),(1.2,1.1,1.4),'light',ear)
    box('smile',(-.7,26.4,-3.0),(1.4,.25,.18),'mouth','head')
    box('smile_left',(-.95,26.65,-2.99),(.3,.28,.2),'mouth','head')
    box('smile_right',(.65,26.65,-2.99),(.3,.28,.2),'mouth','head')
    # One swept-back crest (no symmetrical robot horns).
    box('crest_root',(-.7,32.3,-.1),(2.4,1.7,2.2),'water','head',r=(0,0,-14))
    box('crest_sweep',(.4,33.4,.1),(2.8,1.1,1.6),'stone','head',r=(0,0,-20))
    if final:box('crest_tip',(2.4,33.6,.2),(1.9,.8,1.4),'water','head',r=(0,0,-20))
    # A compact, crescent fin-harp grown from the right hand.
    bx=6.3;by=13.7;top=24.3
    box('harp_foot',(bx,by,-1.5),(4.6,1.3,1.6),'light','harp',r=(0,0,-6))
    for j,(x,y,w,h) in enumerate([(10,14.5,1.4,3.3),(10.9,17.3,1.5,3.4),(10.5,20.4,1.4,2.8),(9.2,22.5,1.9,1.4),(7.2,23.3,2.3,1)]):
        box('harp_curved_fin_'+str(j),(x,y,-1.4),(w,h,1.4),'stone' if j%2 else 'water','harp',r=(0,0,[-8,0,12,20,8][j]))
    for j in range(6 if final else 4):
        x=7.1+j*.62;h=8.6-j*.22
        bone('string_'+str(j),(x,by+1,-1),'harp')
        box('string_'+str(j),(x,by+1,-1),(.14,h,.18),'string','string_'+str(j))
    # Foreground water ribbons form one S-shaped tail with three articulated parts.
    paths=[('ribbon_base',[(-4,22.8,1),(-6,23.2,1),(-8,22.7,.8),(-9.3,21.4,.5)]),('ribbon_mid',[(-9.8,19.6,.2),(-10,17.6,0),(-9.2,15.7,-.2),(-7.7,14.4,-.4)]),('ribbon_tip',[(-7.2,12.6,-.5),(-8,11,-.5),(-9.7,10.2,-.4)])]
    if not final:paths=paths[:2]
    for b,path in paths:
        for j,(x,y,z) in enumerate(path):box(b+'_'+str(j),(x,y,z),(2.2,2,1.1),'water' if j%2 else 'stone',b,r=(0,0,8 if j%2 else -8))

def animate(m):
    mature=m.stage==3
    def k(*items):return {str(t):v for t,v in items}
    def R(*v):return {'rotation':k(*v)}
    def P(*v):return {'position':k(*v)}
    def S(*v):return {'scale':k(*v)}
    def clip(length,loop,bones):return {'animation_length':length,'loop':loop,'bones':{n:v for n,v in bones.items() if n in {b['name'] for b in m.bones}}}
    idle={'body':P((0,[0,0,0]),(1.4,[0,.3,0]),(3.2,[0,0,0])), 'head':R((0,[0,-5,-2]),(1.1,[2,3,2]),(2.3,[-2,5,0]),(3.2,[0,-5,-2])), 'left_arm':R((0,[0,0,-8]),(1.5,[0,0,-14]),(3.2,[0,0,-8])), 'right_forearm':R((0,[0,0,5]),(.8,[0,0,-3]),(1.1,[0,0,5]),(3.2,[0,0,5]))}
    for n,phase in [('ribbon_base',1),('ribbon_mid',-1),('ribbon_tip',1)]:idle[n]=R((0,[0,0,phase*5]),(1.6,[phase*4,0,-phase*7]),(3.2,[0,0,phase*5]))
    for n in ['eye_left','eye_right']:idle[n]=S((0,[1,1,1]),(2.4,[1,1,1]),(2.48,[1,.08,1]),(2.59,[1,1,1]),(3.2,[1,1,1]))
    walk={'root':P((0,[0,0,0]),(.4,[0,.7,-.3]),(.8,[0,0,0]),(1.2,[0,.7,-.3]),(1.6,[0,0,0])), 'body':R((0,[0,0,-4]),(.8,[0,0,4]),(1.6,[0,0,-4])), 'left_leg':R((0,[16,0,-4]),(.8,[-12,0,2]),(1.6,[16,0,-4])), 'right_leg':R((0,[-12,0,4]),(.8,[16,0,-2]),(1.6,[-12,0,4])), 'head':R((0,[0,4,3]),(.8,[0,-4,-3]),(1.6,[0,4,3]))}
    for n,phase in [('ribbon_base',1),('ribbon_mid',-1),('ribbon_tip',1)]:walk[n]=R((0,[phase*8,0,9]),(.5,[-phase*8,0,-9]),(1,[phase*8,0,6]),(1.6,[phase*8,0,9]))
    attack={'body':R((0,[0,0,0]),(.22,[0,18,6]),(.4,[0,-14,-6]),(.85,[0,0,0])),'right_arm':R((0,[0,0,0]),(.22,[-10,0,-24]),(.35,[-8,0,14]),(.5,[0,0,8]),(.85,[0,0,0])),'right_forearm':R((0,[0,0,0]),(.25,[0,0,-20]),(.36,[0,0,35]),(.5,[0,0,15]),(.85,[0,0,0])),'ribbon_tip':R((0,[0,0,0]),(.22,[0,0,-20]),(.46,[0,0,25]),(.85,[0,0,0]))}
    special={'body':R((0,[0,0,0]),(.35,[0,8,2]),(.9,[0,-8,-3]),(1.6,[0,6,2]),(2.4,[0,0,0])),'head':R((0,[0,0,0]),(.4,[8,0,-4]),(1,[2,0,5]),(1.8,[-4,0,-2]),(2.4,[0,0,0])),'left_arm':R((0,[0,0,0]),(.35,[-22,0,-18]),(.8,[-35,0,-35]),(1.6,[-20,0,-22]),(2.4,[0,0,0])),'right_arm':R((0,[0,0,0]),(.3,[-8,0,18]),(.55,[0,0,5]),(.85,[-5,0,18]),(1.1,[0,0,5]),(1.45,[-8,0,18]),(1.8,[0,0,5]),(2.4,[0,0,0])),'right_forearm':R((0,[0,0,0]),(.4,[0,0,-16]),(.58,[0,0,20]),(.82,[0,0,-10]),(1.06,[0,0,25]),(1.4,[0,0,-16]),(1.65,[0,0,18]),(2.4,[0,0,0]))}
    for i in range(6 if mature else 4):
        n='string_'+str(i);t=.44+i*.13
        special[n]=P((0,[0,0,0]),(t,[0,0,0]),(t+.07,[0,0,.3]),(t+.15,[0,0,-.16]),(t+.26,[0,0,.08]),(t+.38,[0,0,0]),(2.4,[0,0,0]))
    # The right hand supports the harp; the left hand reaches across to pluck.
    special['left_arm']=R((0,[0,0,0]),(.35,[12,0,46]),(.65,[17,0,85]),(1.15,[17,0,86]),(1.65,[16,0,84]),(1.95,[-20,0,-22]),(2.4,[0,0,0]))
    special['left_forearm']=R((0,[0,0,0]),(.35,[6,0,15]),(.55,[1,0,7]),(.76,[3,0,-2]),(.98,[1,0,9]),(1.2,[3,0,-2]),(1.45,[1,0,9]),(1.72,[3,0,-2]),(2.4,[0,0,0]))
    special['right_arm']=R((0,[0,0,0]),(.3,[-6,0,3]),(1.75,[-6,0,3]),(2.4,[0,0,0]))
    special['right_forearm']=R((0,[0,0,0]),(.4,[0,0,-3]),(1.75,[0,0,-3]),(2.4,[0,0,0]))
    special['harp']=P((0,[0,0,0]),(.35,[-2,0,-1]),(1.75,[-2,0,-1]),(2.4,[0,0,0]))
    for i,n in enumerate(['ribbon_base','ribbon_mid','ribbon_tip']):
        offset=i*.16
        special[n]=R((0,[0,0,0]),(.4+offset,[0,12,18]),(.85+offset,[6,-18,-22]),(1.3+offset,[-8,15,24]),(1.8+offset,[0,-8,-12]),(2.4,[0,0,0]))
    hurt={'body':R((0,[0,0,0]),(.12,[-10,-12,8]),(.32,[3,4,-3]),(.65,[0,0,0])),'head':R((0,[0,0,0]),(.12,[-12,0,-10]),(.65,[0,0,0])),'harp':R((0,[0,0,0]),(.16,[0,0,18]),(.32,[0,0,-5]),(.65,[0,0,0]))}
    faint={'root':P((0,[0,0,0]),(.3,[0,-.7,0]),(.8,[0,-2,0]),(1.6,[0,-2,0])),'body':R((0,[0,0,0]),(.5,[0,0,-12]),(1,[0,0,-23]),(1.6,[0,0,-23])),'head':R((0,[0,0,0]),(.7,[25,0,5]),(1.6,[25,0,5])),'core':S((0,[1,1,1]),(.8,[.55,.55,.55]),(1.6,[.55,.55,.55]))}
    for n in ['eye_left','eye_right']:faint[n]=S((0,[1,1,1]),(.4,[1,.08,1]),(1.6,[1,.08,1]))
    m.animations={'idle':clip(3.2,True,idle),'walk':clip(1.6,True,walk),'attack':clip(.85,False,attack),'special':clip(2.4,False,special),'hurt':clip(.65,False,hurt),'faint':clip(1.6,False,faint)}
    if not mature:
        for a in m.animations.values():
            a['animation_length']=round(a['animation_length']*.82,4)
            for tracks in a['bones'].values():
                for channel,frames in list(tracks.items()):
                    tracks[channel]={str(round(float(t)*.82,4)):[round(v*(.72 if channel=='position' else 1),5) for v in vec] for t,vec in frames.items()}
