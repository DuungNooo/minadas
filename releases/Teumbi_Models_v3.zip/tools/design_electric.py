"""An original, soft cloud-and-static creature, not a suit of armour.

The pale head and cloud body are living masses.  The single exposed heart and
the lightning-rod tail preserve the floating-core family identity.
"""


def build(m, stage):
    final = stage == 3
    shoulder = 22.4 if final else 12.3
    head_y = 25.0 if final else 14.3
    chest = 19.1 if final else 10.8
    hip = 12.5 if final else 5.8
    m.bone('body', (0, hip, 0))
    m.bone('core', (0, chest, -.6), 'body')
    m.bone('head', (0, head_y, 0), 'body')
    m.bone('left_arm', (-3.8 if final else -3.1, shoulder, 0), 'body', (0, 0, -12))
    m.bone('right_arm', (3.8 if final else 3.1, shoulder, 0), 'body', (0, 0, 18))
    m.bone('left_forearm', (-4.7 if final else -3.8, shoulder-3.5 if final else shoulder-2, -.1), 'left_arm')
    m.bone('right_forearm', (4.7 if final else 3.8, shoulder-3.5 if final else shoulder-2, -.1), 'right_arm')
    m.bone('left_leg', (-1.8 if final else -1.55, 6 if final else 3.8, .3), 'body')
    m.bone('right_leg', (1.8 if final else 1.55, 6 if final else 3.8, .3), 'body')
    m.bone('conductor', (3.2 if final else 2.8, 15 if final else 8, 2.7), 'body', (0, 0, -5))
    m.bone('antenna_left', (-3.7 if final else -3.3, head_y+4, .1), 'head')
    m.bone('antenna_right', (3.7 if final else 3.3, head_y+4, .1), 'head')
    eye_y = head_y+2.25
    m.bone('eye_left', (-2.0 if final else -1.85, eye_y, -3.2 if final else -2.8), 'head')
    m.bone('eye_right', (2.0 if final else 1.85, eye_y, -3.2 if final else -2.8), 'head')

    def B(n, p, s, mat='stone', bone='body', r=(0, 0, 0), pivot=None):
        m.box(n, p, s, mat, bone, r, pivot)

    # A continuous rounded cloud bell, narrowed toward the exposed heart.
    # Three interlocking stepped masses suggest curves without mesh smoothing.
    if final:
        B('cloud_bell', (-4.7, 6.2, -2.4), (9.4, 5.7, 5.3), 'stone')
        B('cloud_bell_lower', (-3.7, 4.9, -1.8), (7.4, 2.1, 4.3), 'stone')
        B('cloud_waist', (-2.6, 11.2, -1.5), (5.2, 3.9, 3.5), 'light')
        for side in [-1, 1]:
            B('soft_cloud_lobe', (side*4.35-1.35, 7.4, -.9), (2.7, 3.5, 3.3), 'stone', r=(0,0,-side*12))
            B('cloud_tip', (side*5.1-.75, 5.9, .1), (1.5, 2.3, 2.6), 'light', r=(0,0,-side*18))
        B('cloud_shadow_tail', (-1.55, 6, 2.3), (3.1, 7.6, 1.5), 'dark', r=(12,0,0))
        B('crescent_waist_mark', (-1.7, 12.1, -1.85), (3.4, .65, .35), 'accent')
        # Curved shoulders are grown into the trunk; they are not armour.
        B('throat', (-1.7, 23.2, -1.1), (3.4, 2.9, 2.7), 'light')
        B('upper_chest', (-3.65, 22.15, -1.45), (7.3, 1.9, 3.3), 'light')
        B('spine', (-1.15, 14.6, 1.25), (2.3, 8.1, 1.5), 'dark')
        for side in [-1, 1]:
            B('breast_curve', (side*2.6-.7, 17.7, -.7), (1.4, 4.8, 2.5), 'light', r=(0,0,side*17))
        B('heart', (-1.8, chest-1.7, -2.4), (3.6, 3.4, 3.6), 'glow', 'core', (0,0,12))
        B('heart_spark', (-.65, chest-.6, -2.61), (1.3, 1.25, .25), 'eye', 'core')
    else:
        B('cloud_belly', (-3.3, 4.1, -1.95), (6.6, 3.8, 4.3), 'stone')
        B('cloud_lower', (-2.5, 3.2, -1.4), (5, 1.8, 3.5), 'stone')
        B('cloud_waist', (-2, 7.1, -1.3), (4, 1.7, 2.9), 'light')
        for side in [-1, 1]:
            B('baby_cloud_lobe', (side*3-.8, 4.2, -.7), (1.6, 2.7, 2.8), 'light', r=(0,0,-side*14))
            B('small_chest_curve', (side*2-.55, 9.1, -.6), (1.1, 3.2, 2.1), 'light', r=(0,0,side*12))
        B('throat', (-1.35, 12.65, -.85), (2.7, 2.1, 2.2), 'light')
        B('back', (-1.1, 8.4, .9), (2.2, 4.7, 1.2), 'dark')
        B('heart', (-1.25, chest-1.2, -1.8), (2.5, 2.4, 2.5), 'glow', 'core', (0,0,-10))
        B('heart_spark', (-.45, chest-.35, -1.99), (.9, .85, .22), 'eye', 'core')

    # Large pale living face.  Dark pupils and a tiny mouth replace the V2 visor.
    half = 4.5 if final else 4.1
    depth = 5.7 if final else 5.0
    front = -3.0 if final else -2.6
    B('head_center', (-half, head_y+.6, front+.35), (half*2, 4.3, depth-.7), 'light', 'head')
    B('head_top', (-half+.9, head_y+4.8, front+1.05), (half*2-1.8, 1.35, depth-2), 'light', 'head')
    B('chin', (-half+1.0, head_y-.15, front+.65), (half*2-2, 1.3, depth-1.3), 'light', 'head')
    for side, name in [(-1,'left'), (1,'right')]:
        # Cheek tufts point sideways and soften the head's square outline.
        B(name+'_cheek', (side*(half-.15)-.8, head_y+.9, front+.75), (1.6, 2.7, depth-1.5), 'stone', 'head', (0,0,-side*13))
        ex=side*(2 if final else 1.85)
        en='eye_'+name
        B(name+'_eye_outline', (ex-1.05, eye_y-1, front-.08), (2.1, 2.25, .3), 'dark', en)
        B(name+'_eye_white', (ex-.88, eye_y-.8, front-.31), (1.76, 1.85, .26), 'eye', en)
        # Pupils sit slightly inward, giving the pair a curious friendly gaze.
        px=ex-side*.2
        B(name+'_pupil', (px-.43, eye_y-.6, front-.51), (.86, 1.45, .22), 'pupil', en)
        B(name+'_eye_shine', (px-.35, eye_y+.25, front-.64), (.3, .38, .16), 'eye', en)
        B(name+'_cheek_spark', (side*3.35-.5, head_y+.65, front+.12), (1, .55, .25), 'blush', 'head', (0,0,-side*16))
    B('little_mouth', (-.45, head_y+.75, front-.13), (.9, .28, .23), 'mouth', 'head')
    B('nose', (-.3, head_y+1.4, front-.15), (.6, .5, .35), 'stone', 'head')
    # One swept lightning forelock is an immediate recognisable silhouette.
    B('forelock_root', (-1.6, head_y+5.5, -.5), (2.6, 1.55, 2), 'accent', 'head', (0,0,-14))
    B('forelock_sweep', (-.6, head_y+6.3, -.15), (3.8 if final else 2.8, 1.3, 1.5), 'accent', 'head', (0,0,24))
    if final:
        B('forelock_tip', (1.9, head_y+7.3, .2), (2.7, .9, 1.2), 'accent', 'head', (0,0,30))
    # Independent lightning ears twitch and drag behind head motion.
    for side, name in [(-1,'left'), (1,'right')]:
        an='antenna_'+name
        x=side*(4.1 if final else 3.65)
        B(name+'_ear_base', (x-.6, head_y+3.2, .1), (1.2, 2.8 if final else 2.2, 1.8), 'accent', an, (0,0,-side*28))
        B(name+'_ear_zig', (x+side*.85-.5, head_y+5.1, .45), (1, 2.25 if final else 1.7, 1.3), 'light', an, (0,0,side*18))

    # Soft tapered arms and paws.  No mechanical joints or gauntlet borders.
    for side, name in [(-1,'left'), (1,'right')]:
        x=side*(3.8 if final else 3.1)
        arm=name+'_arm';fore=name+'_forearm';leg=name+'_leg'
        B(name+'_upper_arm', (x-.95, shoulder-(3.5 if final else 2.0), -.9), (1.9, 3.9 if final else 2.6, 2.2), 'stone', arm, (0,0,side*8))
        fx=side*(4.7 if final else 3.8)
        B(name+'_soft_forearm', (fx-.85, shoulder-(6.4 if final else 3.9), -.95), (1.7, 3.1 if final else 2, 2), 'light', fore, (0,0,side*7))
        B(name+'_paw', (fx-1.05, shoulder-(7.0 if final else 4.45), -1.3), (2.1, 1.4 if final else 1.1, 2.6), 'light', fore)
        B(name+'_paw_spark', (fx-.3, shoulder-(6.85 if final else 4.3), -1.53), (.6, .6, .25), 'accent', fore)
        lx=side*(1.8 if final else 1.55)
        B(name+'_little_leg', (lx-.7, 2.5 if final else 1.4, -.1), (1.4, 3.5 if final else 2.2, 1.8), 'dark', leg)
        B(name+'_rounded_foot', (lx-1.05, 1.1 if final else .45, -1.2), (2.1, 1.5 if final else 1.1, 3), 'stone', leg)
        B(name+'_toe', (lx-.75, 1.0 if final else .35, -1.7), (1.5, .75, .8), 'light', leg)

    # A lightning-rod tail grows from the back and remains attached to it.
    cx=5.4 if final else 4.45
    low=8.5 if final else 5.3
    top=32.6 if final else 20.1
    B('tail_root', (1.4, low+1, 2), (cx-1.2, 1.25, 1.35), 'dark', 'conductor', (0,0,-12))
    B('conductor_stem', (cx-.42, low+1, 2.4), (.84, top-low-1, .95), 'accent', 'conductor')
    B('conductor_dark_flank', (cx+.3, low+1, 2.65), (.35, top-low-1, .7), 'dark', 'conductor')
    B('bolt_lower', (cx-1.4, top-1, 2.1), (2.7, 1.2, 1.55), 'accent', 'conductor', (0,0,25))
    B('bolt_middle', (cx-1.1, top+.2, 2.1), (1.2, 2.3, 1.55), 'accent', 'conductor', (0,0,-18))
    B('bolt_tip', (cx-2, top+1.9, 2.25), (2.25, .95, 1.25), 'light', 'conductor', (0,0,28))


def animate(m):
    """Six storm-spirit clips: fidget, prance, pulse, collect/discharge, hit, wilt."""
    final = m.stage == 3
    length = 4.6 if final else 3.8
    pulse = .8 if final else 1.15
    def frames(*pairs): return {str(t):v for t,v in pairs}
    def clip(loop, duration, bones):return {'loop':loop,'animation_length':duration,'bones':bones}
    idle={
      'body':{'position':frames((0,[0,0,0]),(.9,[0,.25,0]),(1.8,[0,0,0]),(2.9,[0,.18,0]),(length,[0,0,0])),
              'rotation':frames((0,[0,0,0]),(1.2,[0,-3,-1]),(2.5,[0,3,1]),(length,[0,0,0]))},
      'head':{'rotation':frames((0,[0,0,0]),(.7,[-2,-9,-5]),(1.2,[-2,-9,-5]),(1.55,[0,0,0]),(2.65,[2,6,3]),(3.1,[2,6,3]),(length,[0,0,0]))},
      'core':{'scale':frames((0,[1,1,1]),(.4,[1.05,1.05,1.05]),(.6,[1,1,1]),(2.3,[1.04,1.04,1.04]),(2.5,[1,1,1]),(length,[1,1,1])),
              'position':frames((0,[0,0,0]),(1.1,[0,.3,0]),(2.4,[0,-.12,0]),(length,[0,0,0]))},
      'antenna_left':{'rotation':frames((0,[0,0,0]),(.6,[0,0,-4]),(.72,[0,0,13]),(.87,[0,0,-8]),(1.02,[0,0,0]),(length,[0,0,0]))},
      'antenna_right':{'rotation':frames((0,[0,0,0]),(1.8,[0,0,0]),(1.94,[0,0,-15]),(2.08,[0,0,6]),(2.24,[0,0,0]),(length,[0,0,0]))},
      'left_forearm':{'rotation':frames((0,[0,0,0]),(1.9,[-15,12,-12]),(2.25,[-20,4,-8]),(2.5,[-14,15,-11]),(2.9,[0,0,0]),(length,[0,0,0]))},
      'right_forearm':{'rotation':frames((0,[0,0,0]),(.75,[-8,-8,6]),(1.2,[-8,8,6]),(1.55,[0,0,0]),(length,[0,0,0]))},
      'conductor':{'rotation':frames((0,[0,0,0]),(1.2,[2,0,3]),(2.5,[-2,0,-2]),(length,[0,0,0]))},
    }
    for n in ['eye_left','eye_right']:
        idle[n]={'scale':frames((0,[1,1,1]),(1.65,[1,1,1]),(1.7,[1,.08,1]),(1.8,[1,.08,1]),(1.87,[1,1,1]),(length,[1,1,1]))}
    duration=1.25 if final else .92
    walk={
      'root':{'position':frames((0,[0,0,0]),(.18*duration,[0,.6*pulse,0]),(.43*duration,[0,.1,0]),(.7*duration,[0,.8*pulse,0]),(duration,[0,0,0]))},
      'body':{'rotation':frames((0,[0,-4,-3]),(.25*duration,[-3,2,0]),(.5*duration,[0,4,3]),(.75*duration,[-3,-2,0]),(duration,[0,-4,-3]))},
      'head':{'rotation':frames((0,[2,3,2]),(.3*duration,[-3,-4,-1]),(.6*duration,[2,-3,-2]),(duration,[2,3,2]))},
      'left_leg':{'rotation':frames((0,[-22,0,-4]),(.3*duration,[18,0,2]),(.55*duration,[5,0,1]),(.8*duration,[-10,0,-3]),(duration,[-22,0,-4]))},
      'right_leg':{'rotation':frames((0,[12,0,2]),(.2*duration,[-12,0,3]),(.55*duration,[-24,0,4]),(.8*duration,[18,0,-2]),(duration,[12,0,2]))},
      'left_arm':{'rotation':frames((0,[-5,0,-4]),(.35*duration,[10,0,6]),(.75*duration,[-8,0,-5]),(duration,[-5,0,-4]))},
      'right_arm':{'rotation':frames((0,[8,0,5]),(.45*duration,[-12,0,-5]),(.8*duration,[6,0,3]),(duration,[8,0,5]))},
      'conductor':{'rotation':frames((0,[0,0,3]),(.3*duration,[-5,0,-4]),(.65*duration,[4,0,5]),(duration,[0,0,3]))},
      'antenna_left':{'rotation':frames((0,[0,0,-3]),(.3*duration,[0,0,8]),(.7*duration,[0,0,-8]),(duration,[0,0,-3]))},
      'antenna_right':{'rotation':frames((0,[0,0,4]),(.2*duration,[0,0,-9]),(.65*duration,[0,0,7]),(duration,[0,0,4]))},
    }
    a=1.55 if final else 1.16
    attack={
      'body':{'position':frames((0,[0,0,0]),(.25*a,[0,-.7,.25]),(.47*a,[0,-.85,.4]),(.54*a,[0,.2,-.6]),(.68*a,[0,.35,.15]),(a,[0,0,0])),
              'rotation':frames((0,[0,0,0]),(.4*a,[5,-12,0]),(.55*a,[-8,9,0]),(.75*a,[3,-3,0]),(a,[0,0,0]))},
      'head':{'rotation':frames((0,[0,0,0]),(.4*a,[4,-8,-3]),(.55*a,[-5,8,0]),(.8*a,[2,-2,0]),(a,[0,0,0]))},
      'left_arm':{'rotation':frames((0,[0,0,0]),(.32*a,[-28,0,-28]),(.48*a,[-34,0,-30]),(.55*a,[-48,12,6]),(.73*a,[-27,0,-9]),(a,[0,0,0]))},
      'right_arm':{'rotation':frames((0,[0,0,0]),(.32*a,[-30,0,30]),(.48*a,[-36,0,33]),(.55*a,[-78,-8,-12]),(.72*a,[-45,4,4]),(a,[0,0,0]))},
      'right_forearm':{'rotation':frames((0,[0,0,0]),(.4*a,[-55,0,-15]),(.55*a,[12,0,0]),(.7*a,[-8,0,4]),(a,[0,0,0]))},
      'left_forearm':{'rotation':frames((0,[0,0,0]),(.4*a,[-52,0,15]),(.55*a,[-15,0,0]),(a,[0,0,0]))},
      'conductor':{'rotation':frames((0,[0,0,0]),(.46*a,[8,0,-5]),(.57*a,[-14,0,8]),(.72*a,[6,0,-3]),(a,[0,0,0]))},
      'core':{'scale':frames((0,[1,1,1]),(.43*a,[1.25,1.25,1.25]),(.55*a,[.75,.75,.75]),(.7*a,[1.1,1.1,1.1]),(a,[1,1,1]))},
    }
    d=2.8 if final else 2.15
    special={
      'root':{'position':frames((0,[0,0,0]),(.2*d,[0,-.8,0]),(.42*d,[0,1.3,0]),(.56*d,[0,1.5,0]),(.61*d,[0,.3,0]),(.75*d,[0,.8,0]),(d,[0,0,0]))},
      'body':{'rotation':frames((0,[0,0,0]),(.2*d,[8,0,0]),(.42*d,[-12,0,0]),(.56*d,[-18,0,0]),(.62*d,[11,0,0]),(.72*d,[-5,0,0]),(d,[0,0,0]))},
      'head':{'rotation':frames((0,[0,0,0]),(.2*d,[12,0,0]),(.42*d,[-24,0,0]),(.58*d,[-20,0,0]),(.64*d,[8,0,0]),(d,[0,0,0]))},
      'left_arm':{'rotation':frames((0,[0,0,0]),(.2*d,[-20,0,-25]),(.43*d,[-65,0,-55]),(.57*d,[-80,0,-45]),(.64*d,[-25,0,12]),(.78*d,[-12,0,-8]),(d,[0,0,0]))},
      'right_arm':{'rotation':frames((0,[0,0,0]),(.2*d,[-20,0,25]),(.43*d,[-65,0,55]),(.57*d,[-80,0,45]),(.64*d,[-25,0,-12]),(.78*d,[-12,0,8]),(d,[0,0,0]))},
      'conductor':{'rotation':frames((0,[0,0,0]),(.2*d,[7,0,9]),(.4*d,[-12,0,-12]),(.55*d,[-20,0,-8]),(.6*d,[16,0,12]),(.68*d,[-9,0,-6]),(.78*d,[4,0,3]),(d,[0,0,0]))},
      'antenna_left':{'rotation':frames((0,[0,0,0]),(.2*d,[0,0,12]),(.43*d,[0,0,-28]),(.58*d,[0,0,-28]),(.62*d,[0,0,20]),(.73*d,[0,0,-8]),(d,[0,0,0]))},
      'antenna_right':{'rotation':frames((0,[0,0,0]),(.2*d,[0,0,-12]),(.43*d,[0,0,28]),(.58*d,[0,0,28]),(.62*d,[0,0,-20]),(.73*d,[0,0,8]),(d,[0,0,0]))},
      'core':{'scale':frames((0,[1,1,1]),(.3*d,[1.15,1.15,1.15]),(.5*d,[1.4,1.4,1.4]),(.61*d,[.65,.65,.65]),(.72*d,[1.15,1.15,1.15]),(d,[1,1,1]))},
    }
    hurt={
      'body':{'rotation':frames((0,[0,0,0]),(.09,[-13,9,-7]),(.2,[-8,-6,5]),(.38,[3,2,-2]),(.7,[0,0,0])),
              'position':frames((0,[0,0,0]),(.09,[0,.3,1]),(.2,[0,0,.6]),(.7,[0,0,0]))},
      'head':{'rotation':frames((0,[0,0,0]),(.1,[-15,12,8]),(.28,[4,-7,-4]),(.7,[0,0,0]))},
      'conductor':{'rotation':frames((0,[0,0,0]),(.15,[15,0,-15]),(.3,[-10,0,7]),(.5,[4,0,-3]),(.7,[0,0,0]))},
      'eye_left':{'scale':frames((0,[1,1,1]),(.08,[1,.12,1]),(.25,[1,.12,1]),(.38,[1,1,1]),(.7,[1,1,1]))},
      'eye_right':{'scale':frames((0,[1,1,1]),(.08,[1,.12,1]),(.25,[1,.12,1]),(.38,[1,1,1]),(.7,[1,1,1]))},
    }
    faint={
      'root':{'position':frames((0,[0,0,0]),(.45,[0,-.8,0]),(1.1,[0,-2.2,0]),(1.7,[0,-2.2,0]))},
      'body':{'rotation':frames((0,[0,0,0]),(.45,[6,0,-7]),(.85,[17,0,-13]),(1.7,[17,0,-13]))},
      'head':{'rotation':frames((0,[0,0,0]),(.5,[12,0,4]),(1.2,[25,0,9]),(1.7,[25,0,9]))},
      'left_arm':{'rotation':frames((0,[0,0,0]),(.65,[8,0,8]),(1.7,[8,0,8]))},
      'right_arm':{'rotation':frames((0,[0,0,0]),(.65,[12,0,-12]),(1.7,[12,0,-12]))},
      'conductor':{'rotation':frames((0,[0,0,0]),(.7,[5,0,18]),(1.2,[8,0,24]),(1.7,[8,0,24]))},
      'antenna_left':{'rotation':frames((0,[0,0,0]),(.8,[0,0,35]),(1.7,[0,0,35]))},
      'antenna_right':{'rotation':frames((0,[0,0,0]),(.8,[0,0,-30]),(1.7,[0,0,-30]))},
      'eye_left':{'scale':frames((0,[1,1,1]),(.7,[1,.1,1]),(1.7,[1,.1,1]))},
      'eye_right':{'scale':frames((0,[1,1,1]),(.7,[1,.1,1]),(1.7,[1,.1,1]))},
      'core':{'scale':frames((0,[1,1,1]),(.6,[.9,.9,.9]),(1.7,[.82,.82,.82]))},
    }
    m.animations={
      'idle':clip(True,length,idle),'walk':clip(True,duration,walk),
      'attack':clip(False,a,attack),'special':clip(False,d,special),
      'hurt':clip(False,.7,hurt),'faint':clip(False,1.7,faint),
    }
