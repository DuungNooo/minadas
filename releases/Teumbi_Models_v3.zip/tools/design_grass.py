"""Seed-hearted woodland creatures: an acorn sprout and a leaf-palm guardian.

Broad faces, soft stepped masses and actual leaf-shaped hands replace the old
armoured cabinet silhouette.  The palms are apart in the rest pose and meet
only during the dedicated protection action.
"""


def build(m, stage):
    young = stage == 2
    # Stage-specific dimensions, not a uniform scale of the adult.
    hip = 6.0 if young else 7.0
    chest = 10.1 if young else 14.0
    neck = 13.0 if young else 19.0
    face = 15.6 if young else 22.7
    armx = 4.4 if young else 6.0
    army = 11.9 if young else 17.0
    elbowx = 5.2 if young else 7.3
    elbowy = 8.4 if young else 11.8
    legx = 1.9 if young else 2.6

    m.bone('body', (0, hip, 0))
    m.bone('core', (0, chest, -.2), 'body')
    m.bone('head', (0, neck, 0), 'body')
    m.bone('canopy', (-.5, face + (3.1 if young else 4.0), .2), 'head')
    for side, sign in [('left', -1), ('right', 1)]:
        m.bone(side + '_arm', (sign * armx, army, 0), 'body')
        m.bone(side + '_forearm', (sign * elbowx, elbowy, -.7), side + '_arm')
        # Legs belong to root so crouching the trunk does not bury both feet.
        m.bone(side + '_leg', (sign * legx, hip + .8, 0), 'root')
        eye_x = sign * (1.7 if young else 2.15)
        eye_y = face + (.1 if young else .15)
        eye_z = -2.58 if young else -3.36
        m.bone(side + '_eye', (eye_x, eye_y, eye_z), 'head')

    def b(n, p, size, mat='stone', bone='body', rot=(0, 0, 0), pivot=None):
        m.box(n, p, size, material=mat, bone=bone, rotation=rot, pivot=pivot)

    if young:
        # A plump acorn belly is separated from the upper seed shell by the
        # exposed heart.  There is no belt, collar, armour plate or neck post.
        b('round_belly_middle', (-3.6, 5.4, -2.1), (7.2, 2.5, 4.4), 'wood')
        b('round_belly_lower', (-2.8, 4.5, -1.7), (5.6, 1.1, 3.6), 'wood')
        b('belly_cream_spot', (-1.9, 5.6, -2.26), (3.8, 1.7, .28), 'light')
        b('back_acorn', (-2.8, 8.0, 1.5), (5.6, 4.8, 1.4), 'stone')
        b('back_leaf_lip', (-3.0, 11.5, 1.3), (6.0, 1.0, 1.8), 'leaf')
        b('upper_seed_shell', (-3.2, 12.1, -1.9), (6.4, 1.6, 4.0), 'stone')
        for s in [-1, 1]:
            b('rounded_chest_side', (s * 3.1 - .65, 8.2, -1.2), (1.3, 3.9, 3), 'stone', rot=(0, 0, -s * 12))
        b('single_seed_heart', (-1.05, 9.05, -1.15), (2.1, 2.1, 2.1), 'glow', 'core', (0, 0, 10))
        b('heart_seed_mark', (-.25, 9.5, -1.27), (.5, 1.2, .16), 'light', 'core')

        # Big soft head; its cream muzzle is contiguous with the face, so it
        # reads as a creature rather than lights inside a mechanical helmet.
        b('acorn_head_center', (-3.7, 13.6, -2.2), (7.4, 4.8, 4.8), 'stone', 'head')
        b('acorn_head_crown', (-2.9, 18.3, -1.75), (5.8, .8, 3.9), 'leaf', 'head')
        b('acorn_head_cheeks', (-3.2, 13.1, -2.0), (6.4, 1.3, 4.3), 'stone', 'head')
        b('soft_cream_face', (-2.9, 14.0, -2.46), (5.8, 3.3, .4), 'light', 'head')
        b('little_muzzle', (-1.35, 13.7, -2.7), (2.7, 1.5, .7), 'light', 'head')
        b('small_nose', (-.3, 14.6, -3.06), (.6, .4, .22), 'wood', 'head')
        b('smile_left', (-.75, 14.0, -3.04), (.65, .18, .16), 'mouth', 'head', (0, 0, -9))
        b('smile_right', (.1, 14.0, -3.04), (.65, .18, .16), 'mouth', 'head', (0, 0, 9))
        for side, s in [('left', -1), ('right', 1)]:
            eye = side + '_eye'; x = s * 1.7
            b(side + '_eye_white', (x - .72, face - .73, -2.68), (1.44, 1.85, .22), 'light', eye)
            b(side + '_iris', (x - .39, face - .6, -2.84), (.78, 1.5, .18), 'pupil', eye)
            b(side + '_eye_shine', (x - .27, face + .4, -3.02), (.36, .38, .14), 'eye', eye)
            b(side + '_rosy_cheek', (s * 2.55 - .42, 14.8, -2.72), (.84, .42, .15), 'blush', 'head')
            b(side + '_ear_bud', (s * 3.7 - .65, 16.1, -.2), (1.3, 1.6, 2.0), 'leaf', 'head', (0, 0, -s * 20))
        b('sprout_stem', (-.5, 18.6, .25), (.65, 1.8, .65), 'wood', 'canopy', (0, 0, -12))
        b('sprout_large_leaf', (-2.4, 19.8, -.2), (2.6, .65, 1.4), 'leaf', 'canopy', (0, 0, -18))
        b('sprout_leaf_point', (-2.8, 20.2, .0), (.8, .45, 1.0), 'leaf', 'canopy')
        b('sprout_small_leaf', (.0, 19.5, .15), (1.9, .6, 1.3), 'accent', 'canopy', (0, 0, 15))
    else:
        # The adult keeps the seed shape but has a broad, low centre of mass.
        b('seed_belly', (-4.8, 6.8, -2.5), (9.6, 3.7, 5.6), 'wood')
        b('seed_belly_lower', (-3.8, 5.5, -2.15), (7.6, 1.6, 4.8), 'wood')
        b('belly_light_oval', (-2.8, 7.2, -2.68), (5.6, 2.3, .3), 'light')
        b('lower_leaf_tuft', (-2.0, 9.3, -2.9), (4.0, 1.6, .65), 'leaf', rot=(0, 0, -5))
        b('living_back_trunk', (-3.6, 10.3, 2.0), (7.2, 7.0, 1.9), 'wood')
        b('back_moss_cap', (-4.0, 16.0, 1.7), (8.0, 1.6, 2.4), 'leaf')
        b('upper_chest_seed', (-4.8, 17.1, -2.0), (9.6, 2.0, 4.8), 'stone')
        b('upper_chest_rounding', (-3.9, 18.9, -1.7), (7.8, 1.0, 4.0), 'stone')
        for s in [-1, 1]:
            b('trunk_side', (s * 4.1 - .8, 10.5, -1.5), (1.6, 6.4, 3.8), 'stone', rot=(0, 0, -s * 10))
            b('side_leaf_growth', (s * 4.6 - .65, 14.4, -.7), (1.3, 2.0, 2.7), 'leaf', rot=(0, 0, s * 18))
        b('single_seed_heart', (-1.6, 12.4, -1.65), (3.2, 3.2, 3.2), 'glow', 'core', (0, 0, 8))
        b('heart_seed_line', (-.3, 13.0, -1.8), (.6, 2.0, .2), 'light', 'core')

        # A welcoming old-tree face, with a short muzzle and uneven brow tufts.
        b('head_seed_center', (-4.8, 20.0, -2.8), (9.6, 6.1, 6.0), 'stone', 'head')
        b('head_lower_round', (-4.0, 19.3, -2.45), (8.0, 1.5, 5.2), 'stone', 'head')
        b('head_top_round', (-3.9, 26.0, -2.2), (7.8, 1.0, 4.8), 'leaf', 'head')
        b('warm_face', (-3.85, 20.5, -3.03), (7.7, 4.3, .5), 'light', 'head')
        b('short_muzzle', (-1.9, 19.9, -3.25), (3.8, 1.75, 1.0), 'light', 'head')
        b('nose', (-.4, 21.1, -3.79), (.8, .5, .2), 'wood', 'head')
        b('mouth_center', (-.5, 20.5, -3.82), (1, .2, .18), 'mouth', 'head')
        b('mouth_l', (-1.05, 20.65, -3.75), (.55, .2, .16), 'mouth', 'head', (0, 0, -12))
        b('mouth_r', (.5, 20.65, -3.75), (.55, .2, .16), 'mouth', 'head', (0, 0, 12))
        for side, s in [('left', -1), ('right', 1)]:
            eye = side + '_eye'; x = s * 2.15
            b(side + '_eye_white', (x - .9, face - .95, -3.26), (1.8, 2.2, .22), 'light', eye)
            b(side + '_iris', (x - .52, face - .82, -3.43), (1.04, 1.8, .18), 'pupil', eye)
            b(side + '_eye_shine', (x - .38, face + .4, -3.6), (.44, .46, .15), 'eye', eye)
            b(side + '_gentle_brow', (x - 1.1, 24.15, -3.26), (2.2, .7, 1.1), 'stone', 'head', (0, 0, -s * 8))
            b(side + '_cheek_leaf', (s * 4.3 - .65, 20.8, -2.5), (1.3, 1.3, 2.6), 'leaf', 'head', (0, 0, -s * 22))
        # One large angled leaf and a small opposing bud form the family mark.
        b('sprout_branch', (-.9, 26.6, .25), (1.0, 2.4, 1.0), 'wood', 'canopy', (0, 0, -12))
        b('large_canopy_leaf', (-4.2, 28.0, -.8), (4.2, 1.0, 2.6), 'leaf', 'canopy', (0, 0, -14))
        b('large_canopy_tip', (-5.3, 28.75, -.45), (1.5, .7, 1.9), 'leaf', 'canopy', (0, 0, -14))
        b('leaf_mid_vein', (-3.8, 28.8, -.25), (3.1, .23, .4), 'accent', 'canopy', (0, 0, -14))
        b('small_canopy_leaf', (.0, 27.75, .0), (2.8, .85, 2.0), 'accent', 'canopy', (0, 0, 17))

    # Rounded stumpy limbs, not articulated armour.  The feet have two little
    # root toes rather than a shin/knee/boot stack.
    for side, sign in [('left', -1), ('right', 1)]:
        arm = side + '_arm'; hand = side + '_forearm'; leg = side + '_leg'
        ax = sign * armx; ex = sign * elbowx; lx = sign * legx
        if young:
            b(side + '_upper_root', (ax - 1.1, 9.0, -.9), (2.2, 3.5, 2.8), 'wood', arm, (0, 0, -sign * 12))
            b(side + '_palm', (ex - 1.4, 6.8, -1.8), (2.8, 2.5, 3.0), 'wood', hand)
            # The fan is a pointed leaf, not a rectangular shield panel.
            rows = [(6.0, 2.5), (6.8, 3.6), (8.0, 4.6), (9.3, 4.1), (10.5, 2.9), (11.5, 1.4)]
            for j, (y, w) in enumerate(rows):
                b(side + '_leaf_fan_' + str(j), (ex - w / 2, y, -3.0), (w, 1.3, 1.0), 'leaf' if j % 2 else 'accent', hand)
            b(side + '_leaf_vein', (ex - .2, 6.2, -3.18), (.4, 5.7, .24), 'light', hand)
            b(side + '_round_leg', (lx - 1.1, 2.1, -.8), (2.2, 3.6, 2.8), 'stone', leg)
            b(side + '_root_foot', (lx - 1.55, .6, -1.8), (3.1, 1.8, 3.7), 'wood', leg)
            for j in [-1, 1]:b(side + '_root_toe', (lx + j * .66 - .38, .5, -2.1), (.76, .75, 1.0), 'light', leg)
        else:
            b(side + '_upper_root', (ax - 1.4, 12.0, -1.2), (2.8, 5.6, 3.4), 'wood', arm, (0, 0, -sign * 10))
            b(side + '_upper_root_round', (ax - 1.0, 17.1, -.9), (2.0, .8, 2.8), 'stone', arm)
            b(side + '_broad_palm', (ex - 1.9, 8.3, -2.0), (3.8, 3.8, 3.6), 'wood', hand)
            rows = [(6.4, 2.8), (7.5, 4.4), (8.8, 6.0), (10.2, 6.7), (11.7, 6.3), (13.1, 5.0), (14.4, 3.4), (15.6, 1.6)]
            for j, (y, w) in enumerate(rows):
                b(side + '_leaf_fan_' + str(j), (ex - w / 2, y, -3.65), (w, 1.5, 1.4), 'leaf' if j % 3 else 'accent', hand)
            b(side + '_leaf_mid_vein', (ex - .25, 7.0, -3.86), (.5, 9.4, .28), 'light', hand)
            for j in range(2):
                b(side + '_leaf_branch_' + str(j), (ex - 1.6, 10.4 + j * 2.2, -3.94), (3.2, .28, .25), 'accent', hand, (0, 0, sign * 12))
            b(side + '_round_leg', (lx - 1.45, 2.6, -1.1), (2.9, 4.4, 3.4), 'stone', leg)
            b(side + '_root_foot', (lx - 1.9, .7, -2.1), (3.8, 2.2, 4.4), 'wood', leg)
            for j in [-1, 1]:b(side + '_root_toe', (lx + j * .8 - .48, .55, -2.5), (.96, .9, 1.2), 'light', leg)


def animate(m):
    """Woodland-specific pauses, weight shifts and real closing leaf palms."""
    young = m.stage == 2
    pace = .82 if young else 1.0
    pulse = 1.18 if young else 1.0

    def track(points):
        return {str(round(t * pace, 4)): list(v) for t, v in points}

    def ch(**channels):
        return {name: track(points) for name, points in channels.items()}

    def clip(length, bones, loop=False):
        return {'loop': loop, 'animation_length': round(length * pace, 4), 'bones': bones}

    blink = ch(scale=[(0, (1, 1, 1)), (1.12, (1, 1, 1)), (1.2, (1, .08, 1)), (1.31, (1, 1, 1)), (3.2, (1, 1, 1))])
    idle = {
        'body': ch(scale=[(0, (1, 1, 1)), (.9, (1.016, 1.025, 1.016)), (1.8, (1, 1, 1)), (3.2, (1, 1, 1))]),
        'head': ch(rotation=[(0, (0, -3, -2)), (.8, (2, 3, 1)), (1.8, (0, 4, 2)), (2.8, (-1, -3, -2)), (3.2, (0, -3, -2))]),
        'canopy': ch(rotation=[(0, (0, 0, -4)), (.65, (0, 0, 5)), (1.25, (0, 0, -3)), (1.9, (0, 0, 3)), (3.2, (0, 0, -4))]),
        'core': ch(position=[(0, (0, 0, 0)), (1.0, (0, .18, -.05)), (2.1, (0, -.08, .04)), (3.2, (0, 0, 0))], rotation=[(0, (0, -5, 0)), (1.6, (0, 5, 0)), (3.2, (0, -5, 0))]),
        'left_forearm': ch(rotation=[(0, (0, 0, -3)), (1.6, (0, 0, 1)), (3.2, (0, 0, -3))]),
        'right_forearm': ch(rotation=[(0, (0, 0, 1)), (1.6, (0, 0, -2)), (3.2, (0, 0, 1))]),
        'left_eye': blink, 'right_eye': blink,
    }

    # Long planted intervals and a pelvis rock make the walk a seed-like
    # waddle.  Its leaf palms trail with a delayed opposing swing.
    walk = {
        'body': ch(rotation=[(0, (0, -3, -4)), (.27, (0, 0, -5)), (.6, (0, 3, 4)), (.87, (0, 0, 5)), (1.2, (0, -3, -4))], position=[(0, (0, 0, 0)), (.22, (0, .25 * pulse, 0)), (.35, (0, -.12, 0)), (.6, (0, 0, 0)), (.82, (0, .25 * pulse, 0)), (.95, (0, -.12, 0)), (1.2, (0, 0, 0))]),
        'head': ch(rotation=[(0, (0, 2, 2)), (.6, (0, -2, -2)), (1.2, (0, 2, 2))]),
        'canopy': ch(rotation=[(0, (0, 0, 4)), (.35, (0, 0, -5)), (.65, (0, 0, -4)), (.95, (0, 0, 5)), (1.2, (0, 0, 4))]),
    }
    for side, sign in [('left', -1), ('right', 1)]:
        walk[side + '_leg'] = ch(rotation=[(0, (sign * 13, 0, sign * 3)), (.35, (-sign * 11, 0, -sign * 2)), (.6, (-sign * 13, 0, -sign * 3)), (.95, (sign * 11, 0, sign * 2)), (1.2, (sign * 13, 0, sign * 3))], position=[(0, (0, 0, 0)), (.2 if sign < 0 else .8, (0, .7, -.3)), (.35 if sign < 0 else .95, (0, 0, 0)), (1.2, (0, 0, 0))])
        walk[side + '_arm'] = ch(rotation=[(0, (-sign * 4, 0, 0)), (.6, (sign * 5, 0, 0)), (1.2, (-sign * 4, 0, 0))])
        walk[side + '_forearm'] = ch(rotation=[(0, (sign * 3, 0, 0)), (.45, (-sign * 4, 0, 0)), (1.05, (sign * 4, 0, 0)), (1.2, (sign * 3, 0, 0))])

    attack = {
        'body': ch(position=[(0, (0, 0, 0)), (.2, (0, -.6, 1.0)), (.38, (.4, -.2, -2.0)), (.48, (.2, 0, -1.2)), (.7, (0, .1, -.3)), (1.0, (0, 0, 0))], rotation=[(0, (0, 0, 0)), (.2, (-4, -6, -3)), (.38, (10, 9, 4)), (.55, (4, 3, 1)), (1.0, (0, 0, 0))]),
        'head': ch(rotation=[(0, (0, 0, 0)), (.2, (-5, -7, 0)), (.38, (10, 7, 0)), (.7, (-2, 0, 0)), (1.0, (0, 0, 0))]),
        'left_arm': ch(rotation=[(0, (0, 0, 0)), (.2, (-10, 0, 8)), (.38, (-36, -8, 22)), (.55, (-26, 0, 15)), (1.0, (0, 0, 0))]),
        'left_forearm': ch(rotation=[(0, (0, 0, 0)), (.2, (0, 0, -5)), (.38, (-10, 0, -22)), (.55, (0, 0, -15)), (1.0, (0, 0, 0))]),
        'canopy': ch(rotation=[(0, (0, 0, 0)), (.22, (-8, 0, -5)), (.42, (14, 0, 8)), (.62, (-6, 0, -4)), (1.0, (0, 0, 0))]),
    }

    # Seven distinct beats: dip -> sweep inward -> lock -> brace/hold ->
    # release -> soft overshoot -> rest.  Upper arms bring the forearms in;
    # counter-rotation keeps the two leaf surfaces facing the opponent.
    special = {
        'body': ch(position=[(0, (0, 0, 0)), (.25, (0, -.9, .2)), (.6, (0, -1.4, 0)), (.85, (0, -1.6, -.25)), (1.7, (0, -1.6, -.25)), (2.05, (0, -.7, .1)), (2.35, (0, .18, 0)), (2.6, (0, 0, 0))], scale=[(0, (1, 1, 1)), (.6, (1.035, .94, 1.025)), (1.7, (1.035, .94, 1.025)), (2.6, (1, 1, 1))]),
        'head': ch(rotation=[(0, (0, 0, 0)), (.4, (7, 0, 0)), (.85, (3, 0, 0)), (1.7, (3, 0, 0)), (2.2, (-3, 0, 0)), (2.6, (0, 0, 0))]),
        'canopy': ch(rotation=[(0, (0, 0, 0)), (.4, (8, 0, 7)), (.75, (-4, 0, -5)), (1.0, (2, 0, 3)), (1.7, (2, 0, 3)), (2.15, (-5, 0, -4)), (2.6, (0, 0, 0))]),
        'core': ch(scale=[(0, (1, 1, 1)), (.6, (1.08, 1.08, 1.08)), (.85, (1.0, 1.0, 1.0)), (1.25, (1.06, 1.06, 1.06)), (1.7, (1.0, 1.0, 1.0)), (2.6, (1, 1, 1))]),
    }
    for side, sign in [('left', -1), ('right', 1)]:
        # Adult leaf palms are 6.7 units broad; juvenile palms are 4.6.
        shift = 2.0
        special[side + '_arm'] = ch(rotation=[(0, (0, 0, 0)), (.25, (0, 0, sign * 4)), (.6, (-4, 0, -sign * 31)), (.85, (-4, 0, -sign * 32)), (1.7, (-4, 0, -sign * 32)), (2.05, (0, 0, -sign * 10)), (2.35, (0, 0, sign * 3)), (2.6, (0, 0, 0))])
        special[side + '_forearm'] = ch(rotation=[(0, (0, 0, 0)), (.25, (0, 0, 0)), (.6, (4, 0, sign * 31)), (.85, (4, 0, sign * 32)), (1.7, (4, 0, sign * 32)), (2.05, (0, 0, sign * 10)), (2.35, (0, 0, -sign * 3)), (2.6, (0, 0, 0))], position=[(0, (0, 0, 0)), (.25, (0, 0, 0)), (.6, (-sign * shift, 1.5, -1.3)), (.85, (-sign * shift, 1.7, -1.6)), (1.7, (-sign * shift, 1.7, -1.6)), (2.05, (-sign * .3, .5, -.3)), (2.35, (0, -.1, 0)), (2.6, (0, 0, 0))])

    hurt_blink = ch(scale=[(0, (1, 1, 1)), (.08, (1, .12, 1)), (.27, (1, .12, 1)), (.43, (1, 1, 1)), (.6, (1, 1, 1))])
    hurt = {
        'body': ch(rotation=[(0, (0, 0, 0)), (.1, (-8, 0, -5)), (.27, (-4, 0, -2)), (.45, (2, 0, 1)), (.6, (0, 0, 0))], position=[(0, (0, 0, 0)), (.1, (.3, 0, .8)), (.3, (.1, -.2, .3)), (.6, (0, 0, 0))]),
        'head': ch(rotation=[(0, (0, 0, 0)), (.1, (-12, 8, -7)), (.3, (-3, 2, -2)), (.6, (0, 0, 0))]),
        'canopy': ch(rotation=[(0, (0, 0, 0)), (.12, (5, 0, 18)), (.3, (-3, 0, -10)), (.45, (0, 0, 4)), (.6, (0, 0, 0))]),
        'left_eye': hurt_blink, 'right_eye': hurt_blink,
    }
    faint = {
        'root': ch(rotation=[(0, (0, 0, 0)), (.45, (-5, 0, 3)), (.9, (-22, 0, 5)), (1.2, (-68, 0, 8)), (1.45, (-62, 0, 8)), (1.7, (-66, 0, 8))], position=[(0, (0, 0, 0)), (.45, (0, 0, 0)), (.9, (0, .2, 0)), (1.2, (0, 2.1, -.5)), (1.7, (0, 1.8, -.5))]),
        'head': ch(rotation=[(0, (0, 0, 0)), (.45, (16, 0, 0)), (1.0, (25, 0, -6)), (1.7, (25, 0, -6))]),
        'canopy': ch(rotation=[(0, (0, 0, 0)), (.7, (18, 0, -8)), (1.25, (28, 0, -12)), (1.7, (25, 0, -12))]),
        'core': ch(scale=[(0, (1, 1, 1)), (.7, (.9, .9, .9)), (1.7, (.78, .78, .78))]),
        'left_eye': ch(scale=[(0, (1, 1, 1)), (.4, (1, .08, 1)), (1.7, (1, .08, 1))]),
        'right_eye': ch(scale=[(0, (1, 1, 1)), (.4, (1, .08, 1)), (1.7, (1, .08, 1))]),
        'left_arm': ch(rotation=[(0, (0, 0, 0)), (.8, (0, 0, -10)), (1.7, (0, 0, -15))]),
        'right_arm': ch(rotation=[(0, (0, 0, 0)), (.8, (0, 0, 8)), (1.7, (0, 0, 13))]),
    }
    m.animations = {
        'idle': clip(3.2, idle, True), 'walk': clip(1.2, walk, True),
        'attack': clip(1.0, attack), 'special': clip(2.6, special),
        'hurt': clip(.6, hurt), 'faint': clip(1.7, faint),
    }
