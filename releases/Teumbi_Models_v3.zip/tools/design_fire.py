"""Living cinder imps; body masses and faces, never a suit of armour."""


def build(m, stage):
    final = stage == 3
    floor = .15
    hip = 12.0 if final else 7.2
    chest = 19.5 if final else 11.8
    head = 27.0 if final else 17.0
    shoulder = 21.2 if final else 13.1
    armx = 7.0 if final else 5.0
    elbow = 15.3 if final else 9.7
    m.bone('body', (0, hip, .3))
    m.bone('core', (0, chest, -.25), 'body')
    m.bone('head', (0, head-3, 0), 'body')
    m.bone('jaw', (0, head-2.6, -2.6), 'head')
    m.bone('mane', (0, head, 2), 'head')
    for sign, side in [(-1,'left'), (1,'right')]:
        m.bone(side+'_arm', (sign*armx, shoulder, .15), 'body', (0,0,sign*7))
        m.bone(side+'_forearm', (sign*armx, elbow, -.1), side+'_arm')
        m.bone(side+'_leg', (sign*(2.8 if final else 2.1), hip-.6, .2), 'body')
    m.bone('tail', (0, hip+1, 2), 'body')

    def b(n,p,s,mat='stone',bone='body',r=(0,0,0),pivot=None):
        m.box(n,p,s,mat,bone,r,pivot)

    # Rounded, low belly; the open chest is bounded by living coal ribs.
    bellyw = 4.1 if final else 3.5
    bellyy = 10.4 if final else 6.3
    b('warm_belly',(-bellyw,bellyy,-2.1),(bellyw*2,4.1 if final else 2.8,4.9),'accent')
    b('belly_underside',(-bellyw+.7,bellyy-.8,-1.45),(bellyw*2-1.4,1.1,3.6),'stone')
    b('warm_back',(-3.8 if final else -3.1,bellyy+3.0,1.6),(7.6 if final else 6.2,7.0 if final else 4.4,2.1),'stone')
    for sign in [-1,1]:
        x=sign*(4.4 if final else 3.5)
        b('coal_rib_'+str(sign),(x-.9,chest-2.4,-1.8),(1.8,5.0 if final else 3.4,3.5),'stone',r=(0,0,sign*13))
        b('rib_shoulder_'+str(sign),(x-1.25,chest+2,-1.5),(2.5,1.9,3.2),'accent',r=(0,0,-sign*10))
    b('neck',(-2.1,head-5.5,-1.2),(4.2,2.8,3.1),'stone')
    heart=3.2 if final else 2.5
    b('single_ember_heart',(-heart/2,chest-heart/2,-heart/2-.5),(heart,heart,heart),'glow','core',(0,12,0))
    # One inner hot spot is surface detail on that single heart, not another core.
    b('heart_spark',(-.6,chest-.6,-heart/2-.62),(1.2,1.2,.18),'hot','core')

    # The head is a broad cheeked creature cranium with a low muzzle, not a box helmet.
    hw = 5.3 if final else 4.4
    hz = 3.0 if final else 2.65
    b('head_main',(-hw,head-2.3,-hz),(hw*2,5.2 if final else 4.6,hz*2),'stone','head')
    b('rounded_crown',(-hw+.85,head+2.85 if final else head+2.25,-hz+.5),(hw*2-1.7,1.3,hz*2-1),'stone','head')
    b('jaw_shape',(-hw+1.3,head-3.2,-hz+.3),(hw*2-2.6,1.5,hz*2-.5),'accent','jaw')
    for sign,side in [(-1,'left'),(1,'right')]:
        b(side+'_cheek',(sign*(hw-.5)-1,head-1.95,-hz+.4),(2,3.1,4.1 if final else 3.4),'accent','head',r=(0,0,-sign*13))
        b(side+'_cheek_point',(sign*(hw+.2)-.6,head-1.5,-.5),(1.2,2.3,2.5),'stone','head',r=(0,0,-sign*27))
        ex=sign*(2.35 if final else 1.8)
        eyez=-hz-.16
        b(side+'_eye_white',(ex-1.1,head-.15,eyez),(2.2,1.9 if final else 2.15,.22),'eye','head')
        b(side+'_eye_pupil',(ex-.38+(.15 if sign<0 else -.15),head+.03,eyez-.14),(.9,1.5,.16),'pupil','head')
        b(side+'_eye_glint',(ex-.2,head+.9,eyez-.24),(.4,.4,.12),'light','head')
        if final:
            b(side+'_angry_brow',(ex-1.25,head+1.55,eyez-.3),(2.5,.65,.7),'stone','head',r=(0,0,-sign*14))
        else:
            b(side+'_warm_blush',(sign*3-.55,head-.9,eyez-.1),(1.1,.55,.18),'blush','head')
    b('snout',(-1.8,head-1.35,-hz-.9),(3.6,1.4,1.1),'accent','jaw')
    for sign in [-1,1]:
        b('nostril_'+str(sign),(sign*.65-.22,head-.65,-hz-1.02),(.44,.32,.16),'mouth','jaw')
    b('cheeky_mouth',(-1.2,head-2.0,-hz-.82),(2.4,.4,.22),'mouth','jaw')
    b('single_tusk',((1 if final else -.8),head-2.3,-hz-.96),(.55,1.15,.48),'light','jaw',r=(0,0,-10 if final else 7))

    # Unequal horns and a coal mane keep the silhouette expressive and alive.
    for sign,side in [(-1,'left'),(1,'right')]:
        x=sign*(3.7 if final else 2.9)
        top=head+(4.0 if final else 3.4)
        length=(4.4 if sign>0 else 3.6) if final else (1.8 if sign>0 else 1.25)
        b(side+'_horn',(x-.7,top-.4,-.8),(1.4,length,1.7),'dark','head',r=(0,0,-sign*(23 if final else 15)))
        b(side+'_horn_lit_tip',(x+sign*.75-.45,top+length-1.25,-.7),(.9,1.15,1.35),'hot','head',r=(0,0,-sign*23))
    if final:
        for j,(x,y,ang) in enumerate([(-2.8,head-.7,-20),(0,head+1,0),(2.8,head-.1,22)]):
            b('mane_flame_'+str(j),(x-.85,y,2.45),(1.7,4.5,2.2),'hot' if j==1 else 'accent','mane',r=(ang,0,0))
    else:
        b('cinder_cowlick',(-.7,head+3.1,.6),(1.4,2.1,1.4),'accent','mane',r=(-12,0,-18))

    for sign,side in [(-1,'left'),(1,'right')]:
        arm=side+'_arm'; fore=side+'_forearm';leg=side+'_leg'
        x=sign*armx
        # Arms are soft stepped basalt limbs, with no separate armour cuffs.
        b(side+'_upper_limb',(x-1.8,elbow+1.1,-1.65),(3.6,shoulder-elbow+.2,3.6),'stone',arm)
        b(side+'_shoulder_round',(x-1.4,shoulder+1,-1.3),(2.8,1.2,2.8),'stone',arm)
        b(side+'_elbow',(x-1.2,elbow-.65,-1.15),(2.4,1.8,2.5),'accent',fore)
        by=8.1 if final else 5.35
        b(side+'_axe_root',(x-1.4,by+1,-1.4),(2.8,elbow-by-.8,2.8),'stone',fore)
        # Non-overlapping cross-sections form a continuous hooked crescent.
        # Each tuple is height-offset, band-height, inner-edge, outer-edge.
        rows=[(-1.2,1.4,3.2,4.5),(.2,1.5,2.4,5.7),(1.7,1.6,1.3,6.6),(3.3,1.6,.7,6.9),(4.9,1.4,.7,6.4),(6.3,1.2,.9,5.3),(7.5,1.1,1.1,3.8)] if final else [(-.5,.9,1.6,2.5),(.4,1.1,1.0,3.7),(1.5,1.1,.6,4.1),(2.6,.9,.6,3.4),(3.5,.9,.8,2.2)]
        for j,(dy,height,inner,outer) in enumerate(rows):
            reach=outer-inner
            left=x+inner if sign>0 else x-outer
            b(side+'_crescent_blade_'+str(j),(left,by+dy,-1.15),(reach,height,2.3),'stone',fore)
            edge=x+outer-.45 if sign>0 else x-outer-.1
            b(side+'_molten_edge_'+str(j),(edge,by+dy-.05,-1.23),(.6,height+.1,2.46),'hot',fore)
        lx=sign*(2.8 if final else 2.1)
        b(side+'_haunch',(lx-1.7,hip-3.1,-1.1),(3.4,3.9,3.7),'stone',leg,r=(0,0,-sign*7))
        b(side+'_lower_leg',(lx-1.35,2.6 if final else 1.8,-.9),(2.7,hip-5.2 if final else 2.8,2.9),'accent',leg)
        b(side+'_paw',(lx-1.9,floor,-2.2),(3.8,2.6 if final else 1.8,4.6),'stone',leg)
        for j in range(2):b(side+'_toe_'+str(j),(lx-1.25+j*1.55,floor,-2.72),(1.1,1,1.0),'dark',leg)
    b('tail_base',(-.9,hip+.3,2.6),(1.8,2.1,3),'stone','tail',r=(-12,0,0))
    b('tail_spark',(-1.1,hip+1.3,5),(2.2,2.8,2.2),'hot','tail',r=(0,0,15))


def animate(m):
    """An imp's snort/strut and a heavy breaker's asymmetrical axe choreography."""
    final=m.stage==3
    def ch(*frames):return {str(t):list(v) for t,v in frames}
    def r(*frames):return {'rotation':ch(*frames)}
    def p(*frames):return {'position':ch(*frames)}
    def s(*frames):return {'scale':ch(*frames)}
    def clip(length,bones,loop=False):return {'loop':loop,'animation_length':length,'bones':bones}
    rest=(0,0,0);one=(1,1,1)
    T=4.2 if final else 3.0
    idle={
      'body':s((0,one),(T*.45,(1.025,1.015,1.03)),(T,one)),
      'head':r((0,rest),(.7,(1,-6,-2)),(1.2,(-3,-9,-4)),(1.4,(3,-7,-2)),(1.65,rest),(T,rest)),
      'jaw':r((0,rest),(1.18,rest),(1.32,(10 if final else 16,0,0)),(1.48,rest),(T,rest)),
      'right_forearm':r((0,rest),(T*.55,(0,0,0)),(T*.7,(0,0,-9 if final else -17)),(T*.84,rest),(T,rest)),
      'tail':r((0,(0,-8,-2)),(T*.4,(0,10,4)),(T,(0,-8,-2))),
      'core':s((0,one),(T*.26,(1.08,1.08,1.08)),(T*.4,one),(T*.48,(1.04,1.04,1.04)),(T*.6,one),(T,one)),
      'mane':r((0,rest),(T*.4,(-5,0,3)),(T,rest))}
    W=1.45 if final else .95
    walk={
      'root':p((0,rest),(W*.18,(0,.5,0)),(W*.34,rest),(W*.68,(0,.65,0)),(W*.85,rest),(W,rest)),
      'body':r((0,(0,-4,4)),(W*.34,(0,5,-4)),(W*.72,(0,-5,3)),(W,(0,-4,4))),
      'head':r((0,(1,3,-3)),(W*.34,(-2,-3,3)),(W*.72,(1,3,-2)),(W,(1,3,-3))),
      'left_leg':r((0,(23,0,0)),(W*.22,(-14,0,0)),(W*.53,(-18,0,0)),(W*.76,(20,0,0)),(W,(23,0,0))),
      'right_leg':r((0,(-17,0,0)),(W*.3,(21,0,0)),(W*.57,(18,0,0)),(W*.83,(-18,0,0)),(W,(-17,0,0))),
      'left_arm':r((0,(-7,0,-2)),(W*.5,(8,0,-1)),(W,(-7,0,-2))),
      'right_arm':r((0,(9,0,2)),(W*.54,(-6,0,1)),(W,(9,0,2))),
      'tail':r((0,(0,-12,0)),(W*.5,(0,12,0)),(W,(0,-12,0)))}
    A=1.15 if final else .82
    attack={
      'body':r((0,rest),(A*.28,(0,-25,-8)),(A*.47,(4,27,9)),(A*.63,(2,32,6)),(A,rest)),
      'head':r((0,rest),(A*.28,(-6,19,4)),(A*.47,(8,-17,-4)),(A,rest)),
      'right_arm':r((0,rest),(A*.25,(-42,-35,37)),(A*.44,(75,35,-48)),(A*.62,(60,20,-39)),(A,rest)),
      'right_forearm':r((0,rest),(A*.25,(-15,0,17)),(A*.46,(9,0,-20)),(A*.65,(0,0,-13)),(A,rest)),
      'left_arm':r((0,rest),(A*.3,(-8,0,-14)),(A*.5,(14,0,-18)),(A,rest)),
      'root':p((0,rest),(A*.28,(0,0,.4)),(A*.46,(0,0,-1.8 if final else -1)),(A*.68,(0,0,-1)),(A,rest)),
      'jaw':r((0,rest),(A*.35,(18,0,0)),(A*.62,(10,0,0)),(A,rest)),
      'mane':r((0,rest),(A*.3,(-14,0,-12)),(A*.5,(13,0,14)),(A,rest))}
    J=1.9 if final else 1.4
    special={
      'root':p((0,rest),(J*.17,rest),(J*.36,(0,4.4 if final else 3,0)),(J*.46,(0,4.8 if final else 3.5,-.3)),(J*.59,rest),(J*.67,(0,.45,0)),(J*.8,rest),(J,rest)),
      'body':r((0,rest),(J*.18,(12,0,0)),(J*.4,(-15,0,0)),(J*.59,(22,0,0)),(J*.74,(-4,0,0)),(J,rest)),
      'head':r((0,rest),(J*.2,(-7,0,0)),(J*.4,(-12,0,0)),(J*.59,(13,0,0)),(J,rest)),
      'left_arm':r((0,rest),(J*.35,(-141,0,-18)),(J*.46,(-150,0,-15)),(J*.59,(75,0,-8)),(J*.73,(45,0,-8)),(J,rest)),
      'right_arm':r((0,rest),(J*.35,(-141,0,18)),(J*.46,(-150,0,15)),(J*.59,(75,0,8)),(J*.73,(45,0,8)),(J,rest)),
      'left_forearm':r((0,rest),(J*.4,(-28,0,0)),(J*.59,(14,0,0)),(J,rest)),
      'right_forearm':r((0,rest),(J*.4,(-28,0,0)),(J*.59,(14,0,0)),(J,rest)),
      'core':s((0,one),(J*.45,(1.25,1.25,1.25)),(J*.61,(.92,.92,.92)),(J*.8,one),(J,one)),
      'tail':r((0,rest),(J*.35,(-25,0,0)),(J*.59,(30,0,0)),(J,rest))}
    H=.7 if final else .55
    hurt={
      'root':p((0,rest),(H*.25,(0,0,1.2)),(H*.6,(0,0,.7)),(H,rest)),
      'body':r((0,rest),(H*.25,(17,-8,-7)),(H*.54,(11,-4,-3)),(H,rest)),
      'head':r((0,rest),(H*.25,(-18,9,7)),(H,rest)),
      'left_arm':r((0,rest),(H*.25,(-13,0,-16)),(H,rest)),
      'right_arm':r((0,rest),(H*.25,(-22,0,18)),(H,rest)),
      'jaw':r((0,rest),(H*.25,(14,0,0)),(H,rest))}
    F=1.55 if final else 1.2
    faint={
      'body':r((0,rest),(F*.25,(0,0,-7)),(F*.55,(5,0,-24)),(F*.8,(4,0,-82)),(F,(4,0,-82))),
      'root':p((0,rest),(F*.3,(0,-1,0)),(F*.68,(0,-4 if final else -2.5,0)),(F*.85,(0,-8.8 if final else -4.6,0)),(F,(0,-8.8 if final else -4.6,0))),
      'head':r((0,rest),(F*.4,(13,0,-7)),(F*.8,(19,0,5)),(F,(19,0,5))),
      'left_arm':r((0,rest),(F*.7,(8,0,26)),(F,(8,0,26))),
      'right_arm':r((0,rest),(F*.7,(0,0,-13)),(F,(0,0,-13))),
      'jaw':r((0,rest),(F*.7,(8,0,0)),(F,(8,0,0))),
      'tail':r((0,rest),(F*.75,(25,0,14)),(F,(25,0,14)))}
    m.animations={'idle':clip(T,idle,True),'walk':clip(W,walk,True),'attack':clip(A,attack),'special':clip(J,special),'hurt':clip(H,hurt),'faint':clip(F,faint)}
