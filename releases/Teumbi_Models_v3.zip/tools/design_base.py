"""Teumbi V3: a curious stone seed, not a tiny mechanical person.

The rounded cracked-egg silhouette is interrupted around one living core.
Upper shell carries the expressive face. Unequal shards never form limbs.
"""


def build(m, stage=1):
    m.bone('crown', (0, 11.7, 0))
    m.bone('core', (0, 7.1, -.1))
    m.bone('shell_left', (-4.8, 8, .3))
    m.bone('shell_right', (4.7, 6.5, .4))
    m.bone('shell_bottom', (-.3, 3.6, .3))
    m.bone('orbit', (0, 8.2, .3))
    m.bone('eye_left', (-1.95, 11.6, -3.04), 'crown')
    m.bone('eye_right', (1.5, 11.75, -3.04), 'crown')

    def b(n, p, s, mat='stone', bone='crown', r=(0, 0, 0), pivot=None):
        m.box(n, p, s, mat, bone, rotation=r, pivot=pivot)

    # Broad cream-grey face; stepped volume softens the shell's egg profile.
    b('face_seed', (-3.5, 9.9, -2.85), (7, 3.5, 5.5), 'light')
    b('round_left_cheek', (-4.35, 10.3, -2.15), (.9, 2.6, 4.1))
    b('round_right_cheek', (3.45, 10.45, -2.05), (1.05, 2.35, 3.9))
    b('rounded_forehead', (-3.15, 13.4, -2.35), (6.3, 1, 4.5), 'light')
    b('shell_dome', (-2.1, 14.4, -1.55), (4.3, .8, 3.1))
    b('top_offset_pebble', (-1.45, 15.15, -.65), (1.7, .7, 1.7), 'light', r=(0, 0, -12))
    b('lower_face_curve', (-2.55, 9.25, -2.35), (5.1, .7, 4.3), 'light')
    b('shell_back', (-3.1, 10.1, 2.6), (6.2, 3.35, .9))
    b('side_scar', (-4.37, 11.7, -.2), (.14, 1.1, 1.9), 'accent')
    b('forehead_tilt_mark', (2.1, 13.65, -2.4), (.65, .65, .2), 'accent', r=(0, 0, 30))

    # Eyes sit directly on the face, with iris and catchlight rather than a visor.
    for side, x, y in [('left', -2.8, 10.75), ('right', .65, 10.9)]:
        bn = 'eye_' + side
        b(side+'_eye_white', (x, y, -3.04), (1.7, 1.75, .2), 'eye', bn)
        b(side+'_pupil', (x+.65, y+.2, -3.18), (.8, 1.15, .18), 'pupil', bn)
        b(side+'_catchlight', (x+.62, y+.91, -3.3), (.3, .35, .12), 'light', bn)
    b('tiny_smile', (-.4, 10.05, -2.96), (.8, .2, .16), 'mouth')
    b('smile_corner', (.35, 10.2, -2.97), (.17, .22, .17), 'mouth')
    b('left_soft_cheek', (-3.1, 10.2, -2.98), (.65, .22, .15), 'blush')
    b('right_soft_cheek', (2.6, 10.35, -2.98), (.6, .22, .15), 'blush')

    # One compact faceted core, suspended within the shell opening.
    b('single_heart', (-1.4, 5.7, -1.45), (2.8, 2.8, 2.8), 'glow', 'core', (0, 17, 9))
    b('heart_top_facet', (-.95, 8.5, -.95), (1.9, .25, 1.8), 'light', 'core')

    # Unequal curved shell sections: left high, right low, interrupted cradle.
    b('left_shard_main', (-6.05, 6.3, -.4), (1.5, 3.4, 3.7), 'stone', 'shell_left', (0, 0, -9))
    b('left_shard_front_curve', (-5.45, 7.2, -1.8), (1.3, 2.25, 2.2), 'light', 'shell_left')
    b('left_shard_top', (-5.6, 9.5, .25), (1.25, .8, 2.5), 'stone', 'shell_left')
    b('left_shard_low_taper', (-5.55, 5.55, .25), (1.05, .9, 2.45), 'stone', 'shell_left')
    b('left_scar', (-5.5, 8, -1.86), (.9, .25, .12), 'accent', 'shell_left')

    b('right_shard_main', (4.55, 4.7, -.3), (1.6, 3.35, 3.5), 'stone', 'shell_right', (0, 0, 12))
    b('right_shard_lip', (3.9, 5.45, -1.5), (1.3, 2.45, 2), 'light', 'shell_right')
    b('right_shard_taper', (4.5, 3.9, .2), (1.25, 1, 2.6), 'stone', 'shell_right')
    b('right_back_curl', (4.05, 6.05, 2.5), (1.6, 1.7, 1), 'stone', 'shell_right')
    b('right_scar', (4.3, 6.9, -1.57), (.7, .22, .12), 'accent', 'shell_right')

    b('cradle_main', (-2.85, 2.7, -1.2), (5, 1.45, 3.8), 'stone', 'shell_bottom')
    b('cradle_round_tip', (-1.75, 1.95, -.65), (3.25, .8, 2.6), 'light', 'shell_bottom')
    b('cradle_back_curve', (-2.4, 4.15, 1.65), (4.4, 1.2, 1.1), 'stone', 'shell_bottom')
    b('cradle_left_lip', (-3.4, 3.8, -.35), (1.1, 1.1, 2.5), 'light', 'shell_bottom')
    b('cradle_right_break', (1.5, 4, .35), (1.05, .8, 1.8), 'stone', 'shell_bottom')

    for n, p, s, r in [
        ('orbit_high', (4.9, 12.2, .5), (.75, .8, .85), (10, 18, 10)),
        ('orbit_low', (-3.95, 3.85, -1.4), (.7, .65, .8), (5, 8, -18)),
        ('orbit_side', (-6.4, 11.65, .7), (.55, .7, .6), (5, 15, -15)),
        ('orbit_back', (2.8, 7.5, 3.8), (.8, .75, .65), (15, -10, 10)),
    ]:
        b(n, p, s, 'stone', 'orbit', r)


def animate(m):
    """Curiosity, shell lag and anticipation distinguish this little floater."""
    def R(**v): return {str(k).replace('_', '.'): val for k, val in v.items()}
    def clip(length, bones, loop=False):
        return {'loop': loop, 'animation_length': length, 'bones': bones}
    zero = [0, 0, 0]
    blink = {'0':[1,1,1],'2.46':[1,1,1],'2.53':[1,.12,1],'2.64':[1,1,1], '3.48':[1,1,1],'3.55':[1,.2,1],'3.65':[1,1,1],'4.4':[1,1,1]}
    m.animations = {
        'idle': clip(4.4, {
            'root': {'position': {'0':zero,'.65':[0,.45,0],'1.7':[0,.1,0],'2.7':[0,.6,0],'3.5':[0,.15,0],'4.4':zero}},
            'crown': {'rotation': {'0':zero,'.9':[0,-7,-4],'1.8':[0,-7,-4],'2.25':[0,8,5],'3.5':[0,3,1],'4.4':zero}},
            'core': {'position': {'0':zero,'1.1':[.15,.35,0],'2.5':[-.18,.05,.1],'3.7':[0,.3,0],'4.4':zero},
                     'rotation': {'0':[0,-6,-3],'1.7':[0,7,4],'3':[0,-2,1],'4.4':[0,-6,-3]}},
            'shell_left': {'position': {'0':zero,'1.2':[-.15,.12,0],'2.5':[-.35,0,.1],'4.4':zero},
                           'rotation': {'0':zero,'1.6':[0,-5,-4],'3':[0,3,2],'4.4':zero}},
            'shell_right': {'position': {'0':zero,'1.7':[.18,-.15,0],'3.15':[.12,.25,0],'4.4':zero}},
            'shell_bottom': {'rotation': {'0':zero,'1.4':[2,0,3],'3.3':[-2,0,-2],'4.4':zero}},
            'orbit': {'rotation': {'0':zero,'1.6':[0,12,-3],'3.2':[0,-5,4],'4.4':zero}},
            'eye_left': {'scale': blink}, 'eye_right': {'scale': blink},
        }, True),
        'walk': clip(1.3, {
            'root': {'position': {'0':zero,'.3':[0,.65,-.3],'.7':[0,.15,.2],'1':[0,.45,.1],'1.3':zero},
                     'rotation': {'0':[8,0,-3],'.38':[11,0,4],'.8':[7,0,-2],'1.3':[8,0,-3]}},
            'crown': {'rotation': {'0':[-4,0,0],'.45':[2,0,-3],'.9':[-2,0,1],'1.3':[-4,0,0]}},
            'shell_left': {'position': {'0':[0,0,.2],'.35':[0,-.35,.65],'.75':[0,.2,-.15],'1.3':[0,0,.2]}},
            'shell_right': {'position': {'0':[0,.1,.35],'.5':[0,-.25,.7],'.95':[0,.15,-.1],'1.3':[0,.1,.35]}},
            'shell_bottom': {'rotation': {'0':[-5,0,0],'.5':[7,0,0],'1.3':[-5,0,0]}},
            'orbit': {'rotation': {'0':[0,0,-5],'.6':[0,5,6],'1.3':[0,0,-5]}},
        }, True),
        'attack': clip(1.05, {
            'root': {'position': {'0':zero,'.18':[0,-.35,1],'.32':[0,.1,-2.8],'.43':[0,.1,-3.2],'.68':[0,.55,.2],'1.05':zero},
                     'rotation': {'0':zero,'.2':[-12,0,0],'.35':[22,0,0],'.55':[-6,0,0],'1.05':zero}},
            'crown': {'rotation': {'0':zero,'.2':[8,0,0],'.4':[-10,0,0],'.7':[6,0,0],'1.05':zero}},
            'shell_left': {'position': {'0':zero,'.22':[1.3,-.4,-.4],'.46':[-.8,.3,.2],'.7':[-.4,.1,0],'1.05':zero}},
            'shell_right': {'position': {'0':zero,'.22':[-1.1,.25,-.4],'.48':[.8,-.25,.3],'.75':[.35,0,0],'1.05':zero}},
            'shell_bottom': {'position': {'0':zero,'.2':[0,1,-.2],'.5':[0,-.65,.4],'1.05':zero}},
            'orbit': {'scale': {'0':[1,1,1],'.22':[.78,.78,.78],'.5':[1.15,1.1,1.15],'1.05':[1,1,1]}},
        }),
        'special': clip(2.6, {
            'root': {'position': {'0':zero,'.45':[0,.2,0],'1.15':[0,1,0],'1.7':[0,1,0],'2.6':zero}},
            'crown': {'position': {'0':zero,'.55':[0,1.5,.3],'1.6':[0,1.9,.4],'2.6':zero},
                      'rotation': {'0':zero,'.55':[-8,0,0],'1.6':[-10,0,0],'2.6':zero}},
            'shell_left': {'position': {'0':zero,'.55':[-1.45,0,.2],'1.6':[-1.6,.15,.2],'2.6':zero},
                           'rotation': {'0':zero,'.65':[0,-14,-15],'1.6':[0,-14,-15],'2.6':zero}},
            'shell_right': {'position': {'0':zero,'.63':[1.5,0,.3],'1.6':[1.65,.1,.2],'2.6':zero},
                            'rotation': {'0':zero,'.65':[0,14,17],'1.6':[0,14,17],'2.6':zero}},
            'shell_bottom': {'position': {'0':zero,'.6':[0,-.9,0],'1.6':[0,-1,0],'2.6':zero}},
            'core': {'scale': {'0':[1,1,1],'.45':[.85,.85,.85],'.85':[1.35,1.35,1.35],'1.1':[1.12,1.12,1.12],'1.4':[1.38,1.38,1.38],'1.75':[1.05,1.05,1.05],'2.6':[1,1,1]},
                     'rotation': {'0':zero,'1.4':[0,30,15],'2.6':zero}},
            'orbit': {'rotation': {'0':zero,'.8':[0,30,0],'1.6':[0,65,0],'2.6':zero},
                      'scale': {'0':[1,1,1],'.8':[1.3,1.15,1.3],'1.6':[1.35,1.2,1.35],'2.6':[1,1,1]}},
        }),
        'hurt': clip(.75, {
            'root': {'position': {'0':zero,'.12':[0,.2,.8],'.28':[0,.1,.45],'.75':zero},
                     'rotation': {'0':zero,'.12':[-15,0,9],'.3':[5,0,-4],'.75':zero}},
            'crown': {'rotation': {'0':zero,'.12':[7,0,-6],'.75':zero}},
            'shell_left': {'position': {'0':zero,'.15':[.7,-.1,0],'.75':zero}},
            'shell_right': {'position': {'0':zero,'.15':[-.7,.2,0],'.75':zero}},
            'eye_left': {'scale': {'0':[1,1,1],'.12':[1,.15,1],'.5':[1,.15,1],'.75':[1,1,1]}},
            'eye_right': {'scale': {'0':[1,1,1],'.12':[1,.15,1],'.5':[1,.15,1],'.75':[1,1,1]}},
        }),
        'faint': clip(1.8, {
            'root': {'position': {'0':zero,'.45':[0,-.8,0],'1.2':[0,-1.1,0],'1.8':[0,-1.1,0]}},
            'crown': {'position': {'0':zero,'.7':[.5,-1.8,.4],'1.3':[.8,-2.1,.6],'1.8':[.8,-2.1,.6]},
                      'rotation': {'0':zero,'.7':[12,0,18],'1.3':[15,0,22],'1.8':[15,0,22]}},
            'core': {'position': {'0':zero,'.65':[0,-1.7,0],'1.3':[0,-1.9,0],'1.8':[0,-1.9,0]},
                     'scale': {'0':[1,1,1],'.7':[.75,.75,.75],'1.8':[.75,.75,.75]}},
            'shell_left': {'position': {'0':zero,'.8':[-.6,-2,.4],'1.8':[-.6,-2,.4]},
                           'rotation': {'0':zero,'.8':[0,-10,-25],'1.8':[0,-10,-25]}},
            'shell_right': {'position': {'0':zero,'.9':[.6,-2,.2],'1.8':[.6,-2,.2]},
                            'rotation': {'0':zero,'.9':[0,10,29],'1.8':[0,10,29]}},
            'orbit': {'position': {'0':zero,'1.1':[0,-1.8,0],'1.8':[0,-1.8,0]}},
            'eye_left': {'scale': {'0':[1,1,1],'.5':[1,.12,1],'1.8':[1,.12,1]}},
            'eye_right': {'scale': {'0':[1,1,1],'.5':[1,.12,1],'1.8':[1,.12,1]}},
        }),
    }
