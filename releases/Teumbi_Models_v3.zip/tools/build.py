import json,pathlib
from model import Model
import design_base,design_fire,design_electric,design_grass,design_water
ROOT=pathlib.Path(__file__).parent
manifest=[]
for kind,design in [('normal',design_base),('fire',design_fire),('electric',design_electric),('grass',design_grass),('water',design_water)]:
    for stage in ([1] if kind=='normal' else [2,3]):
        name='teumbi' if kind=='normal' else f'teumbi_{kind}_{stage}'
        m=Model(name,kind,stage)
        design.build(m,stage);design.animate(m)
        manifest.append(m.export(ROOT/'pack'))
(ROOT/'pack'/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
