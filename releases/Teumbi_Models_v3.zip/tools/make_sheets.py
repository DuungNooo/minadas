"""Compose actual model renders into easy-to-review sheets."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent;P=ROOT/'pack/previews'
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
BOLD='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def font(n,bold=False):return ImageFont.truetype(BOLD if bold else FONT,n)
BG='#efece5';INK='#252b31';MUTED='#67716f'
INFO={'fire':('불꽃','양팔 도끼 · 물리 공격','#b6542b'),'electric':('전기','피뢰침 · 특수 공격','#ac8631'),'grass':('풀','결합 방패 · 수호','#557856'),'water':('물','물줄기 하프 · 지원','#367f99')}
def main():
    sheet=Image.new('RGB',(2560,1120),BG);d=ImageDraw.Draw(sheet)
    d.text((72,40),'틈비  /  분기 진화 V3',font=font(54,True),fill=INK)
    d.text((75,118),'최종 진화 4종  ·  실제 모델과 텍스처의 렌더링',font=font(25),fill=MUTED)
    for i,(kind,(label,role,col)) in enumerate(INFO.items()):
        x=48+i*628
        im=Image.open(P/f'teumbi_{kind}_3_threequarter.png').convert('RGB').resize((600,667),Image.Resampling.LANCZOS)
        sheet.paste(im,(x,190));d.rounded_rectangle((x,885,x+8,983),3,fill=col)
        d.text((x+26,880),label,font=font(42,True),fill=INK)
        d.text((x+26,946),role,font=font(25),fill=MUTED)
    d.text((74,1050),'블록 기반 원본 모델  ·  Blockbench 편집 / 코어와 관절 애니메이션 포함',font=font(21),fill=MUTED)
    sheet.save(P/'final-evolutions.png')
    sheet.save(P/'final-evolutions.jpg',quality=93,subsampling=0)
    sheet=Image.new('RGB',(2100,2580),BG);d=ImageDraw.Draw(sheet)
    d.text((56,34),'틈비  /  전체 진화 모델 9종',font=font(48,True),fill=INK)
    names=['teumbi','teumbi_fire_2','teumbi_fire_3','teumbi_electric_2','teumbi_electric_3','teumbi_grass_2','teumbi_grass_3','teumbi_water_2','teumbi_water_3']
    for i,name in enumerate(names):
        x=30+(i%3)*690;y=125+(i//3)*810
        im=Image.open(P/(name+'_threequarter.png')).convert('RGB').resize((660,733),Image.Resampling.LANCZOS)
        sheet.paste(im,(x,y))
        title='틈비 · 노말 / 1단계' if name=='teumbi' else INFO[name.split('_')[1]][0]+' / '+name[-1]+'단계'
        d.text((x+18,y+745),title,font=font(29,True),fill=INK)
    sheet.save(P/'all-evolutions.png')
    sheet.save(P/'all-evolutions.jpg',quality=93,subsampling=0)
    print('Created actual-render preview sheets')
if __name__=='__main__':main()
