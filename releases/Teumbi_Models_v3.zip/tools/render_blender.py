"""Render the exported cuboid source faithfully with a studio lighting rig.

Usage:
  blender -b -t 4 --python render_blender.py -- teumbi_fire_3 threequarter 24
  blender -b -t 4 --python render_blender.py -- teumbi front 16

Writes a PNG and a static textured GLB. Studio lights, camera and floor are
excluded from the GLB; they never become parts of the creature geometry.
"""
import json
import math
import pathlib
import sys
import hashlib

import bpy
from mathutils import Euler, Matrix, Vector


ROOT = pathlib.Path(__file__).resolve().parent
PACK = ROOT / 'pack'
ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
NAME = ARGS[0] if ARGS else 'teumbi_fire_3'
VIEW = ARGS[1] if len(ARGS) > 1 else 'threequarter'
SAMPLES = int(ARGS[2]) if len(ARGS) > 2 else 24


def around(pivot, angles):
    p = Vector(pivot)
    rotation = Euler(tuple(math.radians(a) for a in angles), 'XYZ').to_matrix().to_4x4()
    return Matrix.Translation(p) @ rotation @ Matrix.Translation(-p)


def mapped(point):
    return Vector((point.x / 16, point.z / 16, point.y / 16))


def make_material(name):
    mat = bpy.data.materials.new(name + '_pixel_material')
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    shader = nodes.get('Principled BSDF')
    shader.inputs['Roughness'].default_value = .78
    shader.inputs['Metallic'].default_value = .05
    shader.inputs['Specular IOR Level'].default_value = .23
    color = nodes.new('ShaderNodeTexImage')
    color.name = 'Nearest pixel albedo'
    color.image = bpy.data.images.load(str(PACK / 'textures' / f'{name}.png'))
    color.interpolation = 'Closest'
    links.new(color.outputs['Color'], shader.inputs['Base Color'])
    glow_file = PACK / 'textures' / f'{name}_emissive.png'
    if glow_file.is_file():
        glow = nodes.new('ShaderNodeTexImage')
        glow.name = 'Subtle emissive pixels'
        glow.image = bpy.data.images.load(str(glow_file))
        glow.interpolation = 'Closest'
        # Transparent atlas areas are black. Alpha gates emission to prevent
        # invisible padding RGB from lighting non-emissive model surfaces.
        mix = nodes.new('ShaderNodeMixRGB')
        mix.blend_type = 'MULTIPLY'
        mix.inputs[0].default_value = 1
        links.new(glow.outputs['Color'], mix.inputs[1])
        links.new(glow.outputs['Alpha'], mix.inputs[2])
        links.new(mix.outputs['Color'], shader.inputs['Emission Color'])
        shader.inputs['Emission Strength'].default_value = .65
    return mat


def light(name, location, energy, size, color, target):
    data = bpy.data.lights.new(name, 'AREA')
    data.energy = energy
    data.shape = 'DISK'
    data.size = size
    data.color = color
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    obj.rotation_euler = (Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
    return obj


def main():
    source_bytes=(PACK/'source'/f'{NAME}.json').read_bytes()
    source = json.loads(source_bytes)
    source_sha=hashlib.sha256(source_bytes).hexdigest()
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    model_collection = bpy.data.collections.new(NAME)
    scene.collection.children.link(model_collection)
    material = make_material(NAME)
    transforms = {}
    for b in source['bones']:
        local = around(b['pivot'], b.get('rotation', (0,0,0)))
        transforms[b['name']] = transforms.get(b.get('parent'), Matrix.Identity(4)) @ local

    # Winding is defined after the y/z exchange, whose determinant is -1.
    face_indices = {
        'north': (0,1,2,3), 'south': (5,4,7,6),
        'east': (1,5,6,2), 'west': (4,0,3,7),
        'up': (3,2,6,7), 'down': (4,5,1,0),
    }
    model_objects = []
    all_vertices = []
    resolution = source['texture_size']
    for box in source['boxes']:
        x,y,z = box['origin']
        w,h,d = box['size']
        corners = [Vector(v) for v in [
            (x,y,z),(x+w,y,z),(x+w,y+h,z),(x,y+h,z),
            (x,y,z+d),(x+w,y,z+d),(x+w,y+h,z+d),(x,y+h,z+d),
        ]]
        transform = transforms[box['bone']] @ around(box['pivot'], box.get('rotation',(0,0,0)))
        verts = [mapped(transform @ v) for v in corners]
        all_vertices.extend(verts)
        mesh = bpy.data.meshes.new(box['name'])
        mesh.from_pydata(verts, [], list(face_indices.values()))
        mesh.materials.append(material)
        mesh.update()
        layer = mesh.uv_layers.new(name='Pixel Atlas')
        for polygon, face in zip(mesh.polygons, face_indices):
            x0,y0,x1,y1 = box['uv'][face]
            coords = [(x0/resolution,1-y1/resolution),
                      (x1/resolution,1-y1/resolution),
                      (x1/resolution,1-y0/resolution),
                      (x0/resolution,1-y0/resolution)]
            for li, uv in zip(polygon.loop_indices,coords):
                layer.data[li].uv = uv
        obj = bpy.data.objects.new(box['name'],mesh)
        model_collection.objects.link(obj)
        model_objects.append(obj)

    minimum = Vector(tuple(min(v[i] for v in all_vertices) for i in range(3)))
    maximum = Vector(tuple(max(v[i] for v in all_vertices) for i in range(3)))
    center = (minimum+maximum)/2
    extent = maximum-minimum
    radius = max(extent)*2
    # A floor touches the lowest cube. This is merely a studio shadow catcher.
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0,0,minimum.z-.015))
    ground = bpy.context.object
    ground.name='Studio floor (not exported)'
    ground_mat=bpy.data.materials.new('Warm studio floor')
    ground_mat.diffuse_color=(.78,.755,.70,1)
    ground_mat.use_nodes=True
    ground_bsdf=ground_mat.node_tree.nodes.get('Principled BSDF')
    ground_bsdf.inputs['Base Color'].default_value=(.78,.755,.70,1)
    ground_bsdf.inputs['Roughness'].default_value=.9
    ground.data.materials.append(ground_mat)

    scene.world.use_nodes=True
    scene.world.node_tree.nodes.get('Background').inputs['Color'].default_value=(.68,.74,.83,1)
    scene.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.38
    light('Large warm key',(-3.5,-4.5,6),420,4,(1,.91,.79),center)
    light('Soft cool fill',(4,-2,3.5),240,3,(.78,.87,1),center)
    light('Top edge light',(1.5,3,5.5),500,3,(1,.94,.82),center)

    camera_data=bpy.data.cameras.new('Orthographic asset camera')
    camera=bpy.data.objects.new('Orthographic asset camera',camera_data)
    scene.collection.objects.link(camera)
    direction={'front':Vector((0,-2,.08)),
               'threequarter':Vector((.88,-1.9,.82)),
               'back':Vector((.88,1.9,.82))}.get(VIEW,Vector((.88,-1.9,.82)))
    camera.location=center+direction.normalized()*max(6,radius)
    camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler()
    camera_data.type='ORTHO'
    scene.camera=camera
    bpy.context.view_layer.update()
    inv=camera.matrix_world.inverted()
    camera_points=[inv@v for v in all_vertices]
    span_x=max(v.x for v in camera_points)-min(v.x for v in camera_points)
    span_y=max(v.y for v in camera_points)-min(v.y for v in camera_points)
    # For a portrait render Blender's AUTO sensor fit uses the vertical axis.
    # Choosing the larger conservative size leaves clean margins for all views.
    camera_data.ortho_scale=max(span_y,span_x/0.9)*1.24
    camera_data.lens=50

    scene.render.engine='CYCLES'
    scene.cycles.device='CPU'
    scene.cycles.samples=SAMPLES
    # The installed CPU build has no OpenImageDenoise support.
    scene.cycles.use_denoising=False
    scene.cycles.max_bounces=5
    scene.cycles.diffuse_bounces=3
    scene.cycles.glossy_bounces=2
    scene.cycles.transmission_bounces=1
    scene.render.threads_mode='FIXED'
    scene.render.threads=2
    scene.render.resolution_x=900
    scene.render.resolution_y=1000
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    scene.render.image_settings.color_mode='RGBA'
    scene.render.film_transparent=False
    scene.view_settings.view_transform='AgX'
    scene.view_settings.look='AgX - Medium High Contrast'
    scene.view_settings.exposure=.3
    scene.view_settings.gamma=1
    # Keep image crisp: no bevels, smoothing, procedural microgeometry or DOF.
    scene.render.film_transparent=False
    preview_dir=PACK/'previews'
    preview_dir.mkdir(exist_ok=True)
    scene.render.filepath=str(preview_dir/f'{NAME}_{VIEW}.png')
    bpy.ops.render.render(write_still=True)
    (preview_dir/f'{NAME}_{VIEW}.render.json').write_text(json.dumps({'name':NAME,'view':VIEW,'source_sha256':source_sha,'cube_count':len(source['boxes']),'samples':SAMPLES},indent=2))

    # A static, textured inspection asset for applications that support glTF.
    # The editable/animated source of truth remains bbmodel + animation JSON.
    if VIEW=='threequarter':
        export_dir=PACK/'glb'
        export_dir.mkdir(exist_ok=True)
        bpy.ops.object.select_all(action='DESELECT')
        for obj in model_objects:obj.select_set(True)
        bpy.context.view_layer.objects.active=model_objects[0]
        bpy.ops.export_scene.gltf(filepath=str(export_dir/f'{NAME}.glb'),
                                  export_format='GLB',use_selection=True,
                                  export_animations=False,export_cameras=False,
                                  export_lights=False,export_yup=True)
    print(f'RENDER_OK {NAME} {VIEW} {len(source["boxes"])} real cubes')


if __name__=='__main__':
    main()
